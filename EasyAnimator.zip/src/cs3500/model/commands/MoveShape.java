package cs3500.model.commands;

import cs3500.model.shapes.IShape;
import cs3500.model.shapes.Posn;
import java.util.AbstractMap;
import java.util.Objects;

/**
 * A class to represent the type of command that moves a shape to a given position.
 */
public class MoveShape extends ACommand {

  private final Posn newPosn;
  private Posn originalPosn;

  private int newWidth;
  private int newHeight;

  /**
   * A constructor with all of the abstract fields plus the position we are moving the shape to.
   *
   * @param shapes    The list of shapes currently in the model.
   * @param shapeName The index in shapes that gives us the shape we will be doing the command on.
   * @param start     The tick this command starts on.
   * @param end       The tick this command ends on.
   * @param newPosn   The posn we are changing the position of the shape to be.
   */
  public MoveShape(AbstractMap<String, IShape> shapes, String shapeName, int start, int end,
      Posn newPosn) {
    super(shapes, shapeName, start, end);
    this.newPosn = newPosn;
    this.currTick = start + 1;

    this.newWidth = Integer.MIN_VALUE;
    this.newHeight = Integer.MIN_VALUE;

  }

  /**
   * Performs one tick on the command. One tick is (1 / (end - start))th of the commands work. The
   * command's shape field is updated with its new values each tick, so Posn is changed here.
   */
  public void tick() {

    if (this.currTick == this.start + 1) {
      this.originalPosn = this.shapes.get(shapeName).getPosition();
    }

    this.shape = shapes.get(shapeName);
    double xATween = originalPosn.getX() *
        (((this.end - this.currTick) * 1.0) / ((this.end - this.start) * 1.0));
    double yATween = originalPosn.getY() *
        (((this.end - this.currTick) * 1.0) / ((this.end - this.start) * 1.0));

    double xBTween = this.newPosn.getX() *
        (((this.currTick - this.start) * 1.0) / ((this.end - this.start) * 1.0));
    double yBTween = this.newPosn.getY() *
        (((this.currTick - this.start) * 1.0) / ((this.end - this.start) * 1.0));

    double newX = xATween + xBTween;
    double newY = yATween + yBTween;
    this.shape.moveTo(newX, newY);
    if (this.currTick == this.end) {
      this.roundValues();
    }
    this.shapes.put(this.shapeName, this.shape);
    this.currTick++;
  }

  /**
   * Returns a copy of the given ICommand, but is not mutable.
   *
   * @param tree The hashmap to be used as this command's shape list.
   * @return A new ICommand of the same type and with the same values as the given one.
   */
  public ICommand getCopy(AbstractMap<String, IShape> tree) {
    return new MoveShape(tree, this.shapeName, this.start, this.end,
        this.newPosn.getCopy());
  }

  /**
   * Returns the shape this command is acting upon.
   *
   * @return The shape field of the command.
   */
  @Override
  public IShape getShape() {
    return this.shapes.get(this.shapeName);
  }

  /**
   * Sets this commands shape to be the given shape.
   *
   * @param shape The shape to be used as this commands new shape.
   */
  @Override
  public void setShape(IShape shape) {
    this.shape = shape;
    this.originalPosn = this.shape.getCopy().getPosition();
  }

  /**
   * Determines whether a command and an object are equal to one another.
   *
   * @param o The object we are determining if this command is equal to.
   * @return A boolean value stating whether the commmand and object are equal to eachother.
   */
  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (!(o instanceof MoveShape)) {
      return false;
    }
    MoveShape move = (MoveShape) o;
    if (this.shapes.size() != move.shapes.size()) {
      return false;
    }
    for (String s : this.shapes.keySet()) {
      if (!(this.shapes.get(s).equals(move.shapes.get(s)))) {
        return false;
      }
    }
    return this.shapeName.equals(move.shapeName) && this.start == move.start
        && this.end == move.end && this.newPosn.equals(move.newPosn);
  }

  /**
   * Overwrites hashcode for our new definition of equals for the command interface.
   *
   * @return The hashcode of the given command.
   */
  @Override
  public int hashCode() {
    return Objects.hash(this.shapeName, this.start, this.end, this.newPosn);
  }

  /**
   * Rounds the the x and y coordinates of this commands shape to whole numbers.
   */
  @Override
  public void roundValues() {
    Posn p = this.shape.getPosition();
    p.roundValues();
    this.shape.changePosition(p);
  }

  /**
   * Determines if two commands can coexist.
   *
   * @param command The command that this command is being checked against.
   * @return true if these commands can coexist, false otherwise.
   */
  @Override
  public boolean isValid(ICommand command) {
    if (!(this.getShapeName().equals(command.getShapeName()))) {
      return true;
    }
    if (command instanceof MoveShape) {
      return (this.startTime() >= command.endTime()) || (command.startTime() >= this.endTime());
    } else {
      return ((this.startTime() == command.startTime()) && (this.endTime() == command.endTime()))
          || (this.startTime() >= command.endTime() || command.startTime() >= this.endTime());
    }
  }

  /**
   * Simulates this command on a shape and returns a copy of it.
   *
   * @param shape starting position of shape to simulate
   * @return the copy of the shape with its new value after the simulation.
   */
  @Override
  public IShape simulate(IShape shape) {
    IShape shape2 = shape.getCopy();
    shape2.moveTo(newPosn.getX(), newPosn.getY());

    return shape2;

  }

  public String returnComType() {
    return "move";
  }

  public void setOtherType(double type1, double type2) {
    this.newWidth = Math.toIntExact(Math.round(type1));
    this.newHeight = Math.toIntExact(Math.round(type2));
  }

  public double getOtherType1() {
    return this.newWidth;
  }

  public double getOtherType2() {
    return this.newHeight;
  }
}
