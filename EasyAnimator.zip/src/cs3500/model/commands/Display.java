package cs3500.model.commands;

import cs3500.model.shapes.IShape;
import java.util.AbstractMap;
import java.util.Objects;

/**
 * A class to represent a command of type display which performs no actions on the values of its
 * shape.
 */
public class Display extends ACommand {

  /**
   * Constructor that takes in the fields that all command types will have.
   *
   * @param shapes    The list of shapes currently in the model.
   * @param shapeName The name of the shape that this command will be acting on in shapes.
   * @param start     The tick this command starts on.
   * @param end       The tick this command ends on.
   */
  public Display(AbstractMap<String, IShape> shapes, String shapeName, int start, int end) {
    super(shapes, shapeName, start, end);
    this.currTick = start + 1;
  }

  /**
   * Performs one tick on the command. One tick is (1 / (end - start))th of the commands work. The
   * command's shape field is updated with its new values each tick, but nothing changes with a
   * display command.
   */
  @Override
  public void tick() {
    addShape();
  }

  /**
   * Returns a copy of the given ICommand, but is not mutable.
   *
   * @param tree The hashmap to be used as this command's shape list.
   * @return A new ICommand of the same type and with the same values as the given one.
   */
  @Override
  public ICommand getCopy(AbstractMap<String, IShape> tree) {
    Display d1 = new Display(tree, this.shapeName, this.start, this.end);
    d1.setShape(this.getShape().getCopy());
    return d1;
  }

  /**
   * Returns the shape this command is acting upon.
   *
   * @return The shape field of the command.
   */
  @Override
  public IShape getShape() {
    return this.shapes.get(this.shapeName);
  }

  /**
   * Sets this commands shape to be the given shape.
   *
   * @param shape The shape to be used as this commands new shape.
   */
  @Override
  public void setShape(IShape shape) {
    this.shape = shape;
  }

  /**
   * Determines whether a command and an object are equal to one another.
   *
   * @param o The object we are determining if this command is equal to.
   * @return A boolean value stating whether the commmand and object are equal to eachother.
   */
  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (!(o instanceof Display)) {
      return false;
    }
    Display c = (Display) o;
    if (this.shapes.size() != c.shapes.size()) {
      return false;
    }
    for (String s : this.shapes.keySet()) {
      if (!(this.shapes.get(s).equals(c.shapes.get(s)))) {
        return false;
      }
    }
    return this.shapeName.equals(c.shapeName) && this.start == c.start && c.end == this.end;
  }

  /**
   * Overwrites hashcode for our new definition of equals for the command interface.
   *
   * @return The hashcode of the given command.
   */
  @Override
  public int hashCode() {
    return Objects.hash(this.shapeName, this.start, this.end);
  }

  /**
   * Rounds the the x and y coordinates of this commands shape to whole numbers. This shape has no
   * values that change and thus does not need its values rounded.
   */
  @Override
  public void roundValues() {
    //No values for display to round.
  }

  /**
   * Determines if two commands can coexist.
   *
   * @param command The command that this command is being checked against.
   * @return true if these commands can coexist, false otherwise.
   */
  @Override
  public boolean isValid(ICommand command) {

    if (!(this.getShapeName().equals(command.getShapeName()))) {
      return true;
    }
    if (command instanceof Display) {
      return (this.startTime() >= command.endTime()) || (command.startTime() >= this.endTime());
    } else {
      return ((this.startTime() == command.startTime()) && (this.endTime() == command.endTime()))
          || (this.startTime() >= command.endTime() || command.startTime() >= this.endTime());
    }

  }

  /**
   * Returns the given shape as display has no value changing to simulate.
   *
   * @param shape The shape to be returned.
   * @return The given shape.
   */
  @Override
  public IShape simulate(IShape shape) {
    return shape;
  }

  public String returnComType() {
    return "display";
  }

  @Override
  public void setOtherType(double type1, double type2) {
    // Does nothing for display command.
  }

  @Override
  public double getOtherType1() {
    return Integer.MIN_VALUE;
  }

  @Override
  public double getOtherType2() {
    return Integer.MIN_VALUE;
  }

}
