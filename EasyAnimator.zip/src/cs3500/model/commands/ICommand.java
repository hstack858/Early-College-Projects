package cs3500.model.commands;

import cs3500.model.shapes.IShape;
import java.util.AbstractMap;

/**
 * Interface that represents a command for our easy animator.
 */
public interface ICommand {

  /**
   * Performs one tick on the command. One tick is (1 / (end - start))th of the commands work. The
   * command's shape field is updated with its new values each tick, RGB for color, Posn for move,
   * and width and height for transform.
   */
  void tick();

  /**
   * Returns the start time of this command.
   *
   * @return Returns the start field of this command.
   */
  int startTime();

  /**
   * Returns the end time of this command.
   *
   * @return Returns the end field of this command.
   */
  int endTime();

  /**
   * Returns a copy of the given ICommand, but is not mutable.
   *
   * @param tree The hashmap to be used as this command's shape list.
   * @return A new ICommand of the same type and with the same values as the given one.
   */
  ICommand getCopy(AbstractMap<String, IShape> tree);

  /**
   * Returns the shape index of this command.
   *
   * @return The shape index field of the command.
   */
  String getShapeName();

  /**
   * Returns the hashmap of shapes this command has access to.
   *
   * @return The shapes field of the command.
   */
  AbstractMap<String, IShape> getShapes();

  /**
   * Sets the shapes of this command to be the given TreeMap.
   *
   * @param shapes The treemap to be used as a reference.
   */
  void setShapes(AbstractMap<String, IShape> shapes);

  /**
   * Returns the shape this command is acting upon.
   *
   * @return The shape field of this command.
   */
  IShape getShape();

  /**
   * Allows model to set a shape in command to later be added to model when it should be displayed.
   *
   * @param shape shape to be added.
   */
  void setShape(IShape shape);

  /**
   * Determines whether a command and an object are equal to one another.
   *
   * @param o The object we are determining if this command is equal to.
   * @return A boolean value stating whether the commmand and object are equal to eachother.
   */
  boolean equals(Object o);

  /**
   * Overwrites hashcode for our new definition of equals for the command interface.
   *
   * @return The hashcode of the given command.
   */
  int hashCode();

  /**
   * Rounds the relevant fields of each command class from a double to a whole number.
   */
  void roundValues();

  /**
   * Determines if two commands can coexist.
   *
   * @param command The command that this command is being checked against.
   * @return true if these commands can coexist, false otherwise.
   */
  boolean isValid(ICommand command);

  /**
   * Simulates this command on a shape and returns a copy of it.
   *
   * @param shape starting position of shape to simulate
   * @return the copy of the shape with its new value after the simulation.
   */
  IShape simulate(IShape shape);

  /**
   * Takes the hashmap of shapes from the model and updates this command's shape list.
   *
   * @param tree The hashmap of shapes to be added.
   */
  void updateShapes(AbstractMap<String, IShape> tree);

  /**
   * Adds this commands shape to the model.
   */
  void addShape();

  String returnComType();

  void setOtherType(double type1, double type2);

  double getOtherType1();

  double getOtherType2();
}

