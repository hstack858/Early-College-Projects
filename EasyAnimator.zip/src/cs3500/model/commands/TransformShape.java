package cs3500.model.commands;

import cs3500.model.shapes.IShape;
import java.util.AbstractMap;
import java.util.Objects;

/**
 * A class to represent the command that changes a shape's dimensions.
 */
public class TransformShape extends ACommand {

  private final int newWidth;
  private final int newHeight;

  private double newX;
  private double newY;

  private double originalWidth;
  private double originalHeight;

  /**
   * Constructor for transform shape.
   *
   * @param shapes    The list of shapes currently in the model.
   * @param shapeName The name of the shape we will be doing the command on.
   * @param start     The tick this command starts on.
   * @param end       The tick this command ends on.
   * @param newWidth  new width for the shape.
   * @param newHeight new height for the shape.
   */
  public TransformShape(AbstractMap<String, IShape> shapes, String shapeName, int start, int end,
      int newWidth,
      int newHeight) {
    super(shapes, shapeName, start, end);
    this.newWidth = newWidth;
    this.newHeight = newHeight;
    if (newWidth < 0 || newHeight < 0) {
      throw new IllegalArgumentException("Invalid new dimmensions");
    }
    this.currTick = start + 1;
    this.newX = Integer.MIN_VALUE;
    this.newY = Integer.MIN_VALUE;

  }

  /**
   * Performs one tick on the command. One tick is (1 / (end - start))th of the commands work. The
   * command's shape field is updated with its new values each tick, so width and height here.
   */
  @Override
  public void tick() {

    if (this.currTick == this.start + 1) {
      this.originalWidth = this.shapes.get(shapeName).getWidth();
      this.originalHeight = this.shapes.get(shapeName).getHeight();
    }

    this.shape = shapes.get(shapeName);
    double wATween = this.originalWidth *
        (((this.end - this.currTick) * 1.0) / ((this.end - this.start) * 1.0));
    double hATween = this.originalHeight *
        (((this.end - this.currTick) * 1.0) / ((this.end - this.start) * 1.0));
    double wBTween = this.newWidth *
        (((this.currTick - this.start) * 1.0) / ((this.end - this.start) * 1.0));
    double hBTween = this.newHeight *
        (((this.currTick - this.start) * 1.0) / ((this.end - this.start) * 1.0));

    double newWidth = wATween + wBTween;
    double newHeight = hATween + hBTween;
    this.shape.transform(newWidth, newHeight);
    if (this.currTick == this.end) {
      this.roundValues();
    }
    this.shapes.put(this.shapeName, this.shape);
    this.currTick++;
  }

  /**
   * Returns a copy of the given ICommand, but is not mutable.
   *
   * @param tree The hashmap to be used as this command's shape list.
   * @return A new ICommand of the same type and with the same values as the given one.
   */
  public ICommand getCopy(AbstractMap<String, IShape> tree) {
    return new TransformShape(tree, this.shapeName, this.start, this.end,
        this.newWidth, this.newHeight);
  }

  /**
   * Returns the shape this command is acting upon.
   *
   * @return The shape field of the command.
   */
  @Override
  public IShape getShape() {
    return this.shapes.get(this.shapeName);
  }

  /**
   * Sets this commands shape to be the given shape.
   *
   * @param shape The shape to be used as this commands new shape.
   */
  @Override
  public void setShape(IShape shape) {
    this.shape = shape;
  }

  /**
   * Determines whether a command and an object are equal to one another.
   *
   * @param o The object we are determining if this command is equal to.
   * @return A boolean value stating whether the commmand and object are equal to eachother.
   */
  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (!(o instanceof TransformShape)) {
      return false;
    }
    TransformShape trans = (TransformShape) o;
    if (this.shapes.size() != trans.shapes.size()) {
      return false;
    }
    for (String s : this.shapes.keySet()) {
      if (!(this.shapes.get(s).equals(trans.shapes.get(s)))) {
        return false;
      }
    }
    return this.shapeName.equals(trans.shapeName) && this.start == trans.start
        && this.end == trans.end
        && this.newWidth == trans.newWidth && this.newHeight == trans.newHeight;
  }

  /**
   * Overwrites hashcode for our new definition of equals for the command interface.
   *
   * @return The hashcode of the given command.
   */
  @Override
  public int hashCode() {
    return Objects.hash(this.shapeName, this.start, this.end, this.newWidth,
        this.newHeight);
  }

  /**
   * Rounds the shape this command is acting ons width and height to whole numbers.
   */
  @Override
  public void roundValues() {
    this.shape.roundWidthAndHeight();
  }

  /**
   * Determines if two commands can coexist.
   *
   * @param command The command that this command is being checked against.
   * @return true if these commands can coexist, false otherwise.
   */
  @Override
  public boolean isValid(ICommand command) {
    if (!(this.getShapeName().equals(command.getShapeName()))) {
      return true;
    }
    if (command instanceof TransformShape) {
      return (this.startTime() >= command.endTime()) || (command.startTime() >= this.endTime());
    } else {
      return ((this.startTime() == command.startTime()) && (this.endTime() == command.endTime()))
          || (this.startTime() >= command.endTime() || command.startTime() >= this.endTime());
    }
  }

  /**
   * Simulates this command on a shape and returns a copy of it.
   *
   * @param shape starting position of shape to simulate
   * @return the copy of the shape with its new value after the simulation.
   */
  @Override
  public IShape simulate(IShape shape) {
    IShape shape2 = shape.getCopy();
    shape2.transform(newWidth, newHeight);
    return shape2;
  }

  public String returnComType() {
    return "transform";
  }

  public void setOtherType(double type1, double type2) {
    this.newX = type1;
    this.newY = type2;
  }

  public double getOtherType1() {
    return this.newX;
  }

  public double getOtherType2() {
    return this.newY;
  }
}
