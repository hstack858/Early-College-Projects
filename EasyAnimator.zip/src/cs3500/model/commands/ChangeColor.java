package cs3500.model.commands;

import cs3500.model.shapes.IShape;
import cs3500.model.shapes.RGB;
import java.util.AbstractMap;
import java.util.Objects;

/**
 * A class representing the type of command that changes a shapes color to a new RGB value.
 */
public class ChangeColor extends ACommand {

  private RGB rgb;
  private RGB originalRGB;

  /**
   * A constructor that takes in the abstract fields plus the rgb value we want to make this shape.
   *
   * @param shapes    The list of shapes currently in the model.
   * @param shapeName The name of the shape we will be doing the command on.
   * @param start     The tick this command starts on.
   * @param end       The tick this command ends on.
   * @param rgb       The rgb value that dictates the color this shape will become.
   */
  public ChangeColor(AbstractMap<String, IShape> shapes, String shapeName, int start, int end,
      RGB rgb) {
    super(shapes, shapeName, start, end);
    this.rgb = rgb;
    this.currTick = start + 1;
  }

  /**
   * Performs one tick on the command. One tick is (1 / (end - start))th of the commands work. The
   * command's shape field is updated with its new values each tick, so RGB is changed here.
   */
  public void tick() {
    this.shape = shapes.get(shapeName);
    double rATween = originalRGB.getRed() *
        (((this.end - this.currTick) * 1.0) / ((this.end - this.start) * 1.0));
    double gATween = originalRGB.getGreen() *
        (((this.end - this.currTick) * 1.0) / ((this.end - this.start) * 1.0));
    double bATween = originalRGB.getBlue() *
        (((this.end - this.currTick) * 1.0) / ((this.end - this.start) * 1.0));

    double rBTween = this.rgb.getRed() *
        (((this.currTick - this.start) * 1.0) / ((this.end - this.start) * 1.0));
    double gBTween = this.rgb.getGreen() *
        (((this.currTick - this.start) * 1.0) / ((this.end - this.start) * 1.0));
    double bBTween = this.rgb.getBlue() *
        (((this.currTick - this.start) * 1.0) / ((this.end - this.start) * 1.0));

    double newR = rATween + rBTween;
    double newG = gATween + gBTween;
    double newB = bATween + bBTween;
    this.shape.setColor(newR, newG, newB);
    if (this.currTick == this.end) {
      this.roundValues();
    }
    this.shapes.put(this.shapeName, this.shape);
    this.currTick++;
  }

  /**
   * Returns a copy of the given ICommand, but is not mutable.
   *
   * @param tree The hashmap to be used as this command's shape list.
   * @return A new ICommand of the same type and with the same values as the given one.
   */
  public ICommand getCopy(AbstractMap<String, IShape> tree) {
    return new ChangeColor(tree, this.shapeName, this.start, this.end,
        this.rgb.getCopy());
  }

  /**
   * Returns the shape this command is acting upon.
   *
   * @return The shape field of the command.
   */
  public IShape getShape() {
    return this.shapes.get(this.shapeName);
  }

  /**
   * Sets this commands shape to be the given shape.
   *
   * @param shape The shape to be used as this commands new shape.
   */
  @Override
  public void setShape(IShape shape) {
    this.shape = shape;
    this.originalRGB = this.shape.getCopy().getColor();
  }

  /**
   * Determines whether a command and an object are equal to one another.
   *
   * @param o The object we are determining if this command is equal to.
   * @return A boolean value stating whether the commmand and object are equal to eachother.
   */
  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (!(o instanceof ChangeColor)) {
      return false;
    }
    ChangeColor c = (ChangeColor) o;
    if (this.shapes.size() != c.shapes.size()) {
      return false;
    }
    for (String s : this.shapes.keySet()) {
      if (!(this.shapes.get(s).equals(c.shapes.get(s)))) {
        return false;
      }
    }
    return this.shapeName.equals(c.shapeName) && this.start == c.start && c.end == this.end
        && this.rgb.equals(c.rgb);
  }

  /**
   * Overwrites hashcode for our new definition of equals for the command interface.
   *
   * @return The hashcode of the given command.
   */
  @Override
  public int hashCode() {
    return Objects.hash(this.shapeName, this.start, this.end, this.rgb);
  }

  /**
   * Rounds the rgb values of this commands shape to whole numbers.
   */
  @Override
  public void roundValues() {
    this.shape.getColor().roundValues();
  }

  /**
   * Determines if two commands can coexist.
   *
   * @param command The command that this command is being checked against.
   * @return true if these commands can coexist, false otherwise.
   */
  @Override
  public boolean isValid(ICommand command) {
    if (!(this.getShapeName().equals(command.getShapeName()))) {
      return true;
    }
    if (command instanceof ChangeColor) {
      return (this.startTime() >= command.endTime()) || (command.startTime() >= this.endTime());
    } else {
      return ((this.startTime() == command.startTime()) && (this.endTime() == command.endTime()))
          || (this.startTime() >= command.endTime() || command.startTime() >= this.endTime());
    }
  }

  /**
   * Simulates this command on a shape and returns a copy of it.
   *
   * @param shape starting position of shape to simulate
   * @return the copy of the shape with its new value after the simulation.
   */
  @Override
  public IShape simulate(IShape shape) {

    double rToChange = this.rgb.getRed();
    double gToChange = this.rgb.getGreen();
    double bToChange = this.rgb.getBlue();

    IShape shape2 = shape.getCopy();
    shape2.setColor(rToChange, gToChange, bToChange);

    return shape2;
  }

  public String returnComType() {
    return "color";
  }

  public void setOtherType(double type1, double type2) {
    // Does nothing on change color;
  }

  public double getOtherType1() {
    return Integer.MIN_VALUE;
  }

  public double getOtherType2() {
    return Integer.MIN_VALUE;
  }
}
