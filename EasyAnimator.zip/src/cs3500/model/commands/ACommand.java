package cs3500.model.commands;

import cs3500.model.shapes.IShape;
import java.util.AbstractMap;

/**
 * Abstract class that performs methods from ICommand that have the same code for all command
 * types.
 */
public abstract class ACommand implements ICommand {

  protected final int start;
  protected final int end;
  protected AbstractMap<String, IShape> shapes;
  protected String shapeName;
  protected int currTick;
  protected boolean added;
  protected IShape shape;

  /**
   * Constructor that takes in the fields that all command types will have.
   *
   * @param shapes    The list of shapes currently in the model.
   * @param shapeName The name of the shape that this command will be acting on in shapes.
   * @param start     The tick this command starts on.
   * @param end       The tick this command ends on.
   */
  protected ACommand(AbstractMap<String, IShape> shapes, String shapeName, int start, int end) {
    if (shapes == null || !(shapes.containsKey(shapeName)) || start < 0 || end < start) {
      throw new IllegalArgumentException("Invalid command input");
    }

    this.shapes = shapes;
    this.shapeName = shapeName;
    this.start = start;
    this.end = end;
    this.currTick = start;
  }

  /**
   * Performs one tick on the command. One tick is (1 / (end - start))th of the commands work. The
   * command's shape field is updated with its new values each tick, RGB for color, Posn for move,
   * and width and height for transform.
   */
  public abstract void tick();

  /**
   * Returns the start time of this command.
   *
   * @return Returns the start field of this command.
   */
  public int startTime() {
    return this.start;
  }

  /**
   * Returns the end time of this command.
   *
   * @return Returns the end field of this command.
   */
  public int endTime() {
    return this.end;
  }

  /**
   * Returns a copy of the given ICommand, but is not mutable.
   *
   * @param tree The hashmap to be used as this command's shape list.
   * @return A new ICommand of the same type and with the same values as the given one.
   */
  public abstract ICommand getCopy(AbstractMap<String, IShape> tree);

  /**
   * Returns the shape index of this command.
   *
   * @return The shape index field of the command.
   */
  public String getShapeName() {
    return this.shapeName;
  }

  /**
   * Returns the hashmap of shapes this command has access to.
   *
   * @return The shapes field of the command.
   */
  public AbstractMap<String, IShape> getShapes() {
    return this.shapes;
  }

  /**
   * Sets the shapes field of this command to be the given shapes.
   *
   * @param shapes The reference to be used as the shapes field.
   */
  @Override
  public void setShapes(AbstractMap<String, IShape> shapes) {
    this.shapes = shapes;
  }

  /**
   * Returns the shape this command is acting upon.
   *
   * @return The shape field of the command.
   */
  public abstract IShape getShape();

  @Override
  public void setShape(IShape shape) {
    this.shape = shape;
  }

  /**
   * Determines whether a command and an object are equal to one another.
   *
   * @param o The object we are determining if this command is equal to.
   * @return A boolean value stating whether the commmand and object are equal to eachother.
   */
  public abstract boolean equals(Object o);

  /**
   * Overwrites hashcode for our new definition of equals for the command interface.
   *
   * @return The hashcode of the given command.
   */
  public abstract int hashCode();

  /**
   * Rounds the relevant fields of each command class from a double to a whole number.
   */
  public abstract void roundValues();

  /**
   * Determines if two commands can coexist.
   *
   * @param command The command that this command is being checked against.
   * @return true if these commands can coexist, false otherwise.
   */
  public abstract boolean isValid(ICommand command);

  /**
   * Simulates this command on a shape and returns a copy of it.
   *
   * @param shape starting position of shape to simulate
   * @return the copy of the shape with its new value after the simulation.
   */
  public abstract IShape simulate(IShape shape);

  /**
   * Takes the hashmap of shapes from the model and updates this command's shape list.
   *
   * @param tree The hashmap of shapes to be added.
   */
  public void updateShapes(AbstractMap<String, IShape> tree) {
    this.shapes = tree;
  }

  /**
   * Adds this commands shape to its shapes field.
   */
  @Override
  public void addShape() {
    if (!added) {
      shapes.put(this.shape.returnName(), this.shape);
      added = true;
    }
  }

}
