package cs3500.model;

import cs3500.model.commands.ICommand;
import cs3500.model.shapes.IShape;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;

/**
 * Abstract class that abstracts all simple animation behavior for use later on.
 */
public abstract class AbstractAnimationModel implements IAnimationModel {

  protected AbstractMap<String, IShape> shapes;
  protected List<ICommand> toDo;
  protected List<ICommand> inProgress;
  protected List<IShape> shapesInOrder;
  protected Integer ticks = 0;

  protected int x;
  protected int y;
  protected int width;
  protected int height;
  protected int lastTick;

  /**
   * Constructor that takes in every field besides ticks for the AbstractAnimationModel.
   *
   * @param shapes     The shape hashmap for this model with every shape.
   * @param toDo       The list of commands this model still needs to complete.
   * @param inProgress The list of commands this model is currently completing.
   * @param x          BoundingBox x-coordinate.
   * @param y          BoundingBox y-coordinate.
   * @param width      Width of the canvas.
   * @param height     Height of the canvas.
   */
  public AbstractAnimationModel(AbstractMap<String, IShape> shapes, List<ICommand> toDo,
      List<ICommand> inProgress, int x, int y, int width, int height, List<IShape> shapesInOrder) {

    this.shapes = shapes;
    this.toDo = toDo;
    this.inProgress = inProgress;
    this.shapesInOrder = shapesInOrder;

    this.x = x;
    this.y = y;
    this.width = width;
    this.height = height;
  }

  /**
   * Progresses each command in progress by 1 tick.
   */
  public void onTick() {
    if (this.ticks == 0) {
      this.setCopy(this.shapes, this.toDo, this.inProgress, this.x, this.y,
          this.width, this.height, this.shapesInOrder);
    }
    for (ICommand command : toDo) {
      if (command.startTime() == ticks) {
        inProgress.add(command);
      }
    }
    ArrayList<ICommand> commandsToRemove = new ArrayList<ICommand>();
    for (ICommand command : inProgress) {
      if (toDo.contains(command)) {
        toDo.remove(command);
      }
      if (command.endTime() == ticks) {
        command.roundValues();
        this.updateShapes(command);
        for (ICommand com : toDo) {
          com.updateShapes(shapes);
        }
        for (ICommand com : inProgress) {
          com.updateShapes(shapes);
        }
        commandsToRemove.add(command);
      }
    }
    inProgress.removeAll(commandsToRemove);

    if (inProgress.size() > 0) {
      for (ICommand command : inProgress) {
        command.tick();
        this.updateShapes(command);
        for (ICommand c : inProgress) {
          c.updateShapes(this.shapes);
        }
        for (ICommand c : toDo) {
          c.updateShapes(this.shapes);
        }
      }
    }
    ticks = ticks + 1;
  }

  /**
   * Updates the models shapes to be correct after a command.
   *
   * @param c The command who's shapes we are using to update.
   */
  private void updateShapes(ICommand c) {
    this.shapes = c.getShapes();
  }


  /**
   * Adds a command to toDo list.
   *
   * @param command command to be added to toDo commands
   */
  @Override
  public void addCommand(ICommand command) {
    boolean addCommand = true;

    for (ICommand iCommand : this.toDo) {
      addCommand = addCommand && command.isValid(iCommand);
    }

    if (addCommand) {
      this.toDo.add(command);
    } else {
      throw new IllegalArgumentException("Overlapping motions cannot be added");
    }
  }

  /**
   * Adds a shape to the model.
   *
   * @param shapeToAdd shape to be added to model
   */
  @Override
  public void addShape(IShape shapeToAdd) {

    this.shapes.put(shapeToAdd.returnName(), shapeToAdd);

  }

  /**
   * Returns the tick value of the model.
   *
   * @return the current tick value
   */
  @Override
  public int getTick() {
    return ticks;
  }

  /**
   * Runs a command completely iterating through every tick of the command. Returns a copy.
   *
   * @param command to be simulated
   */
  public IShape simulate(ICommand command, IShape shape) {
    return command.simulate(shape);
  }

  /**
   * Finds all of the motions corresponding to a specific shape in a given shape list.
   *
   * @param shape shape to find motions for
   * @return a list of commands associated with a shape
   */
  public List<ICommand> getMotions(IShape shape, AbstractMap<String, IShape> shapes) {

    List<ICommand> motions = new ArrayList<ICommand>();
    for (ICommand command : toDo) {
      if (command.getShapeName().equals(shape.returnName())) {
        ICommand c = command.getCopy(shapes);
        if (command.getOtherType1() >= 0 || command.getOtherType2() >= 0) {
          c.setOtherType(command.getOtherType1(), command.getOtherType2());
        }
        motions.add(c);
      }
    }
    return motions;
  }


  /**
   * Returns the shapes currently in the model.
   *
   * @return a TreeMap of the shapes in the model
   */
  public AbstractMap<String, IShape> getShapes() {
    TreeMap<String, IShape> tree = new TreeMap<String, IShape>();
    Set<String> keys = this.shapes.keySet();
    if (keys != null) {
      for (String s : keys) {
        tree.put(s, this.shapes.get(s).getCopy());
      }
    }
    return tree;
  }

  @Override
  public void setShapes(AbstractMap<String, IShape> shapes) {
    this.shapes = shapes;
  }

  /**
   * Finds the final tick of the program.
   *
   * @return the end tick of the last command to be run
   */
  public int getLastTick() {

    int lastTick = 0;

    if (this.lastTick == 0) {
      if (inProgress.size() == 0) {
        for (ICommand command : toDo) {
          if (command.endTime() > lastTick) {
            lastTick = command.endTime();
          }
        }
      } else {
        for (ICommand command : inProgress) {
          if (command.endTime() > lastTick) {
            lastTick = command.endTime();
          }
        }
      }
      this.lastTick = lastTick;
    }

    return this.lastTick;
  }

  /**
   * Gets this models position.
   *
   * @return The x field of the model.
   */
  @Override
  public int getX() {
    return this.x;
  }

  /**
   * Gets this models position.
   *
   * @return The y field of the model.
   */
  @Override
  public int getY() {
    return this.y;
  }

  /**
   * Gets this models width.
   *
   * @return The width field of this model.
   */
  @Override
  public int getWidth() {
    return this.width;
  }

  /**
   * Gets this models height.
   *
   * @return The height field of this model.
   */
  @Override
  public int getHeight() {
    return this.height;
  }

  /**
   * Gets the current commands in progress.
   *
   * @param shapes The shapes of this model.
   * @return All of the commands of this model that are currently in progress.
   */
  @Override
  public List<ICommand> getInProgress(AbstractMap<String, IShape> shapes) {

    List<ICommand> commands = new ArrayList<ICommand>();

    for (ICommand command : inProgress) {
      commands.add(command.getCopy(shapes));
    }
    return commands;
  }

  @Override
  public List<IShape> getShapesInOrder() {
    List<IShape> shapes = new ArrayList<>();
    for (IShape shape : this.shapesInOrder) {
      shapes.add(shape);
    }
    return shapes;
  }

  @Override
  public void setShapesInOrder(List<IShape> shapes) {
    this.shapesInOrder = shapes;
  }

  @Override
  public abstract void setCopy(AbstractMap<String, IShape> shapes, List<ICommand> toDo,
      List<ICommand> inProgress, int x, int y, int width, int height, List<IShape> shapesInOrder);

  @Override
  public void changeShapeInComs(IShape shapeToChange) {
    for (ICommand c : this.inProgress) {
      if (c.getShapeName().equals(shapeToChange.returnName())) {
        c.setShape(shapeToChange);
      }
    }
    for (ICommand c : this.toDo) {
      if (c.getShapeName().equals(shapeToChange.returnName())) {
        c.setShape(shapeToChange);
      }
    }
  }
}
