package cs3500.model;

import cs3500.model.commands.ICommand;
import cs3500.model.shapes.IShape;
import java.io.IOException;
import java.util.AbstractMap;
import java.util.List;

/**
 * Mock model for testing the controller that writes function calls to log.
 */
public class MockModel implements IAnimationModel {

  private final Appendable log;
  private final int lastTick;

  /**
   * Constructor for mock model that takes log to write to and what this last tick is.
   *
   * @param log      to write to.
   * @param lastTick of the model.
   */
  public MockModel(Appendable log, int lastTick) {
    this.log = log;
    this.lastTick = lastTick;
  }

  @Override
  public void onTick() {
    try {
      log.append("model.onTick()");
    } catch (IOException io) {
      //Making sure that appending to log doesn't crash program.
    }
  }

  @Override
  public void addCommand(ICommand command) {
    //Does nothing in the mock.
  }

  @Override
  public void addShape(IShape shapeToAdd) {
    //Does nothing in the mock.
  }

  @Override
  public int getTick() {
    return 0;
  }

  @Override
  public IShape simulate(ICommand command, IShape shape) {
    return null;
  }

  @Override
  public int getLastTick() {
    return this.lastTick;
  }

  @Override
  public AbstractMap<String, IShape> getShapes() {
    return null;
  }

  @Override
  public void setShapes(AbstractMap<String, IShape> shapes) {
    //Do nothing in mock.
  }

  @Override
  public List<ICommand> getMotions(IShape shape, AbstractMap<String, IShape> shapes) {
    return null;
  }

  @Override
  public int getX() {
    return 0;
  }

  @Override
  public int getY() {
    return 0;
  }

  @Override
  public int getWidth() {
    return 0;
  }

  @Override
  public int getHeight() {
    return 0;
  }

  @Override
  public List<ICommand> getInProgress(AbstractMap<String, IShape> shapes) {
    return null;
  }

  @Override
  public List<IShape> getShapesInOrder() {
    return null;
  }

  @Override
  public void setShapesInOrder(List<IShape> shapes) {
    //Do nothing in mock.
  }

  @Override
  public void setCopy(AbstractMap<String, IShape> shapes, List<ICommand> toDo,
      List<ICommand> inProgress, int x, int y, int width, int height, List<IShape> shapesInOrder) {
    //Does nothing in the mock.
  }

  @Override
  public void resetAnimation() {
    try {
      log.append("model.resetAnimation()");
    } catch (IOException io) {
      //Making sure that appending to log doesn't crash program.
    }
  }

  @Override
  public void changeShapeInComs(IShape shapeToChange) {
    //Do nothing in mock.
  }

  @Override
  public List<IShape> getRenderShapes() {
    return null;
    //Do nothing in mock.
  }


}
