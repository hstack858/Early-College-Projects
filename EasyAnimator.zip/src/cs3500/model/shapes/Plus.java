package cs3500.model.shapes;


import java.util.Objects;

/**
 * A class to represent the plus shape, bounded by square and has two rectangles.
 */
public class Plus extends AShape {

  /**
   * Simple Constructor that takes in only the name of the shape.
   *
   * @param name The string name of the shape.
   */
  public Plus(String name) {
    super(name, null, null, 0.0, 0.0, 0, 0);
  }

  public Plus(String name, Posn position, RGB color,
      double width, double height, int tickAdded, int currTick) {
    super(name, position, color, width, height, tickAdded, currTick);
  }

  /**
   * Checks equality of this object to another object.
   *
   * @param o object to compare this to.
   * @return true if they are the same, false otherwise.
   */
  @Override
  public boolean equals(Object o) {

    if (this == o) {
      return true;
    }

    if (!(o instanceof Plus)) {
      return false;
    }

    Plus that = (Plus) o;

    if (position == null || color == null) {
      return this.name.equals(that.name);
    }

    return this.position.equals(that.position) && this.color.equals(that.color)
        && this.height == that.height && this.width == that.width;

  }

  /**
   * Uses Java's hash function to return a hashcode for this IShape.
   *
   * @return hash value.
   */
  @Override
  public int hashCode() {
    return Objects.hash(this.position, this.color, this.width, this.height);
  }

  /**
   * Gives a string of the type of shape that this shape is.
   *
   * @return A string of the type of shape that this shape is (i.e "oval").
   */
  @Override
  public String returnType() {
    return "plus";
  }

  /**
   * Gives a copy of this shape that can be changed and won't mutate this shape.
   *
   * @return A copy of this shape that can be mutated without fear of mutating this shape.
   */
  @Override
  public IShape getCopy() {
    return new Plus(this.name, new Posn(this.position.getX(), this.position.getY()),
        new RGB(this.color.getRed(), this.color.getBlue(), this.color.getGreen()),
        this.width, this.height, this.tickAdded, this.currTick);
  }
}
