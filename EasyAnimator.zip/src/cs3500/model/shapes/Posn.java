package cs3500.model.shapes;

import java.util.Objects;

/**
 * Class that represents a position with an x and a y.
 */
public class Posn {

  private double x;
  private double y;

  /**
   * Constructor that takes in both parts of the position.
   *
   * @param x The x position for the posn.
   * @param y The y position for the posn.
   */
  public Posn(double x, double y) {
    this.x = x;
    this.y = y;
  }

  /**
   * Checks equality of this Posn to another object.
   *
   * @param o an object compare to this card
   * @return true if they are equal, false otherwise
   */
  public boolean equals(Object o) {

    if (this == o) {
      return true;
    }

    if (!(o instanceof Posn)) {
      return false;
    }

    Posn that = (Posn) o;

    return this.x == that.x && this.y == that.y;

  }

  /**
   * Uses Java's hash function to return a hashcode for this Posn.
   *
   * @return hash value
   */
  public int hashCode() {
    return Objects.hash(this.x, this.y);
  }

  /**
   * Changes the x and y coordinates to be these values.
   *
   * @param x The new X-coordinate.
   * @param y The new Y-coordinate.
   */
  public void moveTo(double x, double y) {
    this.x = x;
    this.y = y;
  }

  /**
   * Makes a new posn object with the values of this posn.
   *
   * @return A new posn object that is equal to this one.
   */
  public Posn getCopy() {
    return new Posn(this.x, this.y);
  }

  /**
   * Gets the x value of this posn.
   *
   * @return The x field of this posn.
   */
  public double getX() {
    return this.x;
  }

  /**
   * Gets the y value of this posn.
   *
   * @return The y field of this posn.
   */
  public double getY() {
    return this.y;
  }

  /**
   * Rounds the values of this posn from decimals to whole numbers.
   */
  public void roundValues() {
    this.x = Math.round(this.x);
    this.y = Math.round(this.y);
  }
}
