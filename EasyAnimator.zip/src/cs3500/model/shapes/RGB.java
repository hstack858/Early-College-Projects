package cs3500.model.shapes;

import java.awt.Color;
import java.util.Objects;

/**
 * Class to represent an RGB color.
 */
public class RGB {

  private double r;
  private double g;
  private double b;

  /**
   * Constructor that takes in all 3 color values.
   *
   * @param r The red value for this color.
   * @param g The green value for this color.
   * @param b The blue value for this color.
   */
  public RGB(double r, double g, double b) {
    if (r > 255 || r < -255 || g > 255 || g < -255 || b > 255 || b < -255) {
      throw new IllegalArgumentException("Invalid Color");
    }
    this.r = r;
    this.g = g;
    this.b = b;
  }

  /**
   * Checks equality of this RGB to another object.
   *
   * @param o an object compare to this card.
   * @return true if they are equal, false otherwise.
   */
  public boolean equals(Object o) {

    if (this == o) {
      return true;
    }

    if (!(o instanceof RGB)) {
      return false;
    }

    RGB that = (RGB) o;

    return this.r == that.r && this.g == that.g && this.b == that.b;

  }

  /**
   * Uses Java's hash function to return a hashcode for this RGB.
   *
   * @return hash value.
   */
  public int hashCode() {
    return Objects.hash(this.r, this.g, this.b);
  }

  /**
   * Gets the red value of this rgb.
   *
   * @return The red field of this rgb.
   */
  public double getRed() {
    return this.r;
  }

  /**
   * Gets the green value of this rgb.
   *
   * @return The green field of this rgb.
   */
  public double getGreen() {
    return this.g;
  }

  /**
   * Gets the blue value of this rgb.
   *
   * @return The blue field of this rgb.
   */
  public double getBlue() {
    return this.b;
  }

  /**
   * Adds the values in this rgb to the values in the given rgb.
   *
   * @param rgb The rgb values to be added to this rgb.
   */
  public void additiveColor(RGB rgb) {
    this.r = this.r + rgb.getRed();
    this.g = this.g + rgb.getGreen();
    this.b = this.b + rgb.getBlue();
  }

  /**
   * Creates a new object copy of this rgb.
   *
   * @return The new object copy of this rgb.
   */
  public RGB getCopy() {
    return new RGB(this.r, this.g, this.b);
  }

  /**
   * Rounds the decimal values of this rgb to whole numbers.
   */
  public void roundValues() {
    this.r = Math.round(this.r);
    this.g = Math.round(this.g);
    this.b = Math.round(this.b);
  }

  /**
   * Sets this RGB color object to new values.
   *
   * @param r red value to set.
   * @param g green value to set.
   * @param b blue value to set.
   */
  public void setColor(double r, double g, double b) {
    this.r = r;
    this.g = g;
    this.b = b;
  }

  /**
   * Converts RGB to Java Color object.
   *
   * @return Color object from this RGBs colors
   */
  public Color toColor() {
    return new Color((int) this.r, (int) this.g, (int) this.b);
  }

}
