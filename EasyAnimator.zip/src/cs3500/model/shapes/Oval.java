package cs3500.model.shapes;

import java.util.Objects;

/**
 * Class to represent circular shapes.
 */
public class Oval extends AShape {

  /**
   * Simple Constructor that takes in only the name of the shape.
   *
   * @param name The string name of the shape.
   */
  public Oval(String name) {
    super(name, null, null, 0.0, 0.0, 0, 0);
  }

  public Oval(String name, Posn position, RGB color, double width, double height, int tickAdded,
      int currTick) {
    super(name, position, color, width, height, tickAdded, currTick);
  }

  /**
   * Checks equality of this object to another object.
   *
   * @param o object to compare this to.
   * @return true if they are the same, false otherwise.
   */
  @Override
  public boolean equals(Object o) {

    if (this == o) {
      return true;
    }

    if (!(o instanceof Oval)) {
      return false;
    }

    Oval that = (Oval) o;

    if (position == null || color == null) {
      return this.name.equals(that.name);
    }

    return this.position.equals(that.position) && this.color.equals(that.color)
        && this.height == that.height && this.width == that.width;

  }

  /**
   * Uses Java's hash function to return a hashcode for this IShape.
   *
   * @return hash value.
   */
  @Override
  public int hashCode() {
    return Objects.hash(this.position, this.color, this.width, this.height);
  }

  /**
   * Gives a string of the type of shape that this shape is.
   *
   * @return A string of the type of shape that this shape is (i.e "oval").
   */
  @Override
  public String returnType() {
    return "oval";
  }

  /**
   * Gives a copy of this shape that can be changed and won't mutate this shape.
   *
   * @return A copy of this shape that can be mutated without fear of mutating this shape.
   */
  @Override
  public Oval getCopy() {
    if (this.position == null || this.color == null) {
      return new Oval(this.name, null, null, this.width,
          this.height, this.tickAdded, this.currTick);
    }
    return new Oval(this.name, this.position.getCopy(), this.color.getCopy(), this.width,
        this.height, this.tickAdded, this.currTick);
  }

}
