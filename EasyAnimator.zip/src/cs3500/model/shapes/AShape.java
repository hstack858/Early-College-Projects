package cs3500.model.shapes;

/**
 * Abstract class to represent the fields common to all IShapes and perform the methods with the
 * same code.
 */
public abstract class AShape implements IShape {

  protected final String name;
  protected Posn position;
  protected RGB color;
  protected double height;
  protected double width;
  protected int tickAdded;
  protected int currTick;

  /**
   * Constructor that takes in every AShape field.
   *
   * @param name      The shape's name.
   * @param position  The shape's Posn.
   * @param color     The shape's Color.
   * @param width     The shape's width.
   * @param height    The shape's height.
   * @param tickAdded The tick this shape was added at.
   * @param currTick  This shape's current tick.
   */
  public AShape(String name, Posn position, RGB color, double width, double height,
      int tickAdded, int currTick) {
    this.name = name;
    this.position = position;
    this.color = color;
    this.height = height;
    this.width = width;
    this.tickAdded = tickAdded;
    this.currTick = currTick;
  }

  /**
   * Changes the position of a shape.
   *
   * @param position The new posn position value this shape will have.
   */
  @Override
  public void changePosition(Posn position) {
    this.position = position;
  }

  /**
   * Gets the position of this shape.
   *
   * @return The position field in posn form of the shape.
   */
  @Override
  public Posn getPosition() {
    if (this.position == null) {
      return null;
    } else {
      return this.position.getCopy();
    }
  }

  /**
   * Accessor for width.
   *
   * @return the width of the shape.
   */
  @Override
  public double getWidth() {
    return width;
  }

  /**
   * Accessor for height.
   *
   * @return the height of the shape.
   */
  @Override
  public double getHeight() {
    return height;
  }

  /**
   * Gets the color of this shape.
   *
   * @return The color field in rgb of this shape.
   */
  @Override
  public RGB getColor() {

    if (this.color == null) {
      return null;
    } else {
      return this.color.getCopy();
    }

  }

  /**
   * Adds a value to this shapes' width value and a value to this shapes' height value.
   *
   * @param amountToAddWidth  The amount to be added to this shapes' width value.
   * @param amountToAddHeight The amount to be added to this shapes' height value.
   */
  @Override
  public void transform(double amountToAddWidth, double amountToAddHeight) {
    this.width = amountToAddWidth;
    this.height = amountToAddHeight;
  }

  /**
   * Adds a value to this shapes' posn's x value and a value to this shapes' posn's y value.
   *
   * @param x The amount to be added to the positions x value.
   * @param y The amount to be added to the positions y value.
   */
  @Override
  public void moveTo(double x, double y) {
    this.position.moveTo(x, y);
  }

  /**
   * Changes this shapes' r, g, and b values by the values in the RGB param by adding them.
   *
   * @param rgb The r, g, and b values that will be added to this shapes' rgb values.
   */
  @Override
  public void changeColor(RGB rgb) {
    this.color.additiveColor(rgb);
  }

  /**
   * Gives a string of the type of shape that this shape is.
   *
   * @return A string of the type of shape that this shape is (i.e "oval").
   */
  @Override
  public abstract String returnType();

  /**
   * Gives the name of this shape.
   *
   * @return The name field of this shape.
   */
  @Override
  public String returnName() {
    return this.name;
  }

  /**
   * Gives a copy of this shape that can be changed and won't mutate this shape.
   *
   * @return A copy of this shape that can be mutated without fear of mutating this shape.
   */
  @Override
  public abstract IShape getCopy();

  /**
   * Outputs a string for the textual view with this shapes' values at the given tick value (tick).
   *
   * @param tick    The tick at which the first set of values should be displayed.
   * @param endTick The end tick of the command to be used for padding purposes.
   * @return The values of the shape at the given tick in String form.
   */
  @Override
  public String toStringAtTick(int tick, int endTick) {
    this.position.roundValues();
    this.color.roundValues();
    this.roundWidthAndHeight();
    int endTickLength = Integer.toString(endTick).length();
    int tickLength = Integer.toString(tick).length();
    int padLength = endTickLength - tickLength;
    String pad = " ";
    while (padLength > 0) {
      pad = pad + " ";
      padLength = padLength - 1;
    }
    String s = Integer.toString(tick) + pad;
    s = s + Double.toString(this.position.getX()) + " ";
    s = s + Double.toString(this.position.getY()) + " ";
    s = s + Double.toString(this.getWidth()) + " ";
    s = s + Double.toString(this.getHeight()) + " ";
    s = s + Double.toString(this.color.getRed()) + " ";
    s = s + Double.toString(this.color.getGreen()) + " ";
    s = s + Double.toString(this.color.getBlue());

    return s;
  }

  /**
   * Rounds the width and height values of this shape to be whole numbers.
   */
  @Override
  public void roundWidthAndHeight() {
    this.width = Math.round(this.width);
    this.height = Math.round(this.height);
  }

  @Override
  public void setColor(double r, double g, double b) {
    this.color.setColor(r, g, b);
  }


  @Override
  public int getStartTick() {
    return this.tickAdded;
  }

  @Override
  public void setWidthAndHeight(double width, double height) {
    this.width = width;
    this.height = height;
  }
}
