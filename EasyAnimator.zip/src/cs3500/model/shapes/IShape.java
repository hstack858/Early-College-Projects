package cs3500.model.shapes;

/**
 * Interface to represent a shape that can be animated with our easy animator.
 */
public interface IShape {

  /**
   * Changes the position of a shape.
   *
   * @param position The new posn position value this shape will have.
   */
  void changePosition(Posn position);

  /**
   * Accessor for width.
   *
   * @return the width of the shape.
   */
  double getWidth();

  /**
   * Accessor for height.
   *
   * @return the height of the shape.
   */
  double getHeight();

  /**
   * Checks equality of this object to another object.
   *
   * @param o object to compare this to.
   * @return true if they are the same, false otherwise.
   */
  boolean equals(Object o);

  /**
   * Uses Java's hash function to return a hashcode for this IShape.
   *
   * @return hash value.
   */
  int hashCode();

  /**
   * Adds a value to this shapes' width value and a value to this shapes' height value.
   *
   * @param amountToAddWidth  The amount to be added to this shapes' width value.
   * @param amountToAddHeight The amount to be added to this shapes' height value.
   */
  void transform(double amountToAddWidth, double amountToAddHeight);

  /**
   * Adds a value to this shapes' posn's x value and a value to this shapes' posn's y value.
   *
   * @param x The amount to be added to the positions x value.
   * @param y The amount to be added to the positions y value.
   */
  void moveTo(double x, double y);

  /**
   * Changes this shapes' r, g, and b values by the values in the RGB param by adding them.
   *
   * @param rgb The r, g, and b values that will be added to this shapes' rgb values.
   */
  void changeColor(RGB rgb);

  /**
   * Gets the position of this shape.
   *
   * @return The position field in posn form of the shape.
   */
  Posn getPosition();

  /**
   * Gets the color of this shape.
   *
   * @return The color field in rgb of this shape.
   */
  RGB getColor();

  /**
   * Gives a string of the type of shape that this shape is.
   *
   * @return A string of the type of shape that this shape is (i.e "oval").
   */
  String returnType();

  /**
   * Gives the name of this shape.
   *
   * @return The name field of this shape.
   */
  String returnName();

  /**
   * Gives a copy of this shape that can be changed and won't mutate this shape.
   *
   * @return A copy of this shape that can be mutated without fear of mutating this shape.
   */
  IShape getCopy();

  /**
   * Outputs a string for the textual view with this shapes' values at the given tick value (tick).
   *
   * @param tick    The tick at which the first set of values should be displayed.
   * @param endTick The end tick of the command to be used for padding purposes.
   * @return The values of the shape at the given tick in String form.
   */
  String toStringAtTick(int tick, int endTick);

  /**
   * Rounds the width and height values of this shape to be whole numbers.
   */
  void roundWidthAndHeight();

  /**
   * Sets the color of this shape to given values.
   *
   * @param r red value to set.
   * @param g green value to set.
   * @param b blue value to set.
   */
  void setColor(double r, double g, double b);

  /**
   * The start tick of this shape.
   *
   * @return The added Tick field.
   */
  int getStartTick();

  void setWidthAndHeight(double width, double height);

}
