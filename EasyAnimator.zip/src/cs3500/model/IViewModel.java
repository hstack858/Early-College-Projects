package cs3500.model;

import cs3500.model.commands.ICommand;
import cs3500.model.shapes.IShape;
import java.util.AbstractMap;
import java.util.List;

/**
 * Read only version of the model to be passed to view so that it can't modify model.
 */
public interface IViewModel {

  /**
   * Returns the tick value of the model.
   *
   * @return the current tick value
   */
  int getTick();

  /**
   * Runs a command completely iterating through every tick of the command. Returns a copy.
   *
   * @param command to be simulated
   */
  IShape simulate(ICommand command, IShape shape);

  /**
   * Finds the final tick of the program.
   *
   * @return the end tick of the last command to be run
   */
  int getLastTick();

  /**
   * Returns the shapes currently in the model.
   *
   * @return a hashmap of shapes in the model and their name
   */
  AbstractMap<String, IShape> getShapes();

  /**
   * Finds all of the motions corresponding to a specific shape in a given shape list.
   *
   * @param shape shape to find motions for
   * @return a list of commands associated with a shape
   */
  List<ICommand> getMotions(IShape shape, AbstractMap<String, IShape> shapes);

  /**
   * Gets leftmost x value.
   *
   * @return leftmost x value
   */
  int getX();

  /**
   * Gets topmost y value.
   *
   * @return topmost y value
   */
  int getY();

  /**
   * Gets width of bounding box.
   *
   * @return returns width of bounding box
   */
  int getWidth();

  /**
   * Gets height of bounding box.
   *
   * @return returns height of bounding box
   */
  int getHeight();

  /**
   * Sorts a list of commands by start time into a hashmap from start time into list of commands.
   *
   * @param coms The commands to be sorted.
   * @return A hashmap from start time to a list of commands that have that start time.
   */
  AbstractMap<Integer, List<ICommand>> startTree(List<ICommand> coms);

  /**
   * Gets the commands in progress.
   *
   * @return list of commands in progress.
   */
  List<ICommand> getInProgress(AbstractMap<String, IShape> shapes);

  /**
   * Gets list of shapes in order.
   *
   * @return returns list of shapes in order.
   */
  List<IShape> getShapesInOrder();

  /**
   * Gets shapes to be rendered.
   *
   * @return shapes to be rendered
   */
  List<IShape> getRenderShapes();

}
