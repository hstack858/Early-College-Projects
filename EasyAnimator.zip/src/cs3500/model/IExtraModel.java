package cs3500.model;

import java.util.Set;

/**
 * Interface to represent the model classes that can be used with the EC features.
 */
public interface IExtraModel extends IAnimationModel {

  Set<Integer> getTimeSet();

}
