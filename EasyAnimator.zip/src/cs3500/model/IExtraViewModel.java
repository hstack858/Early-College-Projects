package cs3500.model;

/**
 * Interface to represent the view model classes that can support EC features.
 */
public interface IExtraViewModel extends IViewModel {

}
