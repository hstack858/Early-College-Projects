package cs3500.model;

import cs3500.model.commands.ICommand;
import cs3500.model.shapes.IShape;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

/**
 * A model that represents an animation that cannot have its fields mutated. This prevents unwanted
 * mutation from occuring outside of the model.
 */
public class SimpleViewModel implements IViewModel {

  IAnimationModel model;

  /**
   * A constructor that takes in a normal model that will give this model its information, but
   * cannot be mutated.
   *
   * @param model The model that ticks through its data and runs the animation.
   */
  public SimpleViewModel(IAnimationModel model) {
    this.model = model;
  }

  /**
   * Returns the tick value of the model.
   *
   * @return the current tick value
   */
  @Override
  public int getTick() {
    return this.model.getTick();
  }

  /**
   * Runs a command completely iterating through every tick of the command. Returns a copy.
   *
   * @param command to be simulated
   */
  @Override
  public IShape simulate(ICommand command, IShape shape) {
    return this.model.simulate(command, shape);
  }

  /**
   * Finds the final tick of the program.
   *
   * @return the end tick of the last command to be run
   */
  @Override
  public int getLastTick() {
    return this.model.getLastTick();
  }

  /**
   * Returns the shapes currently in the model.
   *
   * @return a hashmap of shapes in the model and their name
   */
  @Override
  public AbstractMap<String, IShape> getShapes() {
    return this.model.getShapes();
  }

  /**
   * Finds all of the motions corresponding to a specific shape in a given shape list.
   *
   * @param shape shape to find motions for
   * @return a list of commands associated with a shape
   */
  @Override
  public List<ICommand> getMotions(IShape shape, AbstractMap<String, IShape> shapes) {
    return this.model.getMotions(shape, this.model.getShapes());
  }

  /**
   * Gets leftmost x value.
   *
   * @return leftmost x value
   */
  @Override
  public int getX() {
    return this.model.getX();
  }

  /**
   * Gets topmost y value.
   *
   * @return topmost y value
   */
  @Override
  public int getY() {
    return this.model.getY();
  }

  /**
   * Gets width of bounding box.
   *
   * @return returns width of bounding box.
   */
  @Override
  public int getWidth() {
    return this.model.getWidth();
  }

  /**
   * Gets height of bounding box.
   *
   * @return returns height of bounding box.
   */
  @Override
  public int getHeight() {
    return this.model.getHeight();
  }

  /**
   * Sorts a list of commands by start time into a hashmap from start time into list of commands.
   *
   * @param coms The commands to be sorted.
   * @return A hashmap from start time to a list of commands that have that start time.
   */
  public AbstractMap<Integer, List<ICommand>> startTree(List<ICommand> coms) {
    TreeMap<Integer, List<ICommand>> finTree = new TreeMap<Integer, List<ICommand>>();
    for (ICommand com : coms) {
      if (finTree.keySet().contains(com.startTime())) {
        finTree.get(com.startTime()).add(com);
      } else {
        List<ICommand> oneCom = new ArrayList<ICommand>();
        oneCom.add(com);
        finTree.put(com.startTime(), oneCom);
      }
    }
    return finTree;
  }

  @Override
  public List<ICommand> getInProgress(AbstractMap<String, IShape> shapes) {
    return this.model.getInProgress(shapes);
  }

  @Override
  public List<IShape> getShapesInOrder() {
    return this.model.getShapesInOrder();
  }

  @Override
  public List<IShape> getRenderShapes() {
    return this.model.getRenderShapes();
  }

}
