package cs3500.model;

/**
 * A class to represent the simple view model that can be used with the EC features.
 */
public class ExtraViewModel extends SimpleViewModel implements IExtraViewModel {

  /**
   * A constructor that takes in a normal model that will give this model its information, but
   * cannot be mutated.
   *
   * @param model The model that ticks through its data and runs the animation.
   */
  public ExtraViewModel(IAnimationModel model) {
    super(model);
  }
}
