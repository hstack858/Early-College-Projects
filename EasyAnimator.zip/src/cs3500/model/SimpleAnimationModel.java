package cs3500.model;

import cs3500.animator.util.AnimationBuilder;
import cs3500.model.commands.ChangeColor;
import cs3500.model.commands.Display;
import cs3500.model.commands.ICommand;
import cs3500.model.commands.MoveShape;
import cs3500.model.commands.TransformShape;
import cs3500.model.shapes.IShape;
import cs3500.model.shapes.Oval;
import cs3500.model.shapes.Plus;
import cs3500.model.shapes.Posn;
import cs3500.model.shapes.RGB;
import cs3500.model.shapes.Rectangle;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.TreeMap;

/**
 * A model that employs the builder design pattern in order to create an animation model from the
 * Animation Reader.
 */
public class SimpleAnimationModel extends AbstractAnimationModel {

  SimpleAnimationModel modelCopy;

  /**
   * A Constructor that takes in every field for the SimpleAnimationModel.
   *
   * @param shapes     The shape hashmap for this model with every shape.
   * @param toDo       The list of commands this model still needs to complete.
   * @param inProgress The list of commands this model is currently completing.
   * @param x          The leftmost x value.
   * @param y          The topmost y value.
   * @param width      The width of the bounding box.
   * @param height     The height of the bounding box.
   */
  public SimpleAnimationModel(AbstractMap<String, IShape> shapes, List<ICommand> toDo,
      List<ICommand> inProgress, int x, int y, int width, int height, List<IShape> shapesInOrder) {
    super(shapes, toDo, inProgress, x, y, width, height, shapesInOrder);
  }

  /**
   * Sets this model's modelCopy to be a model with the given values.
   *
   * @param shapes        Shapes field.
   * @param toDo          ToDo field.
   * @param inProgress    InProgress field.
   * @param x             X field.
   * @param y             Y field.
   * @param width         Width field.
   * @param height        Height field.
   * @param shapesInOrder ShapesInOrder field.
   */
  @Override
  public void setCopy(AbstractMap<String, IShape> shapes, List<ICommand> toDo,
      List<ICommand> inProgress, int x, int y, int width, int height, List<IShape> shapesInOrder) {

    List<ICommand> newToDo = new ArrayList<>();
    AbstractMap<String, IShape> newShapes = this.getShapes();

    List<IShape> shapesInOrder2 = new ArrayList<IShape>();

    int index = 0;
    while (shapesInOrder2.size() < shapesInOrder.size()) {
      for (String s : newShapes.keySet()) {
        if (shapesInOrder.get(index).returnName().equals(s)) {
          shapesInOrder2.add(newShapes.get(s));
        }
      }
      index++;
    }

    for (ICommand c : toDo) {
      ICommand c2 = c.getCopy(newShapes);
      String comShapeName = c.getShapeName();
      for (String s : newShapes.keySet()) {
        if (s.equals(comShapeName)) {
          c2.setShape(newShapes.get(s));
        }
      }
      newToDo.add(c2);
    }

    this.modelCopy = new SimpleAnimationModel(newShapes, newToDo, inProgress, x, y, width, height,
        shapesInOrder2);
  }

  /**
   * Resets this animations fields to be their original values.
   */
  public void resetAnimation() {
    this.shapes = modelCopy.getShapes();
    this.toDo = modelCopy.toDo;
    this.inProgress = new ArrayList<ICommand>();
    this.shapesInOrder = modelCopy.getShapesInOrder();
    if (this.ticks < this.getLastTick()) {
      this.ticks = -1;
    } else {
      this.ticks = 0;
    }
    this.x = modelCopy.getX();
    this.y = modelCopy.getY();
    this.width = modelCopy.getWidth();
    this.height = modelCopy.getHeight();
    this.lastTick = modelCopy.getLastTick();
    this.modelCopy = null;
  }

  @Override
  public List<IShape> getRenderShapes() {

    List<IShape> renderShapes = new ArrayList<>();

    if (this.shapes != null) {
      for (IShape shape : this.shapes.values()) {
        if (shape.getStartTick() <= this.ticks) {
          for (ICommand c : inProgress) {
            if (c.getShapeName().equals(shape.returnName()) && !renderShapes.contains(shape)) {
              if (!(shape.getPosition() == null || shape.getColor() == null)) {
                renderShapes.add(shape.getCopy());
              }
            }
          }
        }
      }
    }

    return renderShapes;

  }

  /**
   * Builder class that creates the SimpleAnimationModel that will be ticked through during the
   * animation.
   */
  public static final class Builder implements AnimationBuilder<IAnimationModel> {

    int x;
    int y;
    int width;
    int height;
    List<String> added = new ArrayList<String>();

    AbstractMap<String, IShape> shapes = new TreeMap<String, IShape>();
    List<IShape> shapesInOrder = new ArrayList<IShape>();
    List<ICommand> toDo = new ArrayList<ICommand>();
    List<ICommand> inProgress = new ArrayList<ICommand>();

    /**
     * The method that returns the SimpleAnimationModel when all of its contents have been added.
     *
     * @return The SimpleAnimationModel that will be ticked through during the animation.
     */
    @Override
    public IAnimationModel build() {
      AbstractMap<String, List<ICommand>> shapeComs = new TreeMap<>();
      this.toDo = this.startSort(this.toDo);
      for (ICommand c : toDo) {
        if (shapeComs.containsKey(c.getShapeName())) {
          shapeComs.get(c.getShapeName()).add(c);
        } else {
          List<ICommand> coms = new ArrayList<>();
          coms.add(c);
          shapeComs.put(c.getShapeName(), coms);
        }
      }
      return new SimpleAnimationModel(this.shapes, this.startSort(toDo), inProgress,
          this.x, this.y, this.width, this.height, this.shapesInOrder);
    }


    /**
     * Sorts the given commands in order of start time.
     *
     * @param coms The commands to be sorted.
     * @return The list of commands sorted in order of start time.
     */
    public List<ICommand> startSort(List<ICommand> coms) {
      AbstractMap<Integer, List<ICommand>> tree = this.startTree(coms);
      List<ICommand> finList = new ArrayList<ICommand>();
      while (tree.size() > 0) {
        int minVal = Collections.min(tree.keySet());
        finList.addAll(tree.get(minVal));
        tree.remove(minVal);
      }
      return finList;

    }

    /**
     * Sorts a list of commands by start time into a hashmap from start time into list of commands.
     *
     * @param coms The commands to be sorted.
     * @return A hashmap from start time to a list of commands that have that start time.
     */
    private AbstractMap<Integer, List<ICommand>> startTree(List<ICommand> coms) {
      TreeMap<Integer, List<ICommand>> finTree = new TreeMap<Integer, List<ICommand>>();
      for (ICommand com : coms) {
        if (finTree.keySet().contains(com.startTime())) {
          finTree.get(com.startTime()).add(com);
        } else {
          List<ICommand> oneCom = new ArrayList<ICommand>();
          oneCom.add(com);
          finTree.put(com.startTime(), oneCom);
        }
      }
      return finTree;
    }

    /**
     * Changes the bounds of this animation model.
     *
     * @param x      The leftmost x value.
     * @param y      The topmost y value.
     * @param width  The width of the bounding box.
     * @param height The height of the bounding box.
     * @return This animation model with its bounds changed.
     */
    @Override
    public AnimationBuilder<IAnimationModel> setBounds(int x, int y, int width, int height) {

      this.x = x;
      this.y = y;
      this.width = width;
      this.height = height;

      return this;
    }

    /**
     * Creates a shape to be added to this model.
     *
     * @param name The unique name of the shape to be added. No shape with this name should already
     *             exist.
     * @param type The type of shape (e.g. "ellipse", "rectangle") to be added. The set of supported
     *             shapes is unspecified, but should include "ellipse" and "rectangle" as a
     *             minimum.
     * @return This model with the given shape now a part of it.
     */
    @Override
    public AnimationBuilder<IAnimationModel> declareShape(String name, String type) {

      IShape shape = null;

      if (!(added.contains(name))) {
        added.add(name);
        if (type.equals("rectangle")) {
          shape = new Rectangle(name);
        } else if (type.equals("ellipse")) {
          shape = new Oval(name);
        } else {
          throw new IllegalArgumentException("Unsupported shape type");
        }
        shapes.put(name, shape);
      }

      this.shapesInOrder.add(shape);

      return this;
    }

    /**
     * Adds a command to this model.
     *
     * @param name The name of the shape (added with {@link AnimationBuilder#declareShape})
     * @param t1   The start time of this transformation
     * @param x1   The initial x-position of the shape
     * @param y1   The initial y-position of the shape
     * @param w1   The initial width of the shape
     * @param h1   The initial height of the shape
     * @param r1   The initial red color-value of the shape
     * @param g1   The initial green color-value of the shape
     * @param b1   The initial blue color-value of the shape
     * @param t2   The end time of this transformation
     * @param x2   The final x-position of the shape
     * @param y2   The final y-position of the shape
     * @param w2   The final width of the shape
     * @param h2   The final height of the shape
     * @param r2   The final red color-value of the shape
     * @param g2   The final green color-value of the shape
     * @param b2   The final blue color-value of the shape
     * @return This model with the command added to it.
     */
    @Override
    public AnimationBuilder<IAnimationModel> addMotion(String name, int t1, int x1, int y1, int w1,
        int h1, int r1, int g1, int b1, int t2, int x2, int y2, int w2, int h2, int r2, int g2,
        int b2) {

      x1 = x1 - this.x;
      y1 = y1 - this.y;
      x2 = x2 - this.x;
      y2 = y2 - this.y;

      List<ICommand> comsInOrder = this.startSort(this.toDo);
      List<ICommand> comsInOrderShape = new ArrayList<ICommand>();
      boolean inComs = false;
      IShape shape;
      ICommand command;

      for (ICommand com : comsInOrder) {
        if (com.getShapeName().equals(name)) {
          inComs = true;
          comsInOrderShape.add(com);
        }
      }

      if (comsInOrder.size() == 0 || comsInOrderShape.size() == 0 ||
          !(inComs) && t1 < comsInOrderShape.get(0).startTime()) {

        if (shapes.get(name) instanceof Rectangle) {
          shape = new Rectangle(name, new Posn(x1, y1), new RGB(r1, g1, b1), w1, h1,
              t1, t1);
        } else if (shapes.get(name) instanceof Oval) {
          shape = new Oval(name, new Posn(x1, y1), new RGB(r1, g1, b1), w1, h1,
              t1, t1);
        } else if (shapes.get(name) instanceof Plus) {
          shape = new Plus(name, new Posn(x1, y1), new RGB(r1, g1, b1), w1, h1,
              t1, t1);
        } else {
          throw new IllegalArgumentException("Currently unsupported shape type");
        }
        shapes.put(name, shape);
      } else {
        shape = comsInOrderShape.get(0).getShape();
      }

      int count = 0;
      if (x1 != x2 || y1 != y2) {
        command = new MoveShape(this.shapes, name, t1, t2, new Posn(x2, y2));
        command.setShape(shape);
        this.toDo.add(command);
        count++;
      }
      if (w1 != w2 || h1 != h2) {
        command = new TransformShape(this.shapes, name, t1, t2, w2, h2);
        command.setShape(shape);
        this.toDo.add(command);
        count++;
      }
      if (r1 != r2 || g1 != g2 || b1 != b2) {
        command = new ChangeColor(this.shapes, name, t1, t2, new RGB(r2, g2, b2));
        command.setShape(shape);
        this.toDo.add(command);
        count++;
      }
      if (count == 0) {
        if (t1 == 1 && t2 == 1) {
          shapes.put(name, shape);
        } else {
          command = new Display(this.shapes, name, t1, t2);
          command.setShape(shape);
          this.toDo.add(command);
        }
      }
      return this;
    }
  }
}
