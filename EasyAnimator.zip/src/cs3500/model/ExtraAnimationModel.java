package cs3500.model;

import cs3500.animator.util.AnimationBuilder;
import cs3500.model.commands.ChangeColor;
import cs3500.model.commands.Display;
import cs3500.model.commands.ICommand;
import cs3500.model.commands.MoveShape;
import cs3500.model.commands.TransformShape;
import cs3500.model.shapes.IShape;
import cs3500.model.shapes.Oval;
import cs3500.model.shapes.Plus;
import cs3500.model.shapes.Posn;
import cs3500.model.shapes.RGB;
import cs3500.model.shapes.Rectangle;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;

/**
 * A class to represent a simple model that can be used with the EC features.
 */
public class ExtraAnimationModel extends SimpleAnimationModel implements IExtraModel {


  /**
   * A Constructor that takes in every field for the SimpleAnimationModel.
   *
   * @param shapes        The shape hashmap for this model with every shape.
   * @param toDo          The list of commands this model still needs to complete.
   * @param inProgress    The list of commands this model is currently completing.
   * @param x             The leftmost x value.
   * @param y             The topmost y value.
   * @param width         The width of the bounding box.
   * @param height        The height of the bounding box.
   * @param shapesInOrder The shapes in order.
   */
  public ExtraAnimationModel(
      AbstractMap<String, IShape> shapes,
      List<ICommand> toDo,
      List<ICommand> inProgress, int x, int y, int width, int height,
      List<IShape> shapesInOrder) {
    super(shapes, toDo, inProgress, x, y, width, height, shapesInOrder);
  }

  @Override
  public Set<Integer> getTimeSet() {
    Set<Integer> times = new HashSet<Integer>();
    for (String s : this.getShapes().keySet()) {
      IShape shape = this.getShapes().get(s);
      for (ICommand c : this.getMotions(shape, this.getShapes())) {
        times.add(c.startTime());
        times.add(c.endTime());
      }
    }
    return times;
  }

  /**
   * Builder class that creates the SimpleAnimationModel that will be ticked through during the
   * animation.
   */
  public static final class Builder implements AnimationBuilder<IExtraModel> {

    int x;
    int y;
    int width;
    int height;
    List<String> added = new ArrayList<String>();

    AbstractMap<String, IShape> shapes = new TreeMap<String, IShape>();
    List<IShape> shapesInOrder = new ArrayList<IShape>();
    List<ICommand> toDo = new ArrayList<ICommand>();
    List<ICommand> inProgress = new ArrayList<ICommand>();

    /**
     * The method that returns the SimpleAnimationModel when all of its contents have been added.
     *
     * @return The SimpleAnimationModel that will be ticked through during the animation.
     */
    @Override
    public ExtraAnimationModel build() {
      AbstractMap<String, List<ICommand>> shapeComs = new TreeMap<>();
      this.toDo = this.startSort(this.toDo);
      for (ICommand c : toDo) {
        if (shapeComs.containsKey(c.getShapeName())) {
          shapeComs.get(c.getShapeName()).add(c);
        } else {
          List<ICommand> coms = new ArrayList<>();
          coms.add(c);
          shapeComs.put(c.getShapeName(), coms);
        }
      }
      return new ExtraAnimationModel(this.shapes, this.startSort(toDo), inProgress,
          this.x, this.y, this.width, this.height, this.shapesInOrder);
    }


    /**
     * Sorts the given commands in order of start time.
     *
     * @param coms The commands to be sorted.
     * @return The list of commands sorted in order of start time.
     */
    public List<ICommand> startSort(List<ICommand> coms) {
      AbstractMap<Integer, List<ICommand>> tree = this.startTree(coms);
      List<ICommand> finList = new ArrayList<ICommand>();
      while (tree.size() > 0) {
        int minVal = Collections.min(tree.keySet());
        finList.addAll(tree.get(minVal));
        tree.remove(minVal);
      }
      return finList;

    }

    /**
     * Sorts a list of commands by start time into a hashmap from start time into list of commands.
     *
     * @param coms The commands to be sorted.
     * @return A hashmap from start time to a list of commands that have that start time.
     */
    private AbstractMap<Integer, List<ICommand>> startTree(List<ICommand> coms) {
      TreeMap<Integer, List<ICommand>> finTree = new TreeMap<Integer, List<ICommand>>();
      for (ICommand com : coms) {
        if (finTree.keySet().contains(com.startTime())) {
          finTree.get(com.startTime()).add(com);
        } else {
          List<ICommand> oneCom = new ArrayList<ICommand>();
          oneCom.add(com);
          finTree.put(com.startTime(), oneCom);
        }
      }
      return finTree;
    }

    /**
     * Changes the bounds of this animation model.
     *
     * @param x      The leftmost x value.
     * @param y      The topmost y value.
     * @param width  The width of the bounding box.
     * @param height The height of the bounding box.
     * @return This animation model with its bounds changed.
     */
    @Override
    public AnimationBuilder<IExtraModel> setBounds(int x, int y, int width, int height) {

      this.x = x;
      this.y = y;
      this.width = width;
      this.height = height;

      return this;
    }

    /**
     * Creates a shape to be added to this model.
     *
     * @param name The unique name of the shape to be added. No shape with this name should already
     *             exist.
     * @param type The type of shape (e.g. "ellipse", "rectangle") to be added. The set of supported
     *             shapes is unspecified, but should include "ellipse" and "rectangle" as a
     *             minimum.
     * @return This model with the given shape now a part of it.
     */
    @Override
    public AnimationBuilder<IExtraModel> declareShape(String name, String type) {

      IShape shape = null;

      if (!(added.contains(name))) {
        added.add(name);
        if (type.equals("rectangle")) {
          shape = new Rectangle(name);
        } else if (type.equals("ellipse")) {
          shape = new Oval(name);
        } else if (type.equals("plus")) {
          shape = new Plus(name);
        } else {
          throw new IllegalArgumentException("Unsupported shape type");
        }
        shapes.put(name, shape);
      }

      this.shapesInOrder.add(shape);

      return this;
    }

    /**
     * Adds a command to this model.
     *
     * @param name The name of the shape (added with {@link AnimationBuilder#declareShape})
     * @param t1   The start time of this transformation
     * @param x1   The initial x-position of the shape
     * @param y1   The initial y-position of the shape
     * @param w1   The initial width of the shape
     * @param h1   The initial height of the shape
     * @param r1   The initial red color-value of the shape
     * @param g1   The initial green color-value of the shape
     * @param b1   The initial blue color-value of the shape
     * @param t2   The end time of this transformation
     * @param x2   The final x-position of the shape
     * @param y2   The final y-position of the shape
     * @param w2   The final width of the shape
     * @param h2   The final height of the shape
     * @param r2   The final red color-value of the shape
     * @param g2   The final green color-value of the shape
     * @param b2   The final blue color-value of the shape
     * @return This model with the command added to it.
     */
    @Override
    public AnimationBuilder<IExtraModel> addMotion(String name, int t1, int x1, int y1, int w1,
        int h1, int r1, int g1, int b1, int t2, int x2, int y2, int w2, int h2, int r2, int g2,
        int b2) {

      x1 = x1 - this.x;
      y1 = y1 - this.y;
      x2 = x2 - this.x;
      y2 = y2 - this.y;

      List<ICommand> comsInOrder = this.startSort(this.toDo);
      List<ICommand> comsInOrderShape = new ArrayList<ICommand>();
      boolean inComs = false;
      IShape shape;
      ICommand command;

      for (ICommand com : comsInOrder) {
        if (com.getShapeName().equals(name)) {
          inComs = true;
          comsInOrderShape.add(com);
        }
      }

      if (comsInOrder.size() == 0 || comsInOrderShape.size() == 0 ||
          !(inComs) && t1 < comsInOrderShape.get(0).startTime()) {

        if (shapes.get(name) instanceof Rectangle) {
          shape = new Rectangle(name, new Posn(x1, y1), new RGB(r1, g1, b1), w1, h1,
              t1, t1);
        } else if (shapes.get(name) instanceof Oval) {
          shape = new Oval(name, new Posn(x1, y1), new RGB(r1, g1, b1), w1, h1,
              t1, t1);
        } else if (shapes.get(name) instanceof Plus) {
          shape = new Plus(name, new Posn(x1, y1), new RGB(r1, g1, b1), w1, h1,
              t1, t1);
        } else {
          throw new IllegalArgumentException("Currently unsupported shape type");
        }
        shapes.put(name, shape);
      } else {
        shape = comsInOrderShape.get(0).getShape();
      }

      boolean moveShape = false;
      boolean transShape = false;
      boolean colorShape = false;
      boolean displayShape = false;
      ICommand command1 = null;
      ICommand command2 = null;
      ICommand command3 = null;
      ICommand command4 = null;
      int count = 0;
      if (x1 != x2 || y1 != y2) {
        command1 = new MoveShape(this.shapes, name, t1, t2, new Posn(x2, y2));
        command1.setShape(shape);
        count++;
        moveShape = true;
      }
      if (w1 != w2 || h1 != h2) {
        command2 = new TransformShape(this.shapes, name, t1, t2, w2, h2);
        command2.setShape(shape);

        count++;
        transShape = true;
        if (transShape && moveShape) {
          if (w1 != w2 && h1 != h2) {
            command1.setOtherType(w2, h2);
          } else if (w1 != w2) {
            command1.setOtherType(w2, Integer.MIN_VALUE);
          } else {
            command1.setOtherType(Integer.MIN_VALUE, h2);
          }
          if (x1 != x2 && y1 != y2) {
            command2.setOtherType(x2, y2);
          } else if (x1 != x2) {
            command2.setOtherType(x2, Integer.MIN_VALUE);
          } else {
            command2.setOtherType(Integer.MIN_VALUE, y2);
          }
        }
      }
      if (r1 != r2 || g1 != g2 || b1 != b2) {
        command3 = new ChangeColor(this.shapes, name, t1, t2, new RGB(r2, g2, b2));
        command3.setShape(shape);
        count++;
        colorShape = true;
      }
      if (count == 0) {
        if (t1 == 1 && t2 == 1) {
          shapes.put(name, shape);
        } else {
          command4 = new Display(this.shapes, name, t1, t2);
          command4.setShape(shape);
          displayShape = true;
        }
      }
      if (moveShape) {
        this.toDo.add(command1);
      }
      if (transShape) {
        this.toDo.add(command2);
      }
      if (colorShape) {
        this.toDo.add(command3);
      }
      if (displayShape) {
        this.toDo.add(command4);
      }
      return this;
    }
  }
}

