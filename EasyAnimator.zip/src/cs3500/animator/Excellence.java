package cs3500.animator;

import cs3500.animator.util.AnimationReader;
import cs3500.animator.util.IntervalReader;
import cs3500.animator.view.AnimationSVGView;
import cs3500.animator.view.AnimationTextualView;
import cs3500.animator.view.AnimationVisualView;
import cs3500.animator.view.ExtraInteractiveView;
import cs3500.animator.view.ExtraSVGView;
import cs3500.animator.view.ExtraTextualView;
import cs3500.animator.view.ExtraVisualView;
import cs3500.animator.view.IAnimationView;
import cs3500.animator.view.SimpleInteractiveView;
import cs3500.controller.AnimationController;
import cs3500.controller.ExtraAnimationController;
import cs3500.controller.IAnimationController;
import cs3500.model.ExtraAnimationModel;
import cs3500.model.ExtraViewModel;
import cs3500.model.IAnimationModel;
import cs3500.model.IExtraModel;
import cs3500.model.IExtraViewModel;
import cs3500.model.IViewModel;
import cs3500.model.SimpleAnimationModel;
import cs3500.model.SimpleViewModel;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Map;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 * Main file that runs program taking in command line arguments that specify type of animation to
 * run.
 */
public final class Excellence {

  /**
   * Main method that executes program.
   *
   * @param args command line arguments.
   */
  public static void main(String[] args) {

    Appendable ap = System.out;
    Readable rd = null;
    Readable intervalsRD = null;

    AnimationType type = null;
    int tempo = 1;

    boolean outFile = false;
    boolean features = false;
    boolean fill = true;

    Map<Integer, Integer> intervals = null;

    //loop through the arguments
    //FileWriter writer = null;
    for (int i = 0; i < args.length; i++) {

      //check if view specifier
      if (args[i].equalsIgnoreCase("-view")) {

        checkNextArg(args, i);

        //check type of view
        if (args[i + 1].equalsIgnoreCase("text")) {
          type = AnimationType.TEXT;
        } else if (args[i + 1].equalsIgnoreCase("visual")) {
          type = AnimationType.VISUAL;
        } else if (args[i + 1].equalsIgnoreCase("svg")) {
          type = AnimationType.SVG;
        } else if (args[i + 1].equalsIgnoreCase("interactive")) {
          type = AnimationType.INTERACTIVE;
        } else if (args[i + 1].equalsIgnoreCase("provider")) {
          type = AnimationType.PROVIDER;
        } else {
          showError("Invalid view type");
        }

        i++;

        //check if input specifier
      } else if (args[i].equalsIgnoreCase("-in")) {

        checkNextArg(args, i);

        try {
          rd = new FileReader(args[i + 1]);
        } catch (FileNotFoundException f) {
          showError("File could not be read");
        }

        i++;

      } else if (args[i].equalsIgnoreCase("-out")) {

        checkNextArg(args, i);
        try {
          ap = new FileWriter(args[i + 1]);
        } catch (IOException io) {
          showError("File could not be transmitted");
        }

        outFile = true;

        i++;

      } else if (args[i].equalsIgnoreCase("-speed")) {

        checkNextArg(args, i);

        try {
          tempo = Integer.parseInt(args[i + 1]);
        } catch (NumberFormatException e) {
          showError("Must be a non-negative integer");
        }

        if (tempo <= 0) {
          showError("Must be a non-negative integer");
        }

        i++;

      } else if (args[i].equalsIgnoreCase("-features")) {

        features = true;

      } else if (args[i].equalsIgnoreCase("-intervals")) {

        checkNextArg(args, i);

        try {
          intervalsRD = new FileReader(args[i + 1]);
        } catch (FileNotFoundException f) {
          showError("File could not be read");
        }

        //parse the intervals file given
        try {
          intervals = IntervalReader.parseFile(intervalsRD);
        } catch (NullPointerException n) {
          showError("Intervals file invalid");
        }

        i++;

      } else {

        showError("Not a valid input specifier");

      }

    }

    if (features) {

      IExtraModel model = null;
      IAnimationView view = null;

      //parse file given
      try {
        model = AnimationReader.parseFile(rd, new ExtraAnimationModel.Builder());
      } catch (NullPointerException n) {
        showError("Source file invalid");
      }

      IExtraViewModel viewModel = new ExtraViewModel(model);

      switch (type) {
        case TEXT:
          view = new ExtraTextualView(viewModel, tempo, ap);
          break;
        case VISUAL:
          view = new ExtraVisualView(viewModel, tempo);
          break;
        case SVG:
          view = new ExtraSVGView(viewModel, tempo, ap);
          break;
        case INTERACTIVE:
          view = new ExtraInteractiveView(viewModel, tempo);
          break;
        default:
          showError("View type is illegal");

      }

      if (type == null || model == null) {
        showError("Requires a view type and an input file");
      }

      ExtraAnimationController controller = new ExtraAnimationController();
      controller.setIntervals(intervals);
      controller.startAnimation(model, tempo, view);

    } else {

      IAnimationModel model = null;
      IAnimationView view = null;

      //parse file given
      try {
        model = AnimationReader.parseFile(rd, new SimpleAnimationModel.Builder());
      } catch (NullPointerException n) {
        showError("Source file invalid");
      }

      IViewModel viewModel = new SimpleViewModel(model);

      switch (type) {
        case TEXT:
          view = new AnimationTextualView(viewModel, tempo, ap);
          break;
        case VISUAL:
          view = new AnimationVisualView(viewModel, tempo);
          break;
        case SVG:
          view = new AnimationSVGView(viewModel, tempo, ap);
          break;
        case INTERACTIVE:
          view = new SimpleInteractiveView(viewModel, tempo);
          break;
        default:
          showError("View type is illegal");

      }

      if (type == null || model == null) {
        showError("Requires a view type and an input file");
      }

      IAnimationController controller = new AnimationController();
      controller.startAnimation(model, tempo, view);

    }

    if (outFile) {
      FileWriter writer = (FileWriter) ap;
      try {
        writer.flush();
        writer.close();
      } catch (IOException e) {
        showError("File could not be closed");
        e.printStackTrace();
      }
    }

  }

  private static void checkNextArg(String[] args, int i) {

    if (i + 1 >= args.length) {
      showError("Requires argument after specifier");
    }

    if (args[i + 1].equals("-view") || args[i + 1].equals("-in") || args[i + 1].equals("-out")
        || args[i + 1].equals("-speed")) {
      showError("Cannot leave specifier argument blank");
    }

  }

  /**
   * Takes an error message and shows it on the screen with a popup.
   *
   * @param str The string to be shown as an error.
   */
  private static void showError(String str) {
    //default title and icon
    JFrame frame = new JFrame();
    //custom title, error icon
    JOptionPane.showMessageDialog(frame,
        str,
        "Illegal Argument Exception",
        JOptionPane.ERROR_MESSAGE);
    System.exit(0);
  }

  /**
   * enum representing game type of model.
   */
  public enum AnimationType {
    TEXT,
    VISUAL,
    SVG,
    INTERACTIVE,
    PROVIDER
  }

}
