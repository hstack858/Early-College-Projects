package cs3500.animator.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Class for the algorithm that creates the shooter animation.
 */
public class ShooterAnimationCreator {

  private Appendable ap;

  private int left = 6;
  private int middle = 6;
  private int right = 6;
  private int time = 1;

  private boolean gameOver = false;

  private List<Integer> numbers;

  /**
   * Public constructor that takes in an appendable to write to and a list of numbers that
   * corresponds to which blocks to hit. Must be a numbers between 0 and 2 inclusive.
   *
   * @param ap      appendable to write to
   * @param numbers list of numbers that is sequence to shoot
   */
  public ShooterAnimationCreator(Appendable ap, List<Integer> numbers) {

    this.ap = ap;
    this.numbers = numbers;

  }

  /**
   * Default constructor that has a preset ordering of blocks to shoot.
   *
   * @param ap appendable to write to
   */
  public ShooterAnimationCreator(Appendable ap) {

    List<Integer> numbers = new ArrayList<>();

    for (int i = 0; i < 18; i++) {
      numbers.add(i % 3);
    }

    this.ap = ap;
    this.numbers = numbers;

  }

  /**
   * Creates the animation and returns appendable it's written to.
   *
   * @return appendable that animation is written to.
   */
  public Appendable createAnimation() {

    this.initialize();

    while (!gameOver && this.numbers.size() > 0) {

      int block = this.numbers.remove(0);

      if (block == 0) {
        shoot("left");
      } else if (block == 1) {
        shoot("middle");
      } else if (block == 2) {
        shoot("right");
      }

    }

    return this.ap;
  }

  /**
   * Called in createAnimation to initialize shapes and their start positions.
   */
  private void initialize() {

    this.add("canvas 0 0 800 800");
    this.add("shape background rectangle");
    this.add("shape head oval");
    this.add("shape body rectangle");
    this.add("shape bullet oval");
    this.add("shape left rectangle");
    this.add("shape middle rectangle");
    this.add("shape right rectangle");

    this.add("motion background 1 0 0 800 800 0 0 0 1 0 0 800 800 0 0 0");

    this.add("motion head 1 350 550 100 100 4 20 69 1 350 550 100 100 4 20 69");
    this.add("motion body 1 375 600 50 200 4 20 69 1 375 600 50 200 4 20 69");

    this.add("motion head 1 350 550 100 100 4 20 69 200 350 550 100 100 4 20 69");
    this.add("motion body 1 375 600 50 200 4 20 69 200 375 600 50 200 4 20 69");

    this.add("motion bullet 1 400 770 20 20 0 200 200 1 400 770 20 20 0 200 200");

    this.add("motion left 1 0 0 200 100 127 255 0 1 0 0 200 100 127 255 0");
    this.add("motion middle 1 300 0 200 100 127 255 0 1 300 0 200 100 127 255 0");
    this.add("motion right 1 600 0 200 100 127 255 0 1 600 0 200 100 127 255 0");

    this.add("motion left 1 0 0 200 100 127 255 0 200 0 0 200 100 127 255 0");
    this.add("motion middle 1 300 0 200 100 127 255 0 200 300 0 200 100 127 255 0");
    this.add("motion right 1 600 0 200 100 127 255 0 200 600 0 200 100 127 255 0");
  }

  /**
   * Quick way to add a string to appendable that catches exception and automatically adds a new
   * line.
   *
   * @param str to add to appendable
   * @throws IllegalArgumentException if the appendable is wrong.
   */
  private void add(String str) throws IllegalArgumentException {

    try {
      this.ap.append(str);
      this.ap.append("\n");
    } catch (IOException io) {
      throw new IllegalStateException("Something is wrong with the appendable");
    }

  }

  /**
   * Animation for when a block is shot at left, middle, or right blocks.
   *
   * @param block to shoot at.
   */
  private void shoot(String block) {

    String posn;

    if (block.equals("left")) {
      posn = "100 50";
    } else if (block.equals("middle")) {
      posn = "400 50";
    } else if (block.equals("right")) {
      posn = "700 50";
    } else {
      throw new IllegalArgumentException("Invalid block given");
    }

    String str = "motion bullet " + this.time;
    this.time += 10;
    str = str + " 400 770 20 20 0 200 200 " + this.time + " " + posn + " 20 20 0 200 200";
    this.add(str);

    String str2 = "motion bullet " + this.time;
    str2 = str2 + " " + posn + " 20 20 0 200 200 " + this.time + " " + posn + " 20 20 0 0 0";
    this.add(str2);

    hurtBlock(block);

    String str3 = "motion bullet " + this.time;
    str3 = str3 + " " + posn + " 20 20 0 200 200 " + this.time + " 400 770 20 20 0 200 200";
    this.add(str3);

    String str4 = "motion bullet " + this.time;
    str4 = str4 + " 400 770 20 20 0 0 0 " + this.time + " 400 770 20 20 0 200 200";
    this.add(str4);

  }

  /**
   * Changes color of block to whatever it should be after taking damage from being shot at.
   *
   * @param block to hurt.
   */
  private void hurtBlock(String block) {

    String str = "motion " + block + " " + this.time + " ";
    int blockHealth;
    String posn;

    if (block.equals("left")) {
      blockHealth = this.left;
      posn = "0 0";
      this.left--;
    } else if (block.equals("middle")) {
      blockHealth = this.middle;
      posn = "300 0";
      this.middle--;
    } else if (block.equals("right")) {
      blockHealth = this.right;
      posn = "600 0";
      this.right--;
    } else {
      throw new IllegalArgumentException("Invalid block given");
    }

    int newTime = this.time + 10;

    switch (blockHealth) {
      case 6:
        str = str + posn + " 200 100 127 255 0 " + newTime + " " + posn + " 200 100 192 255 0";
        break;
      case 5:
        str = str + posn + " 200 100 192 255 0 " + newTime + " " + posn + " 200 100 255 255 0";
        break;
      case 4:
        str = str + posn + " 200 100 255 255 0 " + newTime + " " + posn + " 200 100 255 192 0";
        break;
      case 3:
        str = str + posn + " 200 100 255 192 0 " + newTime + " " + posn + " 200 100 255 127 0";
        break;
      case 2:
        str = str + posn + " 200 100 255 127 0 " + newTime + " " + posn + " 200 100 255 63 0";
        break;
      case 1:
        str = str + posn + " 200 100 255 63 0 " + newTime + " " + posn + " 200 100 255 0 0";
        break;
      default:
        str = str + posn + " 200 100 255 0 0 " + newTime + " " + posn + " 200 100 255 255 255";
        this.gameOver = true;
        break;

    }

    this.add(str);
  }

}
