package cs3500.animator.util;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Scanner;
import java.util.regex.Pattern;

/**
 * Class to parse a readable with slow motion information for a corresponding animation.
 */
public class IntervalReader {

  /**
   * Parses a readable and converts it into a map of times and tempos.
   *
   * @param readable to be read.
   * @return map of time intervals and their tempos.
   */
  public static Map<Integer, Integer> parseFile(Readable readable) {

    Objects.requireNonNull(readable, "Must have non-null readable source");

    Scanner s = new Scanner(readable);

    Map<Integer, Integer> intervals = new HashMap<>();

    s.useDelimiter(Pattern.compile("(\\p{Space}+|#.*)+"));

    while (s.hasNextInt()) {

      int key = s.nextInt();
      int value;

      if (s.hasNextInt()) {
        value = s.nextInt();
      } else {
        throw new IllegalStateException("Expected another integer specifying tempo");
      }

      intervals.put(key, value);
    }

    return intervals;

  }


}
