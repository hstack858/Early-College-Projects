package cs3500.animator.util;

import java.util.List;

/**
 * Class that represents a binary search tree.
 */
public class BinTree {

  private BinTree left;
  private BinTree right;
  private int value;

  /**
   * Constructor which takes in every BinTree field.
   *
   * @param value The value of this node.
   * @param left  The left tree of this node.
   * @param right The right tree of this node.
   */
  BinTree(int value, BinTree left, BinTree right) {
    this.value = value;
    this.left = left;
    this.right = right;
  }

  /**
   * Gets the left tree of this node.
   *
   * @return The left tree of this node.
   */
  public BinTree getLeft() {
    return this.left;
  }

  /**
   * Inserts one value into a binary search tree.
   *
   * @param i    The integer to be inserted.
   * @param list The list of strings we build up.
   * @return A list of strings which represents the paths
   */
  public List<String> insert(int i, List<String> list) {
    if (i == value) {
      throw new IllegalArgumentException("Only new values can be added to tree");
    } else if (i > value) {
      list.add("right");
      if (this.right == null) {
        this.right = new BinTree(i, null, null);
        return list;
      } else {
        return this.right.insert(i, list);
      }
    } else {
      list.add("left");
      if (this.left == null) {
        this.left = new BinTree(i, null, null);
        return list;
      } else {
        return this.left.insert(i, list);
      }
    }
  }
}
