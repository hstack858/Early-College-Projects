package cs3500.animator.util;

import java.io.FileWriter;
import java.io.IOException;

/**
 * Class for running the program to create the shooter animation.
 */
public class CreatorRunner {

  /**
   * Main class that creates an output file and stores results of ShooterAnimationCreator.
   *
   * @param args string arguments from main. Does not take any.
   * @throws IOException throws IOException if the file cannot be closed properly.
   */
  public static void main(String[] args) throws IOException {

    Appendable ap;
    FileWriter writer = new FileWriter("output.txt");

    ap = writer;
    ShooterAnimationCreator creator = new ShooterAnimationCreator(ap);
    creator.createAnimation();

    try {
      writer.flush();
      writer.close();
    } catch (IOException e) {
      e.printStackTrace();
    }

  }

}