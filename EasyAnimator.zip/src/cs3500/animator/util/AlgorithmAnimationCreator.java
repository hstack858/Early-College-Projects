package cs3500.animator.util;

import cs3500.model.shapes.IShape;
import cs3500.model.shapes.Oval;
import cs3500.model.shapes.Posn;
import cs3500.model.shapes.RGB;
import cs3500.model.shapes.Rectangle;
import java.io.IOException;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

/**
 * Class that holds the methods necessary to algorithmically animate the sorting of a binary tree
 * with binary numbers.
 */
public class AlgorithmAnimationCreator {

  private Appendable ap;
  private List<Integer> list;
  private int ticks;
  private double nodeWidth;
  private List<IShape> shapes;
  private AbstractMap<String, List<IShape>> numbers;
  private int largestNum;
  private int finalTick;

  /**
   * Constructor that takes in an appendable and the list of numbers to be animated.
   *
   * @param ap   Appendable to output animation text.
   * @param list List of numbers being inserted into the tree.
   */
  public AlgorithmAnimationCreator(Appendable ap, List<Integer> list) {
    this.ap = ap;
    this.list = list;
    ticks = 1;
    nodeWidth = 800 / list.size();
    shapes = new ArrayList<IShape>();
    this.numbers = new TreeMap<String, List<IShape>>();
    int largestNum = 0;
    for (Integer i : list) {
      if (i > largestNum) {
        largestNum = i;
      }
    }
    this.largestNum = largestNum;
    finalTick = this.list.size() * 20 + 10;
  }

  /**
   * Creates the entire animation document.
   *
   * @return The animation document in String form.
   */
  public String createAnimation() {
    this.initialize();
    this.insertList();
    return this.ap.toString();
  }

  /**
   * Produces text which animates an insertion of the next item in the list into the tree.
   */
  private void insertList() {
    BinTree tree = null;
    if (list.size() > 0) {
      tree = new BinTree(this.list.get(0), null, null);
      String motionMaker1 = "motion " + Integer.toString(this.list.get(0));
      double xPosn = 0;
      List<IShape> numbahs = new ArrayList<IShape>();
      for (IShape shape : this.shapes) {
        if (Integer.toString(this.list.get(0)).equals(shape.returnName())) {
          xPosn = shape.getPosition().getX();
          for (String s : this.numbers.keySet()) {
            if (s.equals(shape.returnName())) {
              numbahs = this.numbers.get(s);
            }
          }
        }
      }
      String centerMotion1 = this.shapeAtTick(1, xPosn, 700, nodeWidth, nodeWidth, 0, 200, 0);
      String centerMotion2 = this.shapeAtTick(20, 400, 100, nodeWidth, nodeWidth, 0, 200, 0);
      String centerMotion3 = this
          .shapeAtTick(this.finalTick, 400, 100, nodeWidth, nodeWidth, 0, 200, 0);
      this.add(motionMaker1 + centerMotion1 + centerMotion2);
      this.add(motionMaker1 + centerMotion2 + centerMotion3);

      int i = 0;
      double unitWidth = this.calculateNumWidth();
      for (IShape s : numbahs) {
        String motionMaker2 = "motion " + s.returnName();
        String centerNum1 = "";
        String centerNum2 = "";
        String centerNum3 = "";
        if (s.returnType().equals("rect")) {
          centerNum1 = this.shapeAtTick(1, this.calculateNumPosX(this.list.get(0), xPosn).get(i),
              (700 + .5 * nodeWidth - unitWidth), unitWidth,
              unitWidth * 2, 0, 0, 0);
          centerNum2 = this.shapeAtTick(20, this.calculateNumPosX(this.list.get(0), 400).get(i),
              (100 + .5 * nodeWidth - unitWidth), unitWidth,
              unitWidth * 2, 0, 0, 0);
          centerNum3 = this
              .shapeAtTick(this.finalTick, this.calculateNumPosX(this.list.get(0), 400).get(i),
                  (100 + .5 * nodeWidth - unitWidth), unitWidth,
                  unitWidth * 2, 0, 0, 0);
        } else {
          centerNum1 = this.shapeAtTick(1,
              this.calculateNumPosX(this.list.get(0), xPosn).get(i),
              (700 + .5 * nodeWidth - unitWidth) + unitWidth, unitWidth,
              unitWidth * 2, 0, 0, 0);
          centerNum2 = this.shapeAtTick(20, this.calculateNumPosX(this.list.get(0),
              400).get(i), (100 + .5 * nodeWidth - unitWidth), unitWidth, unitWidth * 2,
              0, 0, 0);
          centerNum3 = this.shapeAtTick(this.finalTick,
              this.calculateNumPosX(this.list.get(0), 400).get(i),
              (100 + .5 * nodeWidth - unitWidth), unitWidth, unitWidth * 2, 0, 0, 0);
        }
        i++;
        this.add(motionMaker2 + centerNum1 + centerNum2);
        this.add(motionMaker2 + centerNum2 + centerNum3);
      }
      this.list.remove(0);
      ticks = 20;
    }
    while (this.list.size() > 0) {
      List<String> path = tree.insert(this.list.get(0), new ArrayList<String>());
      String firstPath = path.get(0);
      int right = 0;
      int left = 0;
      for (String s : path) {
        if (s.equals("right")) {
          right++;
        }
        if (s.equals("left")) {
          left++;
        }
      }
      double newX = 400 + (left * nodeWidth * -1) + (right * nodeWidth);
      double newY = 100 + (left * nodeWidth) + (right * nodeWidth);
      double xPosn = 0;
      IShape shaper = null;
      for (IShape shape : this.shapes) {
        if (Integer.toString(this.list.get(0)).equals(shape.returnName())) {
          shaper = shape;
          xPosn = shape.getPosition().getX();
        }
      }
      if (firstPath.equals("left")) {
        newX = newX - 60 * (.66 * left);
        String motionmaker2 = "motion " + Integer.toString(this.list.get(0)) +
            this.shapeAtTick(ticks, xPosn, 700, nodeWidth, nodeWidth, 0, 0, 200) +
            this.shapeAtTick(ticks + 20, newX, newY, nodeWidth, nodeWidth, 0, 0, 200);
        this.add(motionmaker2);
        String motionmaker5 = "motion " + Integer.toString(this.list.get(0)) +
            this.shapeAtTick(ticks + 20, newX, newY, nodeWidth, nodeWidth, 0, 0, 200) +
            this.shapeAtTick(this.finalTick, newX, newY, nodeWidth, nodeWidth, 0, 0, 200);
        this.add(motionmaker5);
      } else {
        newX = newX + 60 * (.66 * right);
        String motionmaker2 = "motion " + Integer.toString(this.list.get(0)) +
            this.shapeAtTick(ticks, xPosn, 700, nodeWidth, nodeWidth, 200, 0, 0) +
            this.shapeAtTick(ticks + 20, newX, newY, nodeWidth, nodeWidth, 200, 0, 0);
        this.add(motionmaker2);
        String motionmaker5 = "motion " + Integer.toString(this.list.get(0)) +
            this.shapeAtTick(ticks + 20, newX, newY, nodeWidth, nodeWidth, 200, 0, 0) +
            this.shapeAtTick(this.finalTick, newX, newY, nodeWidth, nodeWidth, 200, 0, 0);
        this.add(motionmaker5);
      }
      List<IShape> shapers = new ArrayList<IShape>();
      for (String s : this.numbers.keySet()) {
        if (s.equals(shaper.returnName())) {
          shapers = this.numbers.get(s);
        }
      }
      int index = 0;
      double unitWidth = this.calculateNumWidth();
      for (IShape s : shapers) {
        String motionMaker3 = "motion " + s.returnName();
        String motionMaker4 = "";
        String motionMaker6 = "";
        if (s.returnType().equals("rect")) {
          motionMaker4 = this.shapeAtTick(ticks, this.calculateNumPosX(this.list.get(0),
              xPosn).get(index), (700 + .5 * nodeWidth - unitWidth), unitWidth, 2 * unitWidth, 0, 0,
              0) +
              this.shapeAtTick(ticks + 20,
                  this.calculateNumPosX(this.list.get(0), newX).get(index),
                  (newY + .5 * nodeWidth - unitWidth), unitWidth, 2 * unitWidth,
                  0, 0, 0);
          motionMaker6 = this.shapeAtTick(ticks + 20,
              this.calculateNumPosX(this.list.get(0), newX).get(index),
              (newY + .5 * nodeWidth - unitWidth), unitWidth, 2 * unitWidth,
              0, 0, 0) +
              this.shapeAtTick(this.finalTick,
                  this.calculateNumPosX(this.list.get(0), newX).get(index),
                  (newY + .5 * nodeWidth - unitWidth), unitWidth, 2 * unitWidth,
                  0, 0, 0);
        } else {
          motionMaker4 = this.shapeAtTick(ticks, this.calculateNumPosX(
              this.list.get(0), xPosn).get(index), (700 + .5 * nodeWidth - unitWidth),
              unitWidth, unitWidth * 2, 0, 0, 0) +
              this.shapeAtTick(ticks + 20, this.calculateNumPosX(
                  this.list.get(0), newX).get(index), (newY + .5 * nodeWidth - unitWidth),
                  unitWidth, unitWidth * 2, 0, 0, 0);
          motionMaker6 = this.shapeAtTick(ticks + 20, this.calculateNumPosX(
              this.list.get(0), newX).get(index), (newY + .5 * nodeWidth - unitWidth),
              unitWidth, unitWidth * 2, 0, 0, 0) +
              this.shapeAtTick(this.finalTick, this.calculateNumPosX(
                  this.list.get(0), newX).get(index), (newY + .5 * nodeWidth - unitWidth),
                  unitWidth, unitWidth * 2, 0, 0, 0);
        }
        index++;
        this.add(motionMaker3 + motionMaker4);
        this.add(motionMaker3 + motionMaker6);
      }
      this.ticks += 20;
      this.list.remove(0);
    }
  }

  /**
   * Initializes all of the shapes and their first display commands for this animation.
   */
  private void initialize() {

    // initializes the shapes without values
    this.add("canvas 0 0 800 800");
    double currXPos = nodeWidth / 2;
    for (Integer i : list) {
      this.add("shape " + i.toString() + " oval");
      IShape newShape = new Oval(i.toString(), new Posn(currXPos, 700), new RGB(0, 0, 100),
          nodeWidth, nodeWidth, 0, 0);
      shapes.add(newShape);
      String number = i.toString();
      double unitWidth = this.calculateNumWidth();
      int zeroCount = 1;
      int oneCount = 1;
      numbers.put(newShape.returnName(), new ArrayList<IShape>());
      int index = 0;
      for (char c : number.toCharArray()) {
        if (c == '1') {
          String name = i.toString() + "-One-" + Integer.toString(oneCount);
          IShape newOne = new Rectangle(name, new Posn(currXPos, 700),
              new RGB(0, 0, 0), unitWidth, unitWidth * 2, 0, 0);
          oneCount++;
          currXPos = this.calculateNumPosX(i, currXPos).get(index);
          numbers.get(newShape.returnName()).add(newOne);
          this.add("shape " + name + " rectangle");
          index++;
        }
        if (c == '0') {
          String name = i.toString() + "-Zero-" + Integer.toString(zeroCount);
          IShape newZero = new Oval(name,
              new Posn(this.calculateNumPosX(i, currXPos).get(index), 700),
              new RGB(0, 0, 0), unitWidth, unitWidth * 2, 0, 0);
          zeroCount++;
          numbers.get(newShape.returnName()).add(newZero);
          this.add("shape " + name + " oval");
          index++;
        }
      }
    }
    for (IShape newShape : shapes) {
      String initializer = this.shapeAtTick(1, newShape.getPosition().getX(),
          newShape.getPosition().getY(), newShape.getWidth(), newShape.getHeight(),
          0, 0, 100) + this.shapeAtTick(1, newShape.getPosition().getX(),
          newShape.getPosition().getY(), newShape.getWidth(), newShape.getHeight(),
          0, 0, 100);
      this.add("motion " + newShape.returnName() + initializer);
      currXPos += nodeWidth;
    }

    for (String s : numbers.keySet()) {
      List<IShape> numbersLocal = numbers.get(s);
      double unitWidth = this.calculateNumWidth();
      for (IShape shape : numbersLocal) {
        String initializer = this.shapeAtTick(1, shape.getPosition().getX(),
            (shape.getPosition().getY() + .5 * nodeWidth - unitWidth), shape.getWidth(),
            shape.getHeight(), 0, 0, 0) +
            this.shapeAtTick(1, shape.getPosition().getX(),
                (shape.getPosition().getY() + .5 * nodeWidth - unitWidth), shape.getWidth(),
                shape.getHeight(), 0, 0, 0);
        this.add("motion " + shape.returnName() + initializer);
      }
    }
  }

  /**
   * Returns a formatted string of values at a specific tick.
   *
   * @param tick The tick this shape's values are currently at.
   * @param x    X position.
   * @param y    Y position.
   * @param w    Shape width.
   * @param h    Shape height.
   * @param r    Red value.
   * @param g    Green Value.
   * @param b    Blue Value.
   * @return The shapes values formatted into the correct animation string.
   */
  private String shapeAtTick(int tick, double x, double y, double w, double h, int r, int g,
      int b) {
    long ticks = Math.round(tick);
    long xs = Math.round(x);
    long ys = Math.round(y);
    long ws = Math.round(w);
    long hs = Math.round(h);

    return String.format(" %d %d %d %d %d %d %d %d", ticks, xs, ys, ws, hs, r, g, b);
  }


  /**
   * Adds a string to the appendable.
   *
   * @param str The string to be added.
   */
  private void add(String str) {
    try {
      this.ap.append(str);
      this.ap.append("\n");
    } catch (IOException io) {
      throw new IllegalStateException("Something is wrong with the appendable");
    }
  }

  /**
   * Calculates all of the x positions for the numbers in the search tree based on its nodes posn.
   *
   * @param num  The number being animated.
   * @param xOld The x position of the node.
   * @return A list of all of the x coordinates of the numbers in the node.
   */
  private List<Double> calculateNumPosX(int num, double xOld) {
    List<Double> ret = new ArrayList<Double>();
    String lenString = Integer.toString(num);
    int len = lenString.length();
    double x = (xOld + .5 * nodeWidth);
    x = x - .5 * this.calculateNumWidth();
    if (len == 1) {
      ret.add(x);
      return ret;
    } else if (len == 2) {
      double posn1 = x - (this.calculateNumWidth() / 2) - 5;
      double posn2 = x + (this.calculateNumWidth() / 2) + 5;
      ret.add(posn1);
      ret.add(posn2);
      return ret;
    } else if (len == 3) {
      double posn1 = x - (this.calculateNumWidth()) - 5;
      double posn2 = x;
      double posn3 = x + (this.calculateNumWidth()) + 5;
      ret.add(posn1);
      ret.add(posn2);
      ret.add(posn3);
      return ret;
    } else if (len == 4) {
      double posn1 = x - (this.calculateNumWidth() * 1.5) - 5;
      double posn2 = x - (this.calculateNumWidth() / 2) - 2.5;
      double posn3 = x + (this.calculateNumWidth() / 2) + 2.5;
      double posn4 = x + (this.calculateNumWidth() * 1.5) + 5;
      ret.add(posn1);
      ret.add(posn2);
      ret.add(posn3);
      ret.add(posn4);
      return ret;
    }
    return ret;
  }

  /**
   * Calculates the universal width of the numbers inside the nodes.
   *
   * @return The width of one inner node digit.
   */
  private double calculateNumWidth() {
    int large = this.largestNum;
    String numberString = Integer.toString(large);
    int oneCount = 0;
    int zeroCount = 0;
    for (char c : numberString.toCharArray()) {
      if (c == '1') {
        oneCount++;
      }
      if (c == '0') {
        zeroCount++;
      }
    }
    int totalUnits = oneCount + zeroCount;
    double numberSpace = ((.666666666) * nodeWidth);
    double unitWidth = numberSpace / totalUnits;
    return unitWidth;
  }

}
