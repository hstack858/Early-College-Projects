package cs3500.animator.view;

import cs3500.model.IViewModel;
import cs3500.model.commands.ICommand;
import cs3500.model.shapes.IShape;
import cs3500.model.shapes.Posn;
import cs3500.model.shapes.RGB;
import java.io.IOException;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

/**
 * Class that builds an SVG textual output based on a given model.
 */
public class AnimationSVGView implements IAnimationView {

  private IViewModel model;
  private int tempo;
  private List<IShape> shapesInOrder;
  private Appendable ap;
  private List<ICommand> commandsInOrder;
  private AbstractMap<Integer, List<ICommand>> startTimes;
  private AbstractMap<String, IShape> initializedShapes;

  /**
   * Constructor that takes in the model to animate and the tempo at which to animate it.
   *
   * @param model The model being animated.
   * @param tempo The speed at which it will be animated.
   */
  public AnimationSVGView(IViewModel model, int tempo, Appendable ap) {
    if (model == null) {
      throw new IllegalArgumentException("Null model not allowed");
    }
    if (tempo < 0) {
      throw new IllegalArgumentException("Negative tempo not allowed");
    }
    this.model = model;
    this.tempo = tempo;
    this.shapesInOrder = this.model.getShapesInOrder();
    this.ap = ap;
    this.commandsInOrder = new ArrayList<ICommand>();
    this.startTimes = new TreeMap<Integer, List<ICommand>>();
    this.initializedShapes = new TreeMap<String, IShape>();
  }


  /**
   * The method that outputs the entire SVG textual output.
   */
  public void render() {
    try {
      ap.append(this.createIntroduction());
      ap.append(this.createAnimations());
      ap.append("</svg>");
    } catch (IOException i) {
      throw new IllegalArgumentException("Cannot create animation output: append");
    }
  }

  /**
   * Changes the tempo of this view to the given tempo.
   *
   * @param tempo The tempo to be changed to.
   */
  @Override
  public void changeTempoTo(int tempo) {
    this.tempo = tempo;
  }

  @Override
  public void changeIndicator(String name) {
    //asdsad
  }

  /**
   * The introduction to the SVG file.
   *
   * @return The top lines of the SVG file that don't declare or animate any shapes.
   */
  private String createIntroduction() {
    int width = this.model.getWidth();
    int height = this.model.getHeight();
    int x = this.model.getX();
    int y = this.model.getY();

    String xml = String.format("<svg width=\"%d\" height=\"%d\" version=\"1.1\"\n"
            + " viewBox=\"%d %d %d %d\" xmlns=\"http://www.w3.org/2000/svg\">", width, height, x, y,
        width, height);

    xml = xml + "\n <desc>An animation of your choosing</desc>\n";
    return xml;
  }

  /**
   * Calls createShape on each shape in the model.
   *
   * @return The declaration and animations of each shape in the model.
   */
  private String createAnimations() {
    String allAnimations = "";

    // Puts all commands in order of start time into this.commandsInOrder
    List<ICommand> commandsInOrder = new ArrayList<ICommand>();
    for (IShape s : this.shapesInOrder) {
      List<ICommand> list = this.model.getMotions(s, this.model.getShapes());
      commandsInOrder.addAll(list);
    }
    this.commandsInOrder = commandsInOrder;

    // Finds the earliest command for a specific shape (the display command) and puts this
    // shape into a hashmap from its name to its value so each command can grab the correct
    // shape reference (starts at shape's earliest values).
    for (ICommand c : this.commandsInOrder) {
      if (!(this.initializedShapes.keySet().contains(c.getShapeName()))) {
        this.initializedShapes.put(c.getShapeName(), c.getShape());
      } else {
        c.setShape(this.initializedShapes.get(c.getShapeName()));
      }
    }

    // Gives shapes in order the same shape reference the commands have
    int index = 0;
    while (index < this.shapesInOrder.size()) {
      this.shapesInOrder
          .set(index, this.initializedShapes.get(this.shapesInOrder.get(index).returnName()));
      index++;
    }

    // Creates the hashmap of Integer to Command which represents the commands starting
    // at each tick number. This is used to make sure simultaneous commands work correctly.
    int tick = 0;
    int counter = 0;
    while (counter < this.commandsInOrder.size()) {
      for (ICommand c : this.commandsInOrder) {
        if (c.startTime() == tick) {
          if (this.startTimes.keySet().contains(tick)) {
            this.startTimes.get(tick).add(c);
          } else {
            ArrayList<ICommand> newC = new ArrayList<ICommand>();
            newC.add(c);
            this.startTimes.put(tick, newC);
          }
          counter++;
        }
      }
      tick++;
    }

    // Call declare shape on all shapes
    for (IShape s : this.shapesInOrder) {
      allAnimations = allAnimations +
          this.declareShape(s);
    }

    // Remove last /n from string
    allAnimations.substring(0, allAnimations.length() - 1);

    return allAnimations;
  }

  /**
   * Creates a shape and then calls its animations.
   *
   * @param shape The shape to be declared.
   * @return The shape declaration and all of its animations.
   */
  private String declareShape(IShape shape) {
    String shapeAnimations = "";
    String shapeType = shape.returnType();
    RGB color = shape.getColor();
    color.roundValues();
    long x = Math.round(shape.getPosition().getX());
    long y = Math.round(shape.getPosition().getY());
    long width = Math.round(shape.getWidth());
    long height = Math.round(shape.getHeight());
    String colorRed = Double.toString(color.getRed()).substring(0, 3);
    if (colorRed.charAt(0) == '0') {
      colorRed = "0";
    }
    colorRed = this.periodHelper(colorRed);

    String colorGreen = Double.toString(color.getGreen()).substring(0, 3);
    if (colorGreen.charAt(0) == '0') {
      colorGreen = "0";
    }
    colorGreen = this.periodHelper(colorGreen);

    String colorBlue = Double.toString(color.getBlue()).substring(0, 3);
    if (colorBlue.charAt(0) == '0') {
      colorBlue = "0";
    }
    colorBlue = this.periodHelper(colorBlue);

    if (shapeType.equals("rect")) {
      shapeAnimations = String.format(
          "<rect id=\"%s\" x=\"%d\" y=\"%d\" width=\"%d\" height=\"%d\" fill="
              + "\"rgb(" + colorRed + "," + colorGreen + "," + colorBlue + ")\" "
              + "visibility=\"hidden\" >",
          shape.returnName(), x, y, width, height, color.getRed(), color.getGreen(),
          color.getBlue());
      shapeAnimations = shapeAnimations + "\n";
    } else if (shapeType.equals("oval")) {
      shapeAnimations = String
          .format("<ellipse id=\"%s\" cx=\"%d\" cy=\"%d\" rx=\"%d\" ry=\"%d\" fill="
                  + "\"rgb(" + colorRed + "," + colorGreen + "," + colorBlue + ")\" "
                  + "visibility=\"hidden\" >",
              shape.returnName(),
              x, y, width / 2, height / 2, color.getRed(), color.getGreen(), color.getBlue());
      shapeAnimations = shapeAnimations + "\n";
    }

    for (Integer i : this.startTimes.keySet()) {
      List<ICommand> comsAti = this.startTimes.get(i);
      // Calls callCommand on each command at this tick for this shape
      for (ICommand c : comsAti) {
        if (c.getShapeName().equals(shape.returnName())) {
          shapeAnimations = shapeAnimations + this.callCommand(c);
        }
      }
      // Updates this shapes values after it has gone through its commands at this tick
      for (ICommand c : comsAti) {
        if (c.getShapeName() == shape.returnName()) {
          shape = c.simulate(shape);
        }
      }
    }

    if (shapeType.equals("oval")) {
      shapeAnimations = shapeAnimations + "</ellipse>\n \n";
    } else {
      shapeAnimations = shapeAnimations + "</rect>\n \n";
    }

    return shapeAnimations;
  }

  /**
   * Determines which type of animation this shape should go through based on a given command.
   *
   * @param com The command that this shape will be animated through.
   * @return The svg animation output of this shape going through this single command.
   */
  private String callCommand(ICommand com) {
    String commandType = this.whatCommandType(com);
    if (commandType.equals("move")) {
      return moveXML(com);
    } else if (commandType.equals("color")) {
      return changeColorXML(com);
    } else if (commandType.equals("transform")) {
      return transformXML(com);
    } else if (commandType.equals("display")) {
      return displayXML(com);
    } else {
      throw new IllegalArgumentException("Invalid command type for svg");
    }
  }

  private String displayXML(ICommand com) {
    long start = Math.round((com.startTime() / this.tempo) * 1000);
    long duration = Math.round(1000 * ((model.getLastTick() - com.startTime()) / this.tempo));
    String builder = "    " + "<set attributeName=\"visibility\" attributeType=\"CSS\" " +
        "to=\"visible\" begin=\"" + Long.toString(start) + "ms\" dur =\"" + Long.toString(duration)
        + "ms\" fill=\"freeze\" />";
    return builder + "\n";
  }

  /**
   * Writes a change color animation for a shape in svg format for a given command.
   *
   * @param com The change color command that this shape will go through.
   * @return The textual representation of the change color command on its shape.
   */
  private String changeColorXML(ICommand com) {
    IShape shape = com.getShape();
    RGB color = shape.getColor();
    color.roundValues();
    IShape shape2 = com.simulate(shape);
    RGB color2 = shape2.getColor();
    color2.roundValues();
    String colorRed = Double.toString(color.getRed()).substring(0, 3);
    if (colorRed.charAt(0) == '0') {
      colorRed = "0";
    }
    colorRed = this.periodHelper(colorRed);
    String colorGreen = Double.toString(color.getGreen()).substring(0, 3);
    if (colorGreen.charAt(0) == '0') {
      colorGreen = "0";
    }
    colorGreen = this.periodHelper(colorGreen);
    String colorBlue = Double.toString(color.getBlue()).substring(0, 3);
    if (colorBlue.charAt(0) == '0') {
      colorBlue = "0";
    }
    colorBlue = this.periodHelper(colorBlue);
    String colorRed2 = Double.toString(color2.getRed()).substring(0, 3);
    if (colorRed2.charAt(0) == '0') {
      colorRed2 = "0";
    }
    colorRed2 = this.periodHelper(colorRed2);
    String colorGreen2 = Double.toString(color2.getGreen()).substring(0, 3);
    if (colorGreen2.charAt(0) == '0') {
      colorGreen2 = "0";
    }
    colorGreen2 = this.periodHelper(colorGreen2);
    String colorBlue2 = Double.toString(color2.getBlue()).substring(0, 3);
    if (colorBlue2.charAt(0) == '0') {
      colorBlue2 = "0";
    }
    colorBlue2 = this.periodHelper(colorBlue2);

    long start = Math.round((com.startTime() / this.tempo) * 1000);
    long duration = Math.round(1000 * (com.endTime() - com.startTime()) / this.tempo);
    String comString =
        "    " + String.format("<animate attributeType=\"xml\" begin=\"%dms\" dur=\"%dms\""
            + " attributeName=\"fill\""
            + " from=\"rgb(" + colorRed + "," + colorGreen +
            "," + colorBlue + ")\" to=\"rgb(" + colorRed2 + "," + colorGreen2 +
            "," + colorBlue2 + ")\" fill=\"freeze\" />", start, duration);
    return comString + "\n";
  }

  /**
   * Helps format the periods in long decimal color values.
   *
   * @param s The color value with potential periods
   * @return The color value without any periods.
   */
  private String periodHelper(String s) {
    if (s.length() == 3) {
      if (s.charAt(2) == '.') {
        return s.substring(0, 2);
      } else if (s.charAt(1) == '.') {
        return s.substring(0, 1);
      } else if (s.charAt(0) == '.') {
        return "0";
      }
    } else if (s.length() == 2) {
      if (s.charAt(1) == '.') {
        return s.substring(0, 1);
      } else if (s.charAt(0) == '.') {
        return "0";
      }
    } else if (s.length() == 1) {
      if (s.charAt(0) == '.') {
        return "0";
      }
    }
    return s;
  }

  /**
   * Writes a transform animation for a shape in svg format for a given command.
   *
   * @param com The transform command that this shape will go through.
   * @return The textual representation of the transform command on its shape.
   */
  private String transformXML(ICommand com) {
    IShape shape = com.getShape();
    double width1 = shape.getWidth();
    double height1 = shape.getHeight();
    IShape shape2 = com.simulate(shape);
    double width2 = shape2.getWidth();
    double height2 = shape2.getHeight();

    boolean widthChange = (width1 != width2);
    boolean heightChange = (height1 != height2);

    String w1s = Double.toString(width1);
    String w2s = Double.toString(width2);
    String h1s = Double.toString(height1);
    String h2s = Double.toString(height2);

    long start = Math.round((com.startTime() / this.tempo) * 1000);
    long duration = Math.round(1000 * (com.endTime() - com.startTime()) / this.tempo);
    String comString = "";

    if (widthChange) {
      comString =
          "    " + String.format("<animate attributeType=\"xml\" begin=\"%dms\" dur=\"%dms\""
              + " attributeName=\"width\""
              + " from=\"" + w1s + "\" to=\"" + w2s + "\" fill=\"freeze\" />", start, duration);
    }
    if (widthChange && heightChange) {
      comString = comString + "\n";
    }
    if (heightChange) {
      comString =
          "    " + String.format("<animate attributeType=\"xml\" begin=\"%dms\" dur=\"%dms\""
              + " attributeName=\"height\""
              + " from=\"" + h1s + "\" to=\"" + h2s + "\" fill=\"freeze\" />", start, duration);
    }
    for (Integer i : this.startTimes.keySet()) {
      if (i > com.startTime()) {
        for (ICommand c : this.startTimes.get(i)) {
          c.setShape(shape2);
        }
      }
    }
    return comString + "\n";
  }

  /**
   * Writes a move animation for a shape in svg format for a given command.
   *
   * @param com The move command that this shape will go through.
   * @return The textual representation of the move command on its shape.
   */
  private String moveXML(ICommand com) {
    IShape shape1 = com.getShape();
    IShape shape3 = com.simulate(shape1);
    double x = shape1.getPosition().getX();
    double y = shape1.getPosition().getY();
    double x2 = shape3.getPosition().getX();
    double y2 = shape3.getPosition().getY();

    boolean xChange = (x != x2);
    boolean yChange = (y != y2);
    long start1 = Math.round((com.startTime() / this.tempo) * 1000);
    long duration1 = Math.round(1000 * (com.endTime() - com.startTime()) / this.tempo);

    String stringCom = "";
    String xs = Double.toString(x);
    String ys = Double.toString(y);
    String x2s = Double.toString(x2);
    String y2s = Double.toString(y2);
    String attX;
    String attY;
    if (shape1.returnType().equals("rect")) {
      attX = " attributeName=\"x\"";
    } else {
      attX = " attributeName=\"cx\"";
    }
    if (shape1.returnType().equals("rect")) {
      attY = " attributeName=\"y\"";
    } else {
      attY = " attributeName=\"cy\"";
    }

    if (xChange) {
      stringCom =
          "    " + String.format("<animate attributeType=\"xml\" begin=\"%dms\" dur=\"%dms\"" +
                  attX + " from=\"" + xs + "\" to=\"" + x2s + "\" fill=\"freeze\" />", start1,
              duration1);
    }
    if (xChange && yChange) {
      stringCom = stringCom + "\n";
    }
    if (yChange) {
      stringCom = stringCom + "    " + String
          .format("<animate attributeType=\"xml\" begin=\"%dms\" dur=\"%dms\"" +
                  attY + " from=\"" + ys + "\" to=\"" + y2s + "\" fill=\"freeze\" />", start1,
              duration1);
    }
    for (Integer i : this.startTimes.keySet()) {
      if (i > com.startTime()) {
        for (ICommand c : this.startTimes.get(i)) {
          c.setShape(shape3);
        }
      }
    }
    return stringCom + "\n";
  }

  /**
   * Determines which type of command this command is.
   *
   * @param com The command that we are trying to figure out the type of.
   * @return The type of command com is in string form/
   */
  private String whatCommandType(ICommand com) {
    IShape shape1 = com.getShape();
    Posn ogPosn = shape1.getPosition();
    RGB ogColor = shape1.getColor();
    ogColor.roundValues();
    double ogWidth = shape1.getWidth();
    double ogHeight = shape1.getHeight();

    IShape shape3 = com.simulate(shape1);
    Posn posn2 = shape3.getPosition();
    RGB color2 = shape3.getColor();
    color2.roundValues();
    double width3 = shape3.getWidth();
    double height3 = shape3.getHeight();

    if (!(ogPosn.equals(posn2))) {
      return "move";
    } else if ((!(ogColor.equals(color2)))) {
      return "color";
    } else if (!(ogWidth == width3 && ogHeight == height3)) {
      return "transform";
    } else {
      return "display";
    }
  }
}
