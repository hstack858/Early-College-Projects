package cs3500.animator.view;

import cs3500.controller.IAnimationController;
import java.util.TimerTask;

/**
 * Class to represent a task that needs to be completed by the controller.
 */
public class RenderTask extends TimerTask {

  private final IAnimationController controller;


  public RenderTask(IAnimationController controller) {
    this.controller = controller;
  }

  @Override
  public void run() {
    controller.renderTick();
  }

}
