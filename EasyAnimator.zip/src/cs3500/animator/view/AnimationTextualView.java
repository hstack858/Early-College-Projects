package cs3500.animator.view;

import cs3500.model.IViewModel;
import cs3500.model.SimpleAnimationModel;
import cs3500.model.SimpleViewModel;
import cs3500.model.commands.ICommand;
import cs3500.model.shapes.IShape;
import java.io.IOException;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.TreeMap;

/**
 * Class to represent a textual grid view of an animation motion by motion.
 */
public class AnimationTextualView implements IAnimationView {

  private IViewModel model;
  private int tempo;
  private Appendable ap;
  private AbstractMap<String, List<ICommand>> shapeComs;
  private AbstractMap<String, IShape> shapes;

  /**
   * Takes in all non in class initialized things.
   *
   * @param model model for view
   * @param tempo speed
   * @param ap    appendable
   */
  public AnimationTextualView(IViewModel model, int tempo, Appendable ap) {

    Objects.requireNonNull(this.tempo = tempo, "Can't have null tempo");
    if (tempo < 0) {
      throw new IllegalArgumentException("Can't have negative tempo");
    }

    this.ap = ap;
    shapeComs = new TreeMap<String, List<ICommand>>();
    shapes = model.getShapes();
    for (String s : shapes.keySet()) {
      shapeComs.put(s, model.getMotions(shapes.get(s), shapes));
    }
    List<ICommand> toDo = new ArrayList<ICommand>();
    for (String key : shapes.keySet()) {
      toDo.addAll(model.getMotions(shapes.get(key), shapes));
    }
    SimpleAnimationModel delegate;
    if (model == null) {
      throw new IllegalArgumentException("Invalid model");
    } else {
      delegate = new SimpleAnimationModel(shapes, toDo,
          new ArrayList<ICommand>(),
          model.getX(), model.getY(), model.getWidth(), model.getHeight(),
          model.getShapesInOrder());
    }
    this.model = new SimpleViewModel(delegate);
  }


  /**
   * Outputs the results in shape value for all commands our easy animator is asked to animate in a
   * textual table.
   *
   * @return The textual table of the shape's state before and after each command.
   */
  public String toString() {
    String finalString = "";
    AbstractMap<String, IShape> shapes = this.model.getShapes();
    if (shapes.size() <= 0) {
      return "";
    }
    for (String s : shapes.keySet()) {
      finalString = finalString + this.shapeBlock(shapes.get(s), shapes);
    }
    return finalString.substring(0, finalString.length() - 2);
  }

  /**
   * Outputs one list of commands on a shape and produces one output line for the textual view.
   *
   * @param commands The commands being done during this line.
   * @return The old and new values after the commands are called.
   */
  private String valueLine(List<ICommand> commands) {
    String s = "motion ";
    IShape shape = commands.get(0).getShapes().get(commands.get(0).getShapeName());
    s = s + shape.returnName() + " ";
    s = s + shape.toStringAtTick(commands.get(0).startTime() / this.tempo,
        this.model.getLastTick() / this.tempo) + "    ";
    for (ICommand com : commands) {
      shape = this.model.simulate(com, shape);
      this.shapes.put(shape.returnName(), shape);
      for (ICommand c : this.shapeComs.get(shape.returnName())) {
        c.updateShapes(shapes);
      }
      for (ICommand c : commands) {
        c.updateShapes(shapes);
      }
    }
    s = s + shape.toStringAtTick(commands.get(0).endTime() / this.tempo,
        this.model.getLastTick());
    return s + "\n";
  }

  /**
   * Creates a textual representation of the shape doing nothing during this interval.
   *
   * @param shape     The shape's status that is being written down.
   * @param highStart The start time.
   * @param lowEnd    The end time.
   * @return The entire line in text form.
   */
  private String emptyLine(IShape shape, int highStart, int lowEnd) {
    String s = "motion ";
    s = s + shape.returnName() + " ";
    s = s + shape.toStringAtTick(lowEnd, highStart) + "    ";
    s = s + shape.toStringAtTick(lowEnd, highStart);
    return s + "\n";
  }

  private String shapeBlock(IShape shape, AbstractMap<String, IShape> shapes) {

    String s = "shape " + shape.returnName()
        + " " + shape.returnType() + "\n";

    List<ICommand> motions = this.model.getMotions(shape, shapes);
    AbstractMap<Integer, List<ICommand>> startTimeCommands = this.model.startTree(motions);
    Set<Integer> startTimes = startTimeCommands.keySet();
    List<Integer> startTimes2 = new ArrayList<Integer>();
    for (Integer i : startTimes) {
      startTimes2.add(i);
    }
    Collections.sort(startTimes2);
    int index = 0;
    if (shape.getStartTick() < startTimes2.get(0)) {
      s = s + this.emptyLine(shape, shape.getStartTick(), startTimes2.get(0));
    }
    for (Integer i : startTimes) {
      shape = shapes.get(shape.returnName());
      motions = this.model.getMotions(shape, shapes);
      startTimeCommands = this.model.startTree(motions);
      if (index - 1 < startTimes2.size() && index - 1 > 0) {
        if (startTimes2.get(index) >
            startTimeCommands.get(startTimes2.get(index - 1)).get(0).endTime()) {
          s = s + this.emptyLine(shape, motions.get(index - 1).startTime(),
              startTimeCommands.get(i).get(0).endTime());
          s = s + this.valueLine(startTimeCommands.get(i));
        } else {
          s = s + this.valueLine(startTimeCommands.get(i));
        }
      } else {
        s = s + valueLine(startTimeCommands.get(i));
      }
      index++;
    }
    shape = shapes.get(shape.returnName());
    motions = this.model.getMotions(shape, shapes);
    startTimeCommands = this.model.startTree(motions);
    int currIndex = 0;
    if (index < startTimes2.size()) {
      s = s + this.valueLine(startTimeCommands.get(startTimes2.get(startTimes2.size() - 1)));
      currIndex = startTimeCommands.get(startTimes2.get(startTimes2.size() - 1)).get(0).endTime();
    }
    if (currIndex < this.model.getLastTick()) {
      s = s + this.emptyLine(shape, currIndex,
          this.model.getLastTick());
    }
    return s;
  }

  /**
   * Appends the textual view to this view's appendable.
   */
  @Override
  public void render() {
    try {
      ap.append(this.toString());
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  /**
   * Changes this view's tempo to be the given tempo.
   *
   * @param tempo The tempo to be changed to.
   */
  @Override
  public void changeTempoTo(int tempo) {
    this.tempo = tempo;
  }

  @Override
  public void changeIndicator(String name) {
    //asdsad
  }
}


