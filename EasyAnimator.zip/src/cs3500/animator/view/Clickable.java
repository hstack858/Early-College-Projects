package cs3500.animator.view;

import cs3500.controller.Features;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JComponent;

/**
 * A class to represent a mouse listener with a component field and a name.
 */
class Clickable implements MouseListener {

  protected JComponent comp;
  protected boolean clicked;
  protected String name;
  protected Features features;


  /**
   * Constructor that takes in a component and its name.
   *
   * @param comp The component (button in our case).
   * @param name The name of the component.
   */
  Clickable(JComponent comp, String name, Features features) {
    this.comp = comp;
    this.clicked = false;
    this.name = name;
    this.features = features;
  }

  /**
   * Invoked when the mouse button has been clicked (pressed and released) on a component.
   *
   * @param e the event to be processed
   */
  @Override
  public void mouseClicked(MouseEvent e) {
    //We only use mousePressed and ignore mouseClicked in our implementation.
  }

  /**
   * Invoked when a mouse button has been pressed on a component.
   *
   * @param e the event to be processed
   */
  @Override
  public void mousePressed(MouseEvent e) {
    this.clicked = true;
  }

  /**
   * Invoked when a mouse button has been released on a component.
   *
   * @param e the event to be processed
   */
  @Override
  public void mouseReleased(MouseEvent e) {
    if (this.clicked) {
      if (this.name.equals("play")) {
        features.play();
      }
      if (this.name.equals("pause")) {
        features.pause();
      }
      if (this.name.equals("restart")) {
        features.restart();
      }
      if (this.name.equals("speedUp")) {
        features.speedUp();
      }
      if (this.name.equals("slowDown")) {
        features.slowDown();
      }
      if (this.name.equals("loop")) {
        features.loop();
      }
    }
    this.clicked = false;
  }

  /**
   * Invoked when the mouse enters a component.
   *
   * @param e the event to be processed
   */
  @Override
  public void mouseEntered(MouseEvent e) {
    features.changeIndicator(name);
  }

  /**
   * Invoked when the mouse exits a component.
   *
   * @param e the event to be processed
   */
  @Override
  public void mouseExited(MouseEvent e) {
    features.changeIndicator(name);
  }
}
