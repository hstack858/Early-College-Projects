package cs3500.animator.view;

import cs3500.controller.Features;
import cs3500.model.IViewModel;
import cs3500.model.shapes.IShape;
import java.awt.event.MouseListener;
import java.util.AbstractMap;
import javax.swing.JButton;
import javax.swing.JComponent;

/**
 * Class to represent the interactive view that can support the extra credit features.
 */
public class ExtraInteractiveView extends SimpleInteractiveView implements IExtraView {

  protected ExtraAnimationPanel panel;
  protected JComponent toggle;
  protected JComponent discrete;
  private boolean fill = true;

  /**
   * Creates a simple interactive view from a model and initial speed.
   *
   * @param model The model this view will animate.
   * @param tempo The initial speed this view will produce the animation at.
   */
  public ExtraInteractiveView(IViewModel model, int tempo) {

    super(model, tempo);

  }

  /**
   * Method to create the panel for the interactive view.
   */
  public void createPanel() {
    this.panel = new ExtraAnimationPanel(this.shapesInOrder,
        this.model.getInProgress(this.model.getShapes()), this.model.getShapes(),
        this.model.getTick());
    this.panel.setSize(model.getWidth(), model.getHeight());
    this.add(this.panel);
  }

  @Override
  public void render() {

    this.panel.setFill(this.fill);

    this.shapesInOrder = model.getShapesInOrder();
    AbstractMap<String, IShape> shapes = model.getShapes();
    this.panel.setShapesInOrder(this.shapesInOrder);
    this.panel.setShapes(shapes);
    this.panel.setInProgress(this.model.getInProgress(shapes));
    this.panel.setTick(this.model.getTick());
    this.repaint();
  }

  /**
   * Adds the features to this view.
   *
   * @param features The mouse listeners for this view.
   */
  public void addFeatures(Features features) {

    MouseListener playL = new ExtraClickable(play, "play", features);
    MouseListener pauseL = new ExtraClickable(pause, "pause", features);
    MouseListener restartL = new ExtraClickable(restart, "restart", features);
    MouseListener loopL = new ExtraClickable(loop, "loop", features);
    MouseListener speedUpL = new ExtraClickable(speedUp, "speedUp", features);
    MouseListener slowDownL = new ExtraClickable(slowDown, "slowDown", features);
    MouseListener toggleL = new ExtraClickable(toggle, "toggle", features);
    MouseListener discreteL = new ExtraClickable(discrete, "discrete", features);

    play.addMouseListener(playL);
    pause.addMouseListener(pauseL);
    restart.addMouseListener(restartL);
    loop.addMouseListener(loopL);
    speedUp.addMouseListener(speedUpL);
    slowDown.addMouseListener(slowDownL);
    toggle.addMouseListener(toggleL);
    discrete.addMouseListener(discreteL);

  }

  protected void makeButtons() {
    super.makeButtons();
    toggle = new JButton("toggle");
    discrete = new JButton("discrete");
  }

  protected void makeButtonMap() {
    super.makeButtonMap();
    this.buttons.put("toggle", toggle);
    this.buttons.put("discrete", discrete);
  }

  protected void makeButtonStatusMap() {
    super.makeButtonStatusMap();
    this.buttonStatus.put("toggle", false);
    this.buttonStatus.put("discrete", false);
  }

  protected void setButtonBounds() {
    super.setButtonBounds();
    toggle.setBounds(xPos, yPos + 100, 100, 50);
    discrete.setBounds(xPos + 100, yPos + 100, 100, 50);
  }

  protected void addButtonsToControls() {
    super.addButtonsToControls();
    this.controls.add(toggle);
    this.controls.add(discrete);
  }

  @Override
  public void toggleFill() {
    this.fill = !this.fill;
  }
}
