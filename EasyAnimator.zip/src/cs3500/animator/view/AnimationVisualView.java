package cs3500.animator.view;

import cs3500.model.IViewModel;
import cs3500.model.shapes.IShape;
import java.awt.Graphics2D;
import java.util.AbstractMap;
import java.util.List;
import javax.swing.JFrame;

/**
 * The view component of the MVC design that is a JFrame object that contains an animation model and
 * uses that to display any shape objects onto the screen.
 */
public class AnimationVisualView extends JFrame implements IAnimationView {

  protected final Graphics2D graphics;
  protected final IViewModel model;
  protected AnimationPanel panel;
  protected int tempo;
  protected List<IShape> shapesInOrder;

  /**
   * Visual view for animation.
   *
   * @param model model that this view is displaying
   * @param tempo speed in ticks per second to display view refreshed every tick
   */
  public AnimationVisualView(IViewModel model, int tempo) {
    super();
    this.model = model;
    this.tempo = tempo;

    //setting up the frame
    setSize(model.getWidth(), model.getHeight() + 30);
    setLocation(model.getX(), model.getY());
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    this.graphics = (Graphics2D) this.getGraphics();

    //setting up the canvas
    this.createPanel();
    makeVisible();

  }

  /**
   * Method that creates the panel for the visual view.
   */
  public void createPanel() {
    this.panel = new AnimationPanel(this.shapesInOrder,
        this.model.getInProgress(this.model.getShapes()), this.model.getShapes(),
        this.model.getTick());
    this.panel.setSize(model.getWidth(), model.getHeight());
    this.add(this.panel);
  }

  @Override
  public void render() {
    this.shapesInOrder = model.getShapesInOrder();
    AbstractMap<String, IShape> shapes = model.getShapes();
    this.panel.setShapesInOrder(this.shapesInOrder);
    this.panel.setShapes(shapes);
    this.panel.setInProgress(this.model.getInProgress(shapes));
    this.panel.setTick(this.model.getTick());
    this.repaint();

  }

  /**
   * Makes this JComponent visible.
   */
  public void makeVisible() {
    setVisible(true);
  }

  /**
   * Changes tempo of the view to given tempo.
   *
   * @param tempo to change to.
   */
  public void changeTempoTo(int tempo) {
    this.tempo = tempo;
  }

  @Override
  public void changeIndicator(String name) {
    //asdsad
  }

}

