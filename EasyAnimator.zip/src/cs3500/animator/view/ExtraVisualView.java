package cs3500.animator.view;

import cs3500.model.IViewModel;

/**
 * Class to represent the visual view and support the extra features with it.
 */
public class ExtraVisualView extends AnimationVisualView implements IExtraView {

  /**
   * Visual view for animation.
   *
   * @param model model that this view is displaying
   * @param tempo speed in ticks per second to display view refreshed every tick
   */
  public ExtraVisualView(IViewModel model, int tempo) {
    super(model, tempo);
  }

  @Override
  public void toggleFill() {
    // ToggleFill not needed for this view.
  }
}
