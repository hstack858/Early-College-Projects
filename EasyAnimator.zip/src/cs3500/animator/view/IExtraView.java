package cs3500.animator.view;

/**
 * Interface to represent the view classes which support the extra credit features.
 */
public interface IExtraView extends IAnimationView {

  /**
   * Toggle whether shapes are filled or not.
   */
  void toggleFill();

}
