package cs3500.animator.view;

/**
 * Interface to represent a way of viewing our easy animator model's state.
 */
public interface IAnimationView {

  /**
   * Runs the animation.
   */
  void render();

  /**
   * Changes tempo of the view.
   */
  void changeTempoTo(int tempo);

  /**
   * Change indicator of button in view.
   *
   * @param name of button to change
   */
  void changeIndicator(String name);
}
