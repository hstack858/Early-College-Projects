package cs3500.animator.view;

import cs3500.model.IViewModel;
import cs3500.model.commands.ICommand;
import cs3500.model.shapes.IShape;
import cs3500.model.shapes.Posn;
import cs3500.model.shapes.RGB;
import java.io.IOException;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

/**
 * Class that builds an SVG textual output based on a given model.
 */
public class ExtraSVGView implements IExtraView {

  private IViewModel model;
  private int tempo;
  private List<IShape> shapesInOrder;
  private Appendable ap;
  private List<ICommand> commandsInOrder;
  private AbstractMap<Integer, List<ICommand>> startTimes;
  private AbstractMap<String, IShape> initializedShapes;
  private AbstractMap<String, String> shapeRepresentations;

  /**
   * Constructor that takes in the model to animate and the tempo at which to animate it.
   *
   * @param model The model being animated.
   * @param tempo The speed at which it will be animated.
   */
  public ExtraSVGView(IViewModel model, int tempo, Appendable ap) {
    if (model == null) {
      throw new IllegalArgumentException("Null model not allowed");
    }
    if (tempo < 0) {
      throw new IllegalArgumentException("Negative tempo not allowed");
    }
    this.model = model;
    this.tempo = tempo;
    this.commandsInOrder = new ArrayList<ICommand>();
    this.shapesInOrder = this.model.getShapesInOrder();
    this.ap = ap;
    this.startTimes = new TreeMap<Integer, List<ICommand>>();
    this.initializedShapes = new TreeMap<String, IShape>();
    this.shapeRepresentations = new TreeMap<String, String>();
    for (IShape shape : this.shapesInOrder) {
      if (shape.returnType().equals("plus")) {
        this.shapeRepresentations.put(shape.returnName() + "1", "");
        this.shapeRepresentations.put(shape.returnName() + "2", "");
      } else {
        this.shapeRepresentations.put(shape.returnName(), "");
      }
    }
  }


  /**
   * The method that outputs the entire SVG textual output.
   */
  public void render() {
    try {
      ap.append(this.createIntroduction());
      this.createAnimations();
      for (Integer i : this.startTimes.keySet()) {
        List<ICommand> comsAti = this.startTimes.get(i);
        // Calls callCommand on each command at this tick for this shape
        for (ICommand c : comsAti) {
          this.callCommand(c);
          for (ICommand c2 : comsAti) {
            if (c.getShapeName().equals(c2.getShapeName())) {
              IShape sh = c.getShape();
              c.setShape(c.simulate(sh));
              c2.setShape(sh);
            }
          }
        }
      }
      AbstractMap<String, IShape> modelShapes = this.model.getShapes();

      for (IShape shapeInOrder : this.shapesInOrder) {
        if (shapeInOrder.returnType().equals("plus")) {
          ap.append(this.shapeRepresentations.get(shapeInOrder.returnName() + "1") + "</rect>\n");
          ap.append(this.shapeRepresentations.get(shapeInOrder.returnName() + "2") + "</rect>\n");
        } else if (shapeInOrder.returnType().equals("oval")) {
          ap.append(this.shapeRepresentations.get(shapeInOrder.returnName()) + "</ellipse>\n");
        } else {
          ap.append(this.shapeRepresentations.get(shapeInOrder.returnName()) + "</rect>\n");
        }
      }
      ap.append("</svg>");
    } catch (IOException i) {
      throw new IllegalArgumentException("Cannot create animation output: append");
    }
  }

  /**
   * Changes the tempo of this view to the given tempo.
   *
   * @param tempo The tempo to be changed to.
   */
  @Override
  public void changeTempoTo(int tempo) {
    this.tempo = tempo;
  }

  @Override
  public void changeIndicator(String name) {
    //asdsad
  }

  /**
   * The introduction to the SVG file.
   *
   * @return The top lines of the SVG file that don't declare or animate any shapes.
   */
  protected String createIntroduction() {
    int width = this.model.getWidth();
    int height = this.model.getHeight();
    int x = this.model.getX();
    int y = this.model.getY();

    String xml = String.format("<svg width=\"%d\" height=\"%d\" version=\"1.1\"\n"
            + " viewBox=\"%d %d %d %d\" xmlns=\"http://www.w3.org/2000/svg\">", width, height, x, y,
        width, height);

    xml = xml + "\n <desc>An animation of your choosing</desc>\n";
    return xml;
  }

  /**
   * Calls createShape on each shape in the model.
   *
   * @return The declaration and animations of each shape in the model.
   */
  protected void createAnimations() {
    // Puts all commands in order of start time into this.commandsInOrder
    List<ICommand> commandsInOrder = new ArrayList<ICommand>();
    for (IShape s : this.shapesInOrder) {
      List<ICommand> list = this.model.getMotions(s, this.model.getShapes());
      commandsInOrder.addAll(list);
    }
    this.commandsInOrder = commandsInOrder;

    // Finds the earliest command for a specific shape (the display command) and puts this
    // shape into a hashmap from its name to its value so each command can grab the correct
    // shape reference (starts at shape's earliest values).
    for (ICommand c : this.commandsInOrder) {
      if (!(this.initializedShapes.keySet().contains(c.getShapeName()))) {
        this.initializedShapes.put(c.getShapeName(), c.getShape());
      } else {
        c.setShape(this.initializedShapes.get(c.getShapeName()));
      }
    }

    // Gives shapes in order the same shape reference the commands have
    int index = 0;
    while (index < this.shapesInOrder.size()) {
      this.shapesInOrder
          .set(index, this.initializedShapes.get(this.shapesInOrder.get(index).returnName()));
      index++;
    }

    // Creates the hashmap of Integer to Command which represents the commands starting
    // at each tick number. This is used to make sure simultaneous commands work correctly.
    int tick = 0;
    int counter = 0;
    while (counter < this.commandsInOrder.size()) {
      for (ICommand c : this.commandsInOrder) {
        if (c.startTime() == tick) {
          if (this.startTimes.keySet().contains(tick)) {
            this.startTimes.get(tick).add(c);
          } else {
            ArrayList<ICommand> newC = new ArrayList<ICommand>();
            newC.add(c);
            this.startTimes.put(tick, newC);
          }
          counter++;
        }
      }
      tick++;
    }

    // Call declare shape on all shapes
    for (IShape s : this.shapesInOrder) {
      this.declareShape(s);
    }
  }

  /**
   * Creates a shape and then calls its animations.
   *
   * @param shape The shape to be declared.
   * @return The shape declaration and all of its animations.
   */
  protected void declareShape(IShape shape) {
    String shapeAnimations = "";
    String shapeType = shape.returnType();
    RGB color = shape.getColor();
    color.roundValues();
    long x = Math.round(shape.getPosition().getX());
    long y = Math.round(shape.getPosition().getY());
    long width = Math.round(shape.getWidth());
    long height = Math.round(shape.getHeight());
    String colorRed = Double.toString(color.getRed()).substring(0, 3);
    if (colorRed.charAt(0) == '0') {
      colorRed = "0";
    }
    colorRed = this.periodHelper(colorRed);

    String colorGreen = Double.toString(color.getGreen()).substring(0, 3);
    if (colorGreen.charAt(0) == '0') {
      colorGreen = "0";
    }
    colorGreen = this.periodHelper(colorGreen);

    String colorBlue = Double.toString(color.getBlue()).substring(0, 3);
    if (colorBlue.charAt(0) == '0') {
      colorBlue = "0";
    }
    colorBlue = this.periodHelper(colorBlue);

    if (shapeType.equals("rect")) {
      shapeAnimations = String.format(
          "<rect id=\"%s\" x=\"%d\" y=\"%d\" width=\"%d\" height=\"%d\" fill="
              + "\"rgb(" + colorRed + "," + colorGreen + "," + colorBlue + ")\" "
              + "visibility=\"hidden\" >",
          shape.returnName(), x, y, width, height, color.getRed(), color.getGreen(),
          color.getBlue());
      shapeAnimations = shapeAnimations + "\n";
      String string1 = this.shapeRepresentations.get(shape.returnName()) + shapeAnimations;
      this.shapeRepresentations.put(shape.returnName(), string1);

    } else if (shapeType.equals("oval")) {
      shapeAnimations = String
          .format("<ellipse id=\"%s\" cx=\"%d\" cy=\"%d\" rx=\"%d\" ry=\"%d\" fill="
                  + "\"rgb(" + colorRed + "," + colorGreen + "," + colorBlue + ")\" "
                  + "visibility=\"hidden\" >",
              shape.returnName(),
              x, y, width / 2, height / 2, color.getRed(), color.getGreen(), color.getBlue());
      shapeAnimations = shapeAnimations + "\n";
      String string1 = this.shapeRepresentations.get(shape.returnName()) + shapeAnimations;
      this.shapeRepresentations.put(shape.returnName(), string1);
    } else if (shapeType.equals("plus")) {
      String rect1 = String.format(
          "<rect id=\"%s\" x=\"%d\" y=\"%d\" width=\"%d\" height=\"%d\" fill="
              + "\"rgb(" + colorRed + "," + colorGreen + "," + colorBlue + ")\" "
              + "visibility=\"hidden\" >",
          shape.returnName() + "1", x + (width / 4), y, width / 2, height, color.getRed(),
          color.getGreen(),
          color.getBlue());
      rect1 = rect1 + "\n";

      String rect2 = String.format(
          "<rect id=\"%s\" x=\"%d\" y=\"%d\" width=\"%d\" height=\"%d\" fill="
              + "\"rgb(" + colorRed + "," + colorGreen + "," + colorBlue + ")\" "
              + "visibility=\"hidden\" >",
          shape.returnName() + "2", x, y + (height / 4), width, height / 2, color.getRed(),
          color.getGreen(),
          color.getBlue());
      rect2 = rect2 + "\n";

      String string1 = this.shapeRepresentations.get(shape.returnName() + "1") + rect1;
      String string2 = this.shapeRepresentations.get(shape.returnName() + "2") + rect2;

      this.shapeRepresentations.put(shape.returnName() + "1", string1);
      this.shapeRepresentations.put(shape.returnName() + "2", string2);
    }
  }

  /**
   * Determines which type of animation this shape should go through based on a given command.
   *
   * @param com The command that this shape will be animated through.
   * @return The svg animation output of this shape going through this single command.
   */
  protected void callCommand(ICommand com) {
    String commandType = this.whatCommandType(com);
    if (commandType.equals("move")) {
      moveXML(com);
    } else if (commandType.equals("color")) {
      changeColorXML(com);
    } else if (commandType.equals("transform")) {
      transformXML(com);
    } else if (commandType.equals("display")) {
      displayXML(com);
    } else {
      throw new IllegalArgumentException("Invalid command type for svg");
    }
  }

  protected void displayXML(ICommand com) {
    long start = Math.round((com.startTime() / this.tempo) * 1000);
    long duration = Math.round(1000 * ((model.getLastTick() - com.startTime()) / this.tempo));
    String builder = "    " + "<set attributeName=\"visibility\" attributeType=\"CSS\" " +
        "to=\"visible\" begin=\"" + Long.toString(start) + "ms\" dur =\"" + Long.toString(duration)
        + "ms\" fill=\"freeze\" />";
    builder = builder + "\n";
    if (com.getShape().returnType().equals("plus")) {
      String newString1 = this.shapeRepresentations.get(com.getShapeName() + "1") + builder;
      String newString2 = this.shapeRepresentations.get(com.getShapeName() + "2") + builder;
      this.shapeRepresentations.put(com.getShapeName() + "1", newString1);
      this.shapeRepresentations.put(com.getShapeName() + "2", newString2);
    } else {
      String newString = this.shapeRepresentations.get(com.getShapeName()) + builder;
      this.shapeRepresentations.put(com.getShapeName(), newString);
    }
  }

  /**
   * Writes a change color animation for a shape in svg format for a given command.
   *
   * @param com The change color command that this shape will go through.
   * @return The textual representation of the change color command on its shape.
   */
  protected void changeColorXML(ICommand com) {
    IShape shape = com.getShape();
    RGB color = shape.getColor();
    color.roundValues();
    IShape shape2 = com.simulate(shape);
    RGB color2 = shape2.getColor();
    color2.roundValues();
    String colorRed = Double.toString(color.getRed()).substring(0, 3);
    if (colorRed.charAt(0) == '0') {
      colorRed = "0";
    }
    colorRed = this.periodHelper(colorRed);
    String colorGreen = Double.toString(color.getGreen()).substring(0, 3);
    if (colorGreen.charAt(0) == '0') {
      colorGreen = "0";
    }
    colorGreen = this.periodHelper(colorGreen);
    String colorBlue = Double.toString(color.getBlue()).substring(0, 3);
    if (colorBlue.charAt(0) == '0') {
      colorBlue = "0";
    }
    colorBlue = this.periodHelper(colorBlue);
    String colorRed2 = Double.toString(color2.getRed()).substring(0, 3);
    if (colorRed2.charAt(0) == '0') {
      colorRed2 = "0";
    }
    colorRed2 = this.periodHelper(colorRed2);
    String colorGreen2 = Double.toString(color2.getGreen()).substring(0, 3);
    if (colorGreen2.charAt(0) == '0') {
      colorGreen2 = "0";
    }
    colorGreen2 = this.periodHelper(colorGreen2);
    String colorBlue2 = Double.toString(color2.getBlue()).substring(0, 3);
    if (colorBlue2.charAt(0) == '0') {
      colorBlue2 = "0";
    }
    colorBlue2 = this.periodHelper(colorBlue2);

    long start = Math.round((com.startTime() / this.tempo) * 1000);
    long duration = Math.round(1000 * (com.endTime() - com.startTime()) / this.tempo);
    String comString =
        "    " + String.format("<animate attributeType=\"xml\" begin=\"%dms\" dur=\"%dms\""
            + " attributeName=\"fill\""
            + " from=\"rgb(" + colorRed + "," + colorGreen +
            "," + colorBlue + ")\" to=\"rgb(" + colorRed2 + "," + colorGreen2 +
            "," + colorBlue2 + ")\" fill=\"freeze\" />", start, duration);

    comString = comString + "\n";

    if (com.getShape().returnType().equals("plus")) {
      String newString1 =
          this.shapeRepresentations.get(com.getShapeName() + "1") + comString + "\n";
      String newString2 =
          this.shapeRepresentations.get(com.getShapeName() + "2") + comString + "\n";
      this.shapeRepresentations.put(com.getShapeName() + "1", newString1);
      this.shapeRepresentations.put(com.getShapeName() + "2", newString2);
    } else {
      String newString = this.shapeRepresentations.get(com.getShapeName()) + comString + "\n";
      this.shapeRepresentations.put(com.getShapeName(), newString);
    }
  }

  /**
   * Helps format the periods in long decimal color values.
   *
   * @param s The color value with potential periods
   * @return The color value without any periods.
   */
  protected String periodHelper(String s) {
    if (s.length() == 3) {
      if (s.charAt(2) == '.') {
        return s.substring(0, 2);
      } else if (s.charAt(1) == '.') {
        return s.substring(0, 1);
      } else if (s.charAt(0) == '.') {
        return "0";
      }
    } else if (s.length() == 2) {
      if (s.charAt(1) == '.') {
        return s.substring(0, 1);
      } else if (s.charAt(0) == '.') {
        return "0";
      }
    } else if (s.length() == 1) {
      if (s.charAt(0) == '.') {
        return "0";
      }
    }
    return s;
  }

  /**
   * Writes a transform animation for a shape in svg format for a given command.
   *
   * @param com The transform command that this shape will go through.
   * @return The textual representation of the transform command on its shape.
   */
  protected void transformXML(ICommand com) {
    IShape shape = com.getShape();
    double width1 = shape.getWidth();
    double height1 = shape.getHeight();
    IShape shape2 = com.simulate(shape);
    double width2 = shape2.getWidth();
    double height2 = shape2.getHeight();

    boolean widthChange = (width1 != width2);
    boolean heightChange = (height1 != height2);

    String w1s = Double.toString(width1);
    String w2s = Double.toString(width2);
    String h1s = Double.toString(height1);
    String h2s = Double.toString(height2);

    long start = Math.round((com.startTime() / this.tempo) * 1000);
    long duration = Math.round(1000 * (com.endTime() - com.startTime()) / this.tempo);
    String comString = "";
    // Vert
    String comString1Total = "";
    // Horz
    String comString2Total = "";

    boolean plus = false;
    if (com.getShape().returnType().equals("plus")) {
      plus = true;
    }

    if (widthChange && plus) {
      comString2Total =
          "    " + String.format("<animate attributeType=\"xml\" begin=\"%dms\" dur=\"%dms\""
              + " attributeName=\"width\""
              + " from=\"" + w1s + "\" to=\"" + w2s + "\" fill=\"freeze\" />", start, duration);

      width1 = width1 / 2;
      w1s = Double.toString(width1);
      width2 = width2 / 2;
      w2s = Double.toString(width2);

      // Change Position if there is no change Posn
      if (com.getOtherType1() == Integer.MIN_VALUE) {
        String attX = " attributeName=\"x\"";
        double x = shape.getPosition().getX() + (shape.getWidth() / 4);
        double x2 = shape.getPosition().getX() + (shape2.getWidth() / 4);
        String xs = Double.toString(x);
        String x2s = Double.toString(x2);
        long start1 = Math.round((com.startTime() / this.tempo) * 1000);
        long duration1 = Math.round(1000 * (com.endTime() - com.startTime()) / this.tempo);

        String xChanger =
            "    " + String.format("<animate attributeType=\"xml\" begin=\"%dms\" dur=\"%dms\"" +
                    attX + " from=\"" + xs + "\" to=\"" + x2s + "\" fill=\"freeze\" />", start1,
                duration1);
        String string1 = this.shapeRepresentations.get(com.getShapeName() + "1") + xChanger + "\n";
        this.shapeRepresentations.put(com.getShapeName() + "1", string1);
      }

      if (com.getOtherType2() == Integer.MIN_VALUE) {
        String attY = " attributeName=\"y\"";
        double y = shape.getPosition().getY() + (shape.getHeight() / 4);
        double y2 = shape.getPosition().getY() + (shape2.getHeight() / 4);
        String ys = Double.toString(y);
        String y2s = Double.toString(y2);
        long start1 = Math.round((com.startTime() / this.tempo) * 1000);
        long duration1 = Math.round(1000 * (com.endTime() - com.startTime()) / this.tempo);

        String yChanger =
            "    " + String
                .format("<animate attributeType=\"xml\" begin=\"%dms\" dur=\"%dms\"" +
                        attY + " from=\"" + ys + "\" to=\"" + y2s + "\" fill=\"freeze\" />", start1,
                    duration1);
        String string1 = this.shapeRepresentations.get(com.getShapeName() + "2") + yChanger + "\n";
        this.shapeRepresentations.put(com.getShapeName() + "2", string1);
      }

      comString1Total =
          "    " + String.format("<animate attributeType=\"xml\" begin=\"%dms\" dur=\"%dms\""
              + " attributeName=\"width\""
              + " from=\"" + w1s + "\" to=\"" + w2s + "\" fill=\"freeze\" />", start, duration);
    }

    if (widthChange && !(plus)) {
      comString =
          "    " + String.format("<animate attributeType=\"xml\" begin=\"%dms\" dur=\"%dms\""
              + " attributeName=\"width\""
              + " from=\"" + w1s + "\" to=\"" + w2s + "\" fill=\"freeze\" />", start, duration);
    }
    if (widthChange && heightChange && !(plus)) {
      comString = comString + "\n";
    }

    if (widthChange && heightChange && plus) {
      comString1Total = comString1Total + "\n";
      comString2Total = comString2Total + "\n";
    }

    if (heightChange && !(plus)) {
      comString =
          "    " + String.format("<animate attributeType=\"xml\" begin=\"%dms\" dur=\"%dms\""
              + " attributeName=\"height\""
              + " from=\"" + h1s + "\" to=\"" + h2s + "\" fill=\"freeze\" />", start, duration);
    }

    if (heightChange && plus) {
      comString1Total = comString1Total + "    " + String
          .format("<animate attributeType=\"xml\" begin=\"%dms\" dur=\"%dms\""
              + " attributeName=\"height\""
              + " from=\"" + h1s + "\" to=\"" + h2s + "\" fill=\"freeze\" />", start, duration);

      height1 = height1 / 2;
      h1s = Double.toString(height1);
      height2 = height2 / 2;
      h2s = Double.toString(height2);

      comString2Total = comString2Total + "    " + String
          .format("<animate attributeType=\"xml\" begin=\"%dms\" dur=\"%dms\""
              + " attributeName=\"height\""
              + " from=\"" + h1s + "\" to=\"" + h2s + "\" fill=\"freeze\" />", start, duration);
    }

    for (Integer i : this.startTimes.keySet()) {
      if (i > com.startTime()) {
        for (ICommand c : this.startTimes.get(i)) {
          c.setShape(shape2);
        }
      }
    }
    comString = comString + "\n";
    if (com.getShape().returnType().equals("plus")) {
      String newString1 =
          this.shapeRepresentations.get(com.getShapeName() + "1") + comString1Total + "\n";
      String newString2 =
          this.shapeRepresentations.get(com.getShapeName() + "2") + comString2Total + "\n";
      this.shapeRepresentations.put(com.getShapeName() + "1", newString1);
      this.shapeRepresentations.put(com.getShapeName() + "2", newString2);
    } else {
      String newString = this.shapeRepresentations.get(com.getShapeName()) + comString + "\n";
      this.shapeRepresentations.put(com.getShapeName(), newString);
    }
  }

  /**
   * Writes a move animation for a shape in svg format for a given command.
   *
   * @param com The move command that this shape will go through.
   * @return The textual representation of the move command on its shape.
   */
  protected void moveXML(ICommand com) {
    IShape shape1 = com.getShape();
    IShape shape3 = com.simulate(shape1);
    double x = shape1.getPosition().getX();
    double y = shape1.getPosition().getY();
    double x2 = shape3.getPosition().getX();
    double y2 = shape3.getPosition().getY();

    boolean xChange = (x != x2);
    boolean yChange = (y != y2);
    long start1 = Math.round((com.startTime() / this.tempo) * 1000);
    long duration1 = Math.round(1000 * (com.endTime() - com.startTime()) / this.tempo);

    String stringCom = "";
    String xs = Double.toString(x);
    String ys = Double.toString(y);
    String x2s = Double.toString(x2);
    String y2s = Double.toString(y2);
    String attX;
    String attY;
    if (shape1.returnType().equals("rect") || shape1.returnType().equals("plus")) {
      attX = " attributeName=\"x\"";
    } else {
      attX = " attributeName=\"cx\"";
    }
    if (shape1.returnType().equals("rect") || shape1.returnType().equals("plus")) {
      attY = " attributeName=\"y\"";
    } else {
      attY = " attributeName=\"cy\"";
    }

    boolean plus = false;
    if (shape1.returnType().equals("plus")) {
      plus = true;
    }

    String stringCom1Total = "";
    String stringCom2Total = "";

    boolean andTrans1 = false;
    boolean andTrans2 = false;

    if (xChange && plus) {

      if (com.getOtherType1() != Integer.MIN_VALUE) {
        andTrans1 = true;
      }

      stringCom2Total =
          "    " + String.format("<animate attributeType=\"xml\" begin=\"%dms\" dur=\"%dms\"" +
                  attX + " from=\"" + xs + "\" to=\"" + x2s + "\" fill=\"freeze\" />", start1,
              duration1);

      if ((andTrans1)) {
        x = x + (shape1.getWidth() / 4);
        xs = Double.toString(x);
        x2 = x2 + (com.getOtherType1() / 4);
        x2s = Double.toString(x2);
      } else {
        x = x + (shape1.getWidth() / 4);
        xs = Double.toString(x);
        x2 = x2 + (com.getShape().getWidth() / 4);
        x2s = Double.toString(x2);
      }

      stringCom1Total =
          "    " + String.format("<animate attributeType=\"xml\" begin=\"%dms\" dur=\"%dms\"" +
                  attX + " from=\"" + xs + "\" to=\"" + x2s + "\" fill=\"freeze\" />", start1,
              duration1);


    }

    if (xChange && !(plus)) {
      stringCom =
          "    " + String.format("<animate attributeType=\"xml\" begin=\"%dms\" dur=\"%dms\"" +
                  attX + " from=\"" + xs + "\" to=\"" + x2s + "\" fill=\"freeze\" />", start1,
              duration1);
    }
    if (xChange && yChange && !(plus)) {
      stringCom = stringCom + "\n";
    }

    if (xChange && yChange && plus) {
      stringCom1Total = stringCom1Total + "\n";
      stringCom2Total = stringCom2Total + "\n";
    }

    if (yChange && plus) {

      if (com.getOtherType2() != Integer.MIN_VALUE) {
        andTrans2 = true;
      }
      stringCom1Total = stringCom1Total + "    " + String
          .format("<animate attributeType=\"xml\" begin=\"%dms\" dur=\"%dms\"" +
                  attY + " from=\"" + ys + "\" to=\"" + y2s + "\" fill=\"freeze\" />", start1,
              duration1);

      if ((andTrans2)) {
        y = y + (shape1.getHeight() / 4);
        ys = Double.toString(y);
        y2 = y2 + (com.getOtherType2() / 4);
        y2s = Double.toString(y2);
      } else {
        y = y + (shape1.getHeight() / 4);
        ys = Double.toString(y);
        y2 = y2 + (com.getShape().getHeight() / 4);
        y2s = Double.toString(y2);
      }

      stringCom2Total = stringCom2Total + "    " + String
          .format("<animate attributeType=\"xml\" begin=\"%dms\" dur=\"%dms\"" +
                  attY + " from=\"" + ys + "\" to=\"" + y2s + "\" fill=\"freeze\" />", start1,
              duration1);
    }

    if (yChange && !(plus)) {
      stringCom = stringCom + "    " + String
          .format("<animate attributeType=\"xml\" begin=\"%dms\" dur=\"%dms\"" +
                  attY + " from=\"" + ys + "\" to=\"" + y2s + "\" fill=\"freeze\" />", start1,
              duration1);
    }
    for (Integer i : this.startTimes.keySet()) {
      if (i > com.startTime()) {
        for (ICommand c : this.startTimes.get(i)) {
          c.setShape(shape3);
        }
      }
    }
    stringCom = stringCom + "\n";
    if (com.getShape().returnType().equals("plus")) {
      String newString1 =
          this.shapeRepresentations.get(com.getShapeName() + "1") + stringCom1Total + "\n";
      String newString2 =
          this.shapeRepresentations.get(com.getShapeName() + "2") + stringCom2Total + "\n";
      this.shapeRepresentations.put(com.getShapeName() + "1", newString1);
      this.shapeRepresentations.put(com.getShapeName() + "2", newString2);
    } else {
      String newString = this.shapeRepresentations.get(com.getShapeName()) + stringCom + "\n";
      this.shapeRepresentations.put(com.getShapeName(), newString);
    }
  }

  /**
   * Determines which type of command this command is.
   *
   * @param com The command that we are trying to figure out the type of.
   * @return The type of command com is in string form/
   */
  protected String whatCommandType(ICommand com) {
    IShape shape1 = com.getShape();
    Posn ogPosn = shape1.getPosition();
    RGB ogColor = shape1.getColor();
    ogColor.roundValues();
    double ogWidth = shape1.getWidth();
    double ogHeight = shape1.getHeight();

    IShape shape3 = com.simulate(shape1);
    Posn posn2 = shape3.getPosition();
    RGB color2 = shape3.getColor();
    color2.roundValues();
    double width3 = shape3.getWidth();
    double height3 = shape3.getHeight();

    if (!(ogPosn.equals(posn2))) {
      return "move";
    } else if ((!(ogColor.equals(color2)))) {
      return "color";
    } else if (!(ogWidth == width3 && ogHeight == height3)) {
      return "transform";
    } else {
      return "display";
    }
  }

  /**
   * Toggles the fill mode of this view.
   */
  @Override
  public void toggleFill() {
    // Not needed for the SVG view.
  }
}

