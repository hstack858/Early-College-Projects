package cs3500.animator.view;

import cs3500.controller.Features;
import cs3500.model.IViewModel;
import java.awt.Color;
import java.awt.event.MouseListener;
import java.util.Map;
import java.util.TreeMap;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JPanel;

/**
 * A class to represent a visual view of an animation that is able to be interacted with. These
 * interactions include: playing, pausing, looping, restarting, speeding up and slowing down.
 */
public class SimpleInteractiveView extends AnimationVisualView {

  protected Map<String, JComponent> buttons;
  protected Map<String, Boolean> buttonStatus;
  protected JPanel controls;

  protected JComponent play;
  protected JComponent pause;
  protected JComponent restart;
  protected JComponent loop;
  protected JComponent speedUp;
  protected JComponent slowDown;

  protected int xPos;
  protected int yPos;


  /**
   * Creates a simple interactive view from a model and initial speed.
   *
   * @param model The model this view will animate.
   * @param tempo The initial speed this view will produce the animation at.
   */
  public SimpleInteractiveView(IViewModel model, int tempo) {

    super(model, tempo);

    this.buttons = new TreeMap<>();
    this.buttonStatus = new TreeMap<>();

    int height;

    if (model.getHeight() < 180) {
      height = 180;
    } else {
      height = model.getHeight() + 30;
    }

    setSize(model.getWidth() + 300, height);

    this.controls = new JPanel();

    xPos = model.getWidth();
    yPos = 0;

    this.controls.setBackground(Color.white);
    this.controls.setLayout(null);
    this.controls.setBounds(model.getX() + model.getWidth(), model.getY(), 300, 300);

    makeButtons();

    makeButtonMap();

    makeButtonStatusMap();

    setButtonBounds();

    addButtonsToControls();

    this.add(controls);

    makeVisible();

  }

  /**
   * Changes the indicator light of the button with the given name.
   *
   * @param name The name of the button who's indicator will be changed.
   */
  public void changeIndicator(String name) {

    for (String buttonName : buttons.keySet()) {
      if (name.equals(buttonName)) {
        if (buttonStatus.get(name)) {
          this.buttons.get(name).setBackground(Color.white);
        } else {
          this.buttons.get(name).setBackground(Color.green);
        }
        this.buttons.get(name).setOpaque(true);
      }
    }

    buttonStatus.replace(name, !(buttonStatus.get(name)));
  }

  /**
   * Changes the tempo of this view to be the given tempo.
   *
   * @param tempo The tempo to be changed to.
   */
  public void changeTempoTo(int tempo) {
    this.tempo = tempo;
  }

  /**
   * Adds the features to this view.
   *
   * @param features The mouse listeners for this view.
   */
  public void addFeatures(Features features) {
    MouseListener playL = new Clickable(play, "play", features);
    MouseListener pauseL = new Clickable(pause, "pause", features);
    MouseListener restartL = new Clickable(restart, "restart", features);
    MouseListener loopL = new Clickable(loop, "loop", features);
    MouseListener speedUpL = new Clickable(speedUp, "speedUp", features);
    MouseListener slowDownL = new Clickable(slowDown, "slowDown", features);

    play.addMouseListener(playL);
    pause.addMouseListener(pauseL);
    restart.addMouseListener(restartL);
    loop.addMouseListener(loopL);
    speedUp.addMouseListener(speedUpL);
    slowDown.addMouseListener(slowDownL);

  }

  protected void makeButtons() {
    play = new JButton("play");
    pause = new JButton("pause");
    restart = new JButton("restart");
    loop = new JButton("loop");
    speedUp = new JButton("speedUp");
    slowDown = new JButton("slowDown");
  }

  protected void makeButtonMap() {
    this.buttons.put("play", play);
    this.buttons.put("pause", pause);
    this.buttons.put("restart", restart);
    this.buttons.put("loop", loop);
    this.buttons.put("speedUp", speedUp);
    this.buttons.put("slowDown", slowDown);
  }

  protected void makeButtonStatusMap() {
    this.buttonStatus.put("play", false);
    this.buttonStatus.put("pause", false);
    this.buttonStatus.put("restart", false);
    this.buttonStatus.put("loop", false);
    this.buttonStatus.put("speedUp", false);
    this.buttonStatus.put("slowDown", false);
  }

  protected void setButtonBounds() {
    play.setBounds(xPos, yPos, 100, 50);
    pause.setBounds(xPos + 100, yPos, 100, 50);
    restart.setBounds(xPos + 200, yPos, 100, 50);
    loop.setBounds(xPos, yPos + 50, 100, 50);
    speedUp.setBounds(xPos + 100, yPos + 50, 100, 50);
    slowDown.setBounds(xPos + 200, yPos + 50, 100, 50);
  }

  protected void addButtonsToControls() {
    this.controls.add(play);
    this.controls.add(pause);
    this.controls.add(restart);
    this.controls.add(loop);
    this.controls.add(speedUp);
    this.controls.add(slowDown);
  }

}
