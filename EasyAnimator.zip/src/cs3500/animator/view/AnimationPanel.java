package cs3500.animator.view;

import cs3500.model.commands.ICommand;
import cs3500.model.shapes.IShape;
import java.awt.Graphics;
import java.util.AbstractMap;
import java.util.List;
import javax.swing.JPanel;

/**
 * Panel that represents the canvas to draw to.
 */
public class AnimationPanel extends JPanel {

  AbstractMap<String, IShape> shapes;
  List<IShape> shapesInOrder;
  List<ICommand> inProgress;
  int tick;

  /**
   * Constructor for the panel.
   *
   * @param shapesInOrder shapes from model in order.
   * @param inProgress    commands in progress.
   * @param shapes        shapes not in order.
   * @param tick          the current tick.
   */
  AnimationPanel(List<IShape> shapesInOrder, List<ICommand> inProgress,
      AbstractMap<String, IShape> shapes, int tick) {

    super();
    this.shapesInOrder = shapesInOrder;
    this.inProgress = inProgress;
    this.shapes = shapes;
    this.tick = tick;

  }

  /**
   * Overrides paintComponent from JPanel and paints model shapes.
   *
   * @param graphics object to draw to.
   */
  protected void paintComponent(Graphics graphics) {

    super.paintComponent(graphics);
    if (this.shapesInOrder != null) {
      for (IShape shape : shapesInOrder) {
        if (shape.getStartTick() <= this.tick) {
          for (ICommand c : inProgress) {
            if (c.getShapeName().equals(shape.returnName())) {
              paintShape(this.shapes.get(shape.returnName()), graphics);
            }
          }
        }
      }
    }

  }

  /**
   * Paints the shape onto a graphic.
   */
  protected void paintShape(IShape shape, Graphics graphics) {

    if (shape.getPosition() != null && shape.getColor() != null) {

      graphics.setColor(shape.getColor().toColor());

      if (shape.returnType().equals("rect")) {

        graphics.fillRect((int) shape.getPosition().getX(), (int) shape.getPosition().getY(),
            (int) shape.getWidth(), (int) shape.getHeight());

      } else if (shape.returnType().equals("oval")) {

        graphics.fillOval((int) shape.getPosition().getX(), (int) shape.getPosition().getY(),
            (int) shape.getWidth(), (int) shape.getHeight());

      } else if (shape.returnType().equals("plus")) {

        // The vertical bar
        graphics.fillRect((int) shape.getPosition().getX()
                + (int) (shape.getWidth() / 4), (int) shape.getPosition().getY(),
            (int) (shape.getWidth() / 2), (int) (shape.getHeight()));
        // The horizontal bar
        graphics.fillRect((int) shape.getPosition().getX(), (int) shape.getPosition().getY()
                + (int) (shape.getHeight() / 4), (int) (shape.getWidth()),
            (int) (shape.getHeight() / 2));

      } else {
        throw new IllegalArgumentException("Unsupported shape to draw");
      }

    }

  }

  /**
   * Sets the shapes in order.
   *
   * @param shapes to set shapes in order to.
   */
  public void setShapesInOrder(List<IShape> shapes) {
    this.shapesInOrder = shapes;
  }

  /**
   * Sets the shape list.
   *
   * @param shapes shapes to set shape list to.
   */
  public void setShapes(AbstractMap<String, IShape> shapes) {
    this.shapes = shapes;
  }

  /**
   * Sets commands in progress.
   *
   * @param inProgress commands to set inProgress to.
   */
  public void setInProgress(List<ICommand> inProgress) {
    this.inProgress = inProgress;
  }

  /**
   * Sets the tick.
   *
   * @param tick to set this tick to.
   */
  public void setTick(int tick) {
    this.tick = tick;
  }

}
