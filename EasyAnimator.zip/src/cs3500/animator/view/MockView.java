package cs3500.animator.view;

import cs3500.controller.Features;
import java.io.IOException;

/**
 * Mock view for testing the controller that writes to a log.
 */
public class MockView implements IAnimationView {

  private final Appendable log;
  private final boolean visualP;

  /**
   * Constructor for the mock view that takes in log to write to and whether it's a visual or not.
   *
   * @param log     to write to.
   * @param visualP boolean on whether it's visual or not.
   */
  public MockView(Appendable log, boolean visualP) {

    this.log = log;
    this.visualP = visualP;

  }

  @Override
  public void render() {

    try {
      this.log.append("view.render()");
    } catch (IOException io) {
      //Making sure appendable can be written to.
    }

  }

  @Override
  public void changeTempoTo(int tempo) {
    try {
      this.log.append("view.changeTempoTo()");
    } catch (IOException io) {
      //Making sure appendable can be written to.
    }
  }

  /**
   * In mock does nothing.
   *
   * @param name of button to change
   */
  public void changeIndicator(String name) {
    //Do nothing
  }

  /**
   * In mock does nothing.
   *
   * @param features features to add to mock.
   */
  public void addFeatures(Features features) {
    //Does nothing in mock
  }

  /**
   * Whether or not this view is visual or txt/svg.
   *
   * @return true if visual, false otherwise.
   */
  public boolean visualP() {
    return visualP;
  }


}
