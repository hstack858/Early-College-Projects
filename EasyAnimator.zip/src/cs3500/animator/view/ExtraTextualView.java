package cs3500.animator.view;

import cs3500.model.IViewModel;

/**
 * Class which supports the extra features for the textual view.
 */
public class ExtraTextualView extends AnimationTextualView implements IExtraView {

  /**
   * Takes in all non in class initialized things.
   *
   * @param model model for view
   * @param tempo speed
   * @param ap    appendable
   */
  public ExtraTextualView(IViewModel model, int tempo, Appendable ap) {
    super(model, tempo, ap);
  }

  @Override
  public void toggleFill() {
    // Does nothing in textual view.
  }
}
