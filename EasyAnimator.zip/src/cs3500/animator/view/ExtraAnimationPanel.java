package cs3500.animator.view;

import cs3500.model.commands.ICommand;
import cs3500.model.shapes.IShape;
import java.awt.Graphics;
import java.util.AbstractMap;
import java.util.List;

/**
 * A class to represent the Animation Panel that is needed for the added features.
 */
public class ExtraAnimationPanel extends AnimationPanel {

  private boolean fill = true;

  /**
   * Constructor for the panel.
   *
   * @param shapesInOrder shapes from model in order.
   * @param inProgress    commands in progress.
   * @param shapes        shapes not in order.
   * @param tick          the current tick.
   */
  ExtraAnimationPanel(List<IShape> shapesInOrder,
      List<ICommand> inProgress,
      AbstractMap<String, IShape> shapes, int tick) {
    super(shapesInOrder, inProgress, shapes, tick);
  }

  public void setFill(boolean fill) {
    this.fill = fill;
  }

  protected void paintShape(IShape shape, Graphics graphics) {
    if (this.fill) {
      super.paintShape(shape, graphics);
    } else {

      if (shape.getPosition() != null && shape.getColor() != null) {

        graphics.setColor(shape.getColor().toColor());

        if (shape.returnType().equals("rect")) {

          graphics.drawRect((int) shape.getPosition().getX(), (int) shape.getPosition().getY(),
              (int) shape.getWidth(), (int) shape.getHeight());

        } else if (shape.returnType().equals("oval")) {

          graphics.drawOval((int) shape.getPosition().getX(), (int) shape.getPosition().getY(),
              (int) shape.getWidth(), (int) shape.getHeight());

        } else if (shape.returnType().equals("plus")) {

          // The vertical bar
          graphics.drawRect((int) shape.getPosition().getX()
                  + (int) (shape.getWidth() / 4), (int) shape.getPosition().getY(),
              (int) (shape.getWidth() / 2), (int) (shape.getHeight()));

          // The horizontal bar
          graphics.setColor(shape.getColor().toColor());
          graphics.drawRect((int) shape.getPosition().getX(), (int) shape.getPosition().getY() +
                  (int) (shape.getHeight() / 4), (int) (shape.getWidth()),
              (int) (shape.getHeight() / 2));

          graphics.setColor(getBackground());
          graphics.fillRect((int) shape.getPosition().getX(), (int) shape.getPosition().getY() +
                  (int) (shape.getHeight() / 4), (int) (shape.getWidth()),
              (int) (shape.getHeight() / 2));
          graphics.fillRect((int) shape.getPosition().getX()
                  + (int) (shape.getWidth() / 4), (int) shape.getPosition().getY(),
              (int) (shape.getWidth() / 2), (int) (shape.getHeight()));

        } else {
          throw new IllegalArgumentException("Unsupported shape to draw");
        }

      }

    }
  }

}
