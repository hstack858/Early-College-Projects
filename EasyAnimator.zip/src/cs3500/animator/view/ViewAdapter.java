//package cs3500.animator.view;
//
////import cs3500.animator.provider.shape.IModelShape;
////import cs3500.animator.provider.shape.IShapeAdapter;
////import cs3500.animator.provider.view.IInteractiveView;
//import cs3500.controller.Features;
//import cs3500.model.IViewModel;
//import cs3500.model.shapes.IShape;
//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
//import java.util.ArrayList;
//
///**
// * A class to adapt the view for the controller.
// */
//public class ViewAdapter implements IAnimationView, ActionListener {
//
////  private IInteractiveView view;
//  private IViewModel model;
//  private Features features;
//  //ArrayList because they used ArrayList not List in their view
////  private ArrayList<IModelShape> viewShapes = new ArrayList<>();
//
//
//  /**
//   * Constructor that takes in the view and model needed for this adapter.
//   * @param view The view being adapted.
//   * @param model The model being adapted.
//   */
//  public ViewAdapter(IInteractiveView view, IViewModel model) {
//
//    this.view = view;
//    this.model = model;
//
//    for (IShape s: model.getRenderShapes()) {
//      viewShapes.add(new IShapeAdapter(s));
//    }
//    this.view.addShape(viewShapes);
//  }
//
//  @Override
//  public void render() {
//
//    this.viewShapes = new ArrayList<>();
//
//    for (IShape s: model.getRenderShapes()) {
//      this.viewShapes.add(new IShapeAdapter(s));
//    }
//
//    this.view.refresh();
//  }
//
//  @Override
//  public void changeTempoTo(int tempo) {
//    //Does nothing for their view because they do not have a tempo field.
//  }
//
//  @Override
//  public void changeIndicator(String name) {
//    // No indicator required.
//  }
//
//  /**
//   * Adds the features as a field to this adapter.
//   * @param features The features to be added.
//   */
//  public void addFeatures(Features features) {
//    this.features = features;
//    this.view.addListener(this);
//  }
//
//  @Override
//  public void actionPerformed(ActionEvent e) {
//    switch (e.getActionCommand()) {
//      case "start":
//      case "resume":
//        features.play();
//        break;
//      case "restart":
//        features.restart();
//        break;
//      case "loop":
//        features.loop();
//        break;
//      case "speed up":
//        features.speedUp();
//        break;
//      case "speed down":
//        features.slowDown();
//        break;
//      case "pause":
//        features.pause();
//        break;
//      default:
//        //throw new IllegalArgumentException("Cannot recieve this action event");
//
//    }
//  }
//
//}
