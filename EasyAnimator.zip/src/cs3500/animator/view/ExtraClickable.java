package cs3500.animator.view;

import cs3500.controller.ExtraFeatures;
import cs3500.controller.Features;
import java.awt.event.MouseEvent;
import javax.swing.JComponent;

/**
 * Class to represent the Clickable which is able to be used with the extra features.
 */
public class ExtraClickable extends Clickable {

  protected ExtraFeatures features;

  /**
   * Constructor that takes in a component and its name.
   *
   * @param comp     The component (button in our case).
   * @param name     The name of the component.
   * @param features The features controller for this listener.
   */
  ExtraClickable(JComponent comp, String name, Features features) {
    super(comp, name, features);
    this.features = (ExtraFeatures) features;
  }

  /**
   * Invoked when a mouse button has been released on a component.
   *
   * @param e the event to be processed
   */
  @Override
  public void mouseReleased(MouseEvent e) {
    if (this.clicked) {
      if (this.name.equals("play")) {
        features.play();
      }
      if (this.name.equals("pause")) {
        features.pause();
      }
      if (this.name.equals("restart")) {
        features.restart();
      }
      if (this.name.equals("speedUp")) {
        features.speedUp();
      }
      if (this.name.equals("slowDown")) {
        features.slowDown();
      }
      if (this.name.equals("loop")) {
        features.loop();
      }
      if (this.name.equals("toggle")) {
        features.toggleFill();
      }
      if (this.name.equals("discrete")) {
        features.toggleDiscrete();
      }

    }
    this.clicked = false;
  }

  /**
   * Invoked when the mouse enters a component.
   *
   * @param e the event to be processed
   */
  @Override
  public void mouseEntered(MouseEvent e) {
    features.changeIndicator(name);
  }

  /**
   * Invoked when the mouse exits a component.
   *
   * @param e the event to be processed
   */
  @Override
  public void mouseExited(MouseEvent e) {
    features.changeIndicator(name);
  }

}
