package cs3500.controller;

import java.util.Map;

/**
 * Interface to represent animation controllers that can be used to produce EC features.
 */
public interface IExtraAnimationController extends IAnimationController {

  /**
   * Set the time intervals of tempos for animation speed.
   *
   * @param intervals of tempos
   */
  void setIntervals(Map<Integer, Integer> intervals);

}
