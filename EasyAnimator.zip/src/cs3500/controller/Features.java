package cs3500.controller;

/**
 * Interface for features that a controller can implement.
 */
public interface Features {

  /**
   * Resumes the animation.
   */
  void play();

  /**
   * Pauses the animation.
   */
  void pause();

  /**
   * Restarts the animation.
   */
  void restart();

  /**
   * Toggles looping option for animation.
   */
  void loop();

  /**
   * Speeds up animation.
   */
  void speedUp();

  /**
   * Slows down the animation.
   */
  void slowDown();

  /**
   * Change color of button.
   *
   * @param name of button to change
   */
  void changeIndicator(String name);

}
