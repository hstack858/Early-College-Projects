package cs3500.controller;

import cs3500.animator.view.IAnimationView;
import cs3500.model.IAnimationModel;

/**
 * An interface to represent the controller of our program which is used to write to a passed
 * appendable which creates the files and outputs.
 */
public interface IAnimationController {

  /**
   * The method that takes in the parameters to pass to the view and model.
   *
   * @param model The model for this program.
   * @param tempo The speed at which this program runs.
   */
  void startAnimation(IAnimationModel model, int tempo, IAnimationView view);

  /**
   * Toggles whether next timer task should be run if view is rendering a model that requires
   * onTick.
   */
  void toggleTiming();

  /**
   * Ticks the model appropriately and renders the view.
   */
  void renderTick();
}
