package cs3500.controller;

import cs3500.animator.view.AnimationVisualView;
import cs3500.animator.view.IAnimationView;
import cs3500.animator.view.RenderTask;
import cs3500.animator.view.SimpleInteractiveView;
import cs3500.model.IAnimationModel;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Class for the animation controller that works with all views.
 */
public class AnimationController implements IAnimationController, Features {

  protected IAnimationModel model;
  protected IAnimationView view;
  protected int tick = 0;
  protected int tempo;
  protected volatile boolean isPlaying;
  protected boolean isLooping;
  protected Timer timer = new Timer();
  protected boolean timing = true;

  public AnimationController() {
    this.isPlaying = true;
    this.isLooping = false;
  }

  /**
   * The method that takes in the parameters to pass to the view and model.
   *
   * @param model The model for this program.
   * @param tempo The speed at which this program runs.
   * @param view  The view for this program.
   */
  @Override
  public void startAnimation(IAnimationModel model, int tempo, IAnimationView view) {

    if (model == null) {
      throw new IllegalArgumentException("Cannot accept a null model");
    }

    this.model = model;
    this.tempo = tempo;
    this.view = view;

    if (view instanceof SimpleInteractiveView) {
      ((SimpleInteractiveView) view).addFeatures(this);
    }

    if (view instanceof AnimationVisualView) {

      while (tick <= model.getLastTick()) {
        if (isPlaying && timing) {
          toggleTiming();
          TimerTask task = new RenderTask(this);
          this.timer.schedule(task, 1000 / this.tempo);
        }
        if (isLooping && tick == model.getLastTick()) {
          tick = 0;
          model.resetAnimation();
        }
      }
    }
    view.render();
  }

  @Override
  public void play() {
    this.isPlaying = true;
  }

  @Override
  public void pause() {
    this.isPlaying = false;
  }

  @Override
  public void restart() {
    if (this.tick < model.getLastTick()) {
      this.tick = -1;
    } else {
      this.tick = 0;
    }
    model.resetAnimation();
  }

  @Override
  public void loop() {
    isLooping = !(isLooping);
  }

  @Override
  public void speedUp() {
    this.tempo += 5;
    view.changeTempoTo(tempo);
  }

  @Override
  public void slowDown() {
    this.tempo -= 5;
    view.changeTempoTo(tempo);
  }

  @Override
  public void changeIndicator(String name) {
    view.changeIndicator(name);
  }

  /**
   * Returns true if playing, false otherwise.
   *
   * @return isPlaying value.
   */
  public boolean getIsPlaying() {
    return this.isPlaying;
  }

  /**
   * Returns true if looping, false otherwise.
   *
   * @return isLooping value.
   */
  public boolean getIsLooping() {
    return this.isLooping;
  }

  /**
   * Returns tick value as integer.
   *
   * @return tick.
   */
  public int getTick() {
    return this.tick;
  }

  /**
   * Returns tempo as integer.
   *
   * @return tempo.
   */
  public int getTempo() {
    return this.tempo;
  }

  @Override
  public void toggleTiming() {
    this.timing = !this.timing;
  }

  @Override
  public void renderTick() {
    this.timing = true;
    this.tick += 1;
    model.onTick();
    view.render();
  }

}