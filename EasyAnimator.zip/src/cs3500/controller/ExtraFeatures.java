package cs3500.controller;

/**
 * Interface to represent the features classes which support the extra credit features.
 */
public interface ExtraFeatures extends Features {

  /**
   * Toggle whether shapes are filled or not.
   */
  void toggleFill();

  /**
   * Toggle discrete playback.
   */
  void toggleDiscrete();

}
