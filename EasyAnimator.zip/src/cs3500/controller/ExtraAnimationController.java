package cs3500.controller;

import cs3500.animator.view.AnimationVisualView;
import cs3500.animator.view.ExtraInteractiveView;
import cs3500.animator.view.IAnimationView;
import cs3500.animator.view.IExtraView;
import cs3500.animator.view.RenderTask;
import cs3500.model.IAnimationModel;
import cs3500.model.IExtraModel;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TimerTask;

/**
 * Controller that supports the use of the extra credit features.
 */
public class ExtraAnimationController extends AnimationController
    implements IExtraAnimationController, ExtraFeatures {

  protected IExtraModel model;
  protected IExtraView view;
  private boolean discrete = false;
  private Set<Integer> timeSet;
  private Map<Integer, Integer> intervals = new HashMap<>();

  public ExtraAnimationController() {
    super();
  }

  /**
   * Starts the animation.
   *
   * @param model The model for this program.
   * @param tempo The speed at which this program runs.
   * @param view  The view for this program.
   */
  public void startAnimation(IAnimationModel model, int tempo, IAnimationView view) {

    if (model == null) {
      throw new IllegalArgumentException("Cannot accept a null model");
    }

    super.model = model;
    super.view = view;
    this.model = (IExtraModel) model;
    this.view = (IExtraView) view;
    this.tempo = tempo;

    if (view instanceof ExtraInteractiveView) {
      ((ExtraInteractiveView) view).addFeatures(this);
    }

    if (view instanceof AnimationVisualView) {

      timeSet = this.model.getTimeSet();

      while (tick <= model.getLastTick()) {
        if (this.intervals != null && this.intervals.containsKey(tick)) {
          this.tempo = intervals.get(tick);
        }
        if (isPlaying && timing) {
          toggleTiming();
          TimerTask task = new RenderTask(this);
          this.timer.schedule(task, 1000 / this.tempo);
        }
        if (isLooping && tick == model.getLastTick()) {
          tick = 0;
          model.resetAnimation();
        }
      }
    }

    this.view.render();
  }

  @Override
  public void toggleFill() {
    this.view.toggleFill();
  }

  @Override
  public void toggleDiscrete() {
    this.discrete = !this.discrete;
  }

  @Override
  public void renderTick() {

    this.timing = true;

    if (this.discrete) {
      fastForward();
    } else {
      this.tick++;
      model.onTick();
    }

    view.render();
  }

  private void fastForward() {
    while (!(timeSet.contains(this.tick))) {
      this.tick++;
      model.onTick();
    }
    if (timeSet.contains(this.tick)) {
      this.tick++;
    }
  }

  @Override
  public void setIntervals(Map<Integer, Integer> intervals) {
    this.intervals = intervals;
  }

  /**
   * Return whether this is toggled to discrete or non-discrete.
   *
   * @return false if normal, true if discrete playback mode.
   */
  public boolean getToggleDiscrete() {
    return this.discrete;
  }
}
