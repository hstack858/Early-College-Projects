Class invariants:
Time is always positive meaning that the tick value must be greater than 0.

Types used in model and relating to model:

ICommand: A display is a type of command which could also be considered a motion. The purpose of
this type is to represent the different motions that could happen within the model. This belongs
in the model because it relates to the behavior and logic of the program.
List of ICommands:
- ACommand is an abstract command that abstracts all relevant fields and methods for all commands.
- AddShape adds a shape to the model at a point in time. We need to be able to add shapes.
- ChangeColor changes the color of a shape in the model.
- MoveShape moves a shape within the model. We need to be able to "animate" or move shapes across
the screen in addition to changing their color. MoveShape does not ensure that the position it's
moving to is within any screen bounds because we do not have that information yet.
- TransformShape changes either the width, height, or both of those properties about a given shape
over a period of time.

IShape: An IShape is a type of shape within the model. We use this to represent our shapes. This
belongs in the model because the shapes are the objects that we perform computations on which is
model behavior.
List of IShapes:
- AShape is an abstract shape that abstracts all relevant fields and methods for all shapes.
- Oval is a shape representing an ellipse. This also includes the special ellipse known as a circle.
- Rectangle is a shape representing a rectangle. This also includes the special rectangle known as
a square.

Posn: A posn represents the position of a shape. IShapes need to have positions within the state
of the program. This belongs in the model because it's a component of shapes which
we've already justified belong in the model.

RGB: An RGB represents the color of a shape. IShapes need to have some color field because our
client wants colorful animations. This belongs in the model because it's a component of shapes which
we've already justified belong in the model.

IAnimationModel: An interface for the animation model.
AbstractAnimationModel: Currently where all the model implementations are, but will be used in
the future to abstract common model behavior.
SimpleAnimationModel: Currently only a concrete representation of the abstract model that
represents a simple animation model.

Methods:
- onTick changes the program state an incremental amount (1 tick). By calling the tick method for
each command that is "in progress" meaning that the command or motion is occurring
during the current tick.
- addCommand implements the functionality of adding a command or motion to the model.
This behavior and implementation depends on what the controller will pass and whether it should
pass the model a list of values corresponding to a command that the model will parse or whether
each motion should have a method that corresponds to that command. We haven't decided this detail
yet as we're waiting for more information.
- getTick returns the current tick value of the model
- simulate runs a command all the way through it's desired behavior and returns a copy now
- getLastTick returns the end tick of the last command to be run in the model
- getShapes returns the shapes currently in the model
- getMotions returns all the motions or commands associated with a given shape
- addShapeCommand changes the reference of this.shapes, the shapes list to whatever a command's
shape list in
- allCommandShapes returns the shapes that will be added to the model
- We added a method to sort the commands into a hashmap by runtime, this is called startSort
- Its helper is called startTree

Assignment 9 ReadME additions:

No structural changes were made to the main MVC.
Rearranging code and moving functionality into helper methods were the largest changes.
One notable change was inside the AnimationVisual view where the panel that was an inner class
was made into it's own class. The shapes no longer paint themselves as that was view behavior
and is now correctly done in the view.

The model, view, and controller were all extended into extra versions of themselves that include
the extra features and functionality.

Level 1:
Inside the model package, a new shapes class for the plus shape has been created.
All the views were extended, but the ExtraInteractiveView and SVG view were the ones that
required the most changes.

The SVG view required a complete redesign with several helper methods
so it'd be simpler and easier to work with shapes especially with the plus sign that required
two rectangles.

The interactive view did not require much changing. The relevant changes include
including support for the shape to be draw correctly and adding a different type of drawing option
inside of the AnimationPanel (extended to ExtraAnimationPanel for the ExtraInteractiveView) so that
if fill was toggled (fill a boolean in the view), then it would draw outlines versus filled shapes.

Level 2:

Discrete playback only required changing the controller and adding one method to the model.
The model method called getTimeSet found all the start and end times of the commands and created
a set to store them in. This was then used by the controller. The controller used to have an inner
class called RenderTask that overrode TimerTask and was used by the java util timer. This was
moved outside of the controller into it's own class called RenderTask and used by the controller.
A new method in the controller called renderTick that could be overridden by the
ExtraAnimationController meant more granular controller over what the controller does each tick.
The regular controller still ticks the model once and then renders the view, but the new controller
when (a boolean called discrete) is toggled, calls a method called fastForward that ticks the model
up until the tick of a start or end command and then renders the view.

Level 3:

Slow motion playback only required changing the controller. Inside the controller there is a map
of ticks to corresponding tempos. An intervals file can be given the program that specifies the
start tick and the new tempo where tick 0 will always start at the tempo and the first tick with
a new tempo will change the program tempo. Before trying to render anything or tick the model,
the controller checks the tempo of the current tick against a map (a hashmap) then schedules the
next task for rendering the next tick based on the tempo.

