import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import cs3500.model.shapes.IShape;
import cs3500.model.shapes.Oval;
import cs3500.model.shapes.Plus;
import cs3500.model.shapes.Posn;
import cs3500.model.shapes.RGB;
import cs3500.model.shapes.Rectangle;
import org.junit.Test;

/**
 * Testing class for shapes package.
 */
public class ShapesTest {

  private IShape p;
  private IShape p2;
  private IShape o;
  private IShape o2;
  private IShape r;
  private IShape r2;
  private IShape r3;
  private IShape r4;
  private IShape r5;
  private Posn posn1;
  private Posn posn2;
  private Posn posn3;
  private Posn posn4;
  private RGB rgb1;
  private RGB rgb2;
  private RGB rgb3;
  private RGB rgb4;

  private void utils() {
    posn1 = new Posn(5, 5);
    posn2 = new Posn(5, 5);
    posn3 = new Posn(0, 0);
    posn4 = new Posn(5.0, 0);
    rgb1 = new RGB(5, 5, 5);
    rgb2 = new RGB(5, 5, 5);
    rgb3 = new RGB(0, 0, 0);
    rgb4 = new RGB(1, 2, 3);

    p = new Plus("P", new Posn(0, 0), new RGB(255, 0, 0), 5, 5, 1, 1);
    p2 = new Plus("P", new Posn(0, 0), new RGB(255, 0, 0), 5, 5, 1, 1);
    o = new Oval("O", new Posn(0, 0), new RGB(255, 0, 0), 5, 5, 1, 1);
    o2 = new Oval("O", new Posn(0, 0), new RGB(255, 0, 0), 5, 5, 1, 1);
    r = new Rectangle("R", new Posn(0, 0), new RGB(0, 0, 255), 4, 4, 1, 1);
    r2 = new Rectangle("R", new Posn(0, 0), new RGB(0, 0, 255), 4, 4, 1, 1);
    r3 = new Rectangle("R", new Posn(5, 5), new RGB(10, 20, 255), 5, 10, 1, 1);
    r4 = new Rectangle("R", new Posn(5, 5), new RGB(10, 20, 255), 10, 20, 1, 1);
    r5 = new Rectangle("R", new Posn(10, 15), new RGB(10, 20, 255), 5, 10, 1, 1);
  }

  @Test
  public void testPlusEqualsItself() {
    utils();
    assertEquals(p, p);
  }

  @Test
  public void testPlusHashItself() {
    utils();
    assertEquals(p.hashCode(), p.hashCode());
  }

  @Test
  public void testPlusEqualsAnother() {
    utils();
    assertEquals(p, p2);
  }

  @Test
  public void testPlusHashAnother() {
    utils();
    assertEquals(p.hashCode(), p2.hashCode());
  }

  @Test
  public void testPlusNotEquals() {
    utils();
    IShape p3 = new Plus("P", new Posn(0, 0), new RGB(255, 0, 0), 8, 4, 1, 1);
    assertNotEquals(p, p3);
  }

  @Test
  public void testPlusNotHash() {
    utils();
    IShape p3 = new Plus("P", new Posn(0, 0), new RGB(255, 0, 0), 8, 4, 1, 1);
    assertNotEquals(p.hashCode(), p3.hashCode());
  }


  @Test
  public void testOvalEqualsItself() {
    utils();
    assertEquals(o, o);
  }

  @Test
  public void testOvalHashItself() {
    utils();
    assertEquals(o.hashCode(), o.hashCode());
  }

  @Test
  public void testOvalEqualsAnother() {
    utils();
    assertEquals(o, o2);
  }

  @Test
  public void testOvalHashAnother() {
    utils();
    assertEquals(o.hashCode(), o2.hashCode());
  }

  @Test
  public void testOvalNotEquals() {
    utils();
    IShape o3 = new Oval("O", new Posn(0, 0), new RGB(255, 0, 0), 8, 4, 1, 1);
    assertNotEquals(o, o3);
  }

  @Test
  public void testOvalNotHash() {
    utils();
    IShape o3 = new Oval("O", new Posn(0, 0), new RGB(255, 0, 0), 8, 4, 1, 1);
    assertNotEquals(o.hashCode(), o3.hashCode());
  }

  @Test
  public void testRectangleEqualsItself() {
    utils();
    assertEquals(r, r);
  }

  @Test
  public void testRectangleHashItself() {
    utils();
    assertEquals(r.hashCode(), r.hashCode());
  }

  @Test
  public void testRectangleEqualsAnother() {
    utils();
    assertEquals(r, r2);
  }

  @Test
  public void testRectangleHashAnother() {
    utils();
    assertEquals(r.hashCode(), r2.hashCode());
  }

  @Test
  public void testRectangleNotEquals() {
    utils();
    assertNotEquals(o, r2);
  }

  @Test
  public void testRectangleNotHash() {
    utils();
    assertNotEquals(o.hashCode(), r2.hashCode());
  }

  @Test
  public void testOvalReturnType() {
    utils();
    assertEquals("oval", o.returnType());
  }

  @Test
  public void testRectangleReturnType() {
    utils();
    assertEquals("rect", r.returnType());
  }

  @Test
  public void testOvalGetCopy() {
    utils();
    assertEquals(o, o.getCopy());
  }

  @Test
  public void testRectGetCopy() {
    utils();
    assertEquals(r, r.getCopy());
  }

  //Here and below are tests from abstract shape

  @Test
  public void testAbstractChangePosition() {
    utils();
    r.changePosition(new Posn(5, 5));
    r2.changePosition(new Posn(5, 5));
    assertEquals(r2, r);
  }

  @Test
  public void testAbstractGetPosition() {
    utils();
    assertEquals(new Posn(0, 0), r.getPosition());
  }

  @Test
  public void testAbstractGetWidth() {
    utils();
    assertEquals(5, r3.getWidth(), .01);
  }

  @Test
  public void testAbstractGetHeight() {
    utils();
    assertEquals(10, r3.getHeight(), .01);
  }

  @Test
  public void testAbstractGetColor() {
    utils();
    assertEquals(new RGB(10, 20, 255), r3.getColor());
  }

  @Test
  public void testAbstractTransform() {
    utils();
    r3.transform(10, 20);
    assertEquals(r4, r3);
  }

  @Test
  public void testAbstractMoveTo() {
    utils();
    r3.moveTo(10, 15);
    assertEquals(r5, r3);
  }

  @Test
  public void testAbstractReturnName() {
    utils();
    assertEquals("R", r.returnName());
  }

  @Test
  public void testAbstractToStringAtTick() {
    utils();
    String s = "10 0.0 0.0 4.0 4.0 0.0 0.0 255.0";
    assertEquals(s, r.toStringAtTick(10, 20));
  }

  //Here and below are tests for Posn and RGB

  @Test
  public void testPosnEqualsItself() {
    utils();
    assertEquals(posn1, posn1);
  }

  @Test
  public void testPosnHashItself() {
    utils();
    assertEquals(posn1.hashCode(), posn1.hashCode());
  }

  @Test
  public void testPosnEqualsAnother() {
    utils();
    assertEquals(posn1, posn2);
  }

  @Test
  public void testPosnHashAnother() {
    utils();
    assertEquals(posn1.hashCode(), posn2.hashCode());
  }

  @Test
  public void testPosnNotEquals() {
    utils();
    assertNotEquals(posn1, posn3);
  }

  @Test
  public void testPosnNotHash() {
    utils();
    assertNotEquals(posn1.hashCode(), posn3.hashCode());
  }

  @Test
  public void testmoveTo() {
    utils();
    posn3.moveTo(5, 5);
    assertEquals(posn3, posn1);
  }

  @Test
  public void testPosnGetCopy() {
    utils();
    Posn posn4 = posn1.getCopy();
    assertEquals(posn4, posn1);
  }

  @Test
  public void testPosnGetX() {
    utils();
    assertEquals(5.0, posn4.getX(), .01);
  }

  @Test
  public void testPosnGetY() {
    utils();
    assertEquals(0.0, posn4.getY(), .01);
  }

  @Test
  public void testRGBEqualsItself() {
    utils();
    assertEquals(rgb1, rgb1);
  }

  @Test
  public void testRGBHashItself() {
    utils();
    assertEquals(rgb1.hashCode(), rgb1.hashCode());
  }

  @Test
  public void testRGBEqualsAnother() {
    utils();
    assertEquals(rgb1, rgb2);
  }

  @Test
  public void testRGBHashAnother() {
    utils();
    assertEquals(rgb1.hashCode(), rgb2.hashCode());
  }

  @Test
  public void testRGBNotEquals() {
    utils();
    assertNotEquals(rgb1, rgb3);
  }

  @Test
  public void testRGBNotHash() {
    utils();
    assertNotEquals(rgb1.hashCode(), rgb3.hashCode());
  }

  @Test
  public void testRGBGetRed() {
    utils();
    assertEquals(1, rgb4.getRed(), .1);
  }

  @Test
  public void testRGBGetGreen() {
    utils();
    assertEquals(2, rgb4.getGreen(), .1);
  }

  @Test
  public void testRGBGetBlue() {
    utils();
    assertEquals(3, rgb4.getBlue(), .1);
  }

  @Test
  public void testRGBAdditiveColor() {
    utils();
    rgb1.additiveColor(new RGB(1, 1, 1));
    assertEquals(new RGB(6, 6, 6), rgb1);
  }

  @Test
  public void testRGBGetCopy() {
    utils();
    assertEquals(rgb1.getCopy(), rgb1);
  }
}
