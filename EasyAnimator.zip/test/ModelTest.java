import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import cs3500.model.ExtraAnimationModel;
import cs3500.model.IAnimationModel;
import cs3500.model.SimpleAnimationModel;
import cs3500.model.commands.ICommand;
import cs3500.model.commands.MoveShape;
import cs3500.model.shapes.IShape;
import cs3500.model.shapes.Oval;
import cs3500.model.shapes.Posn;
import cs3500.model.shapes.RGB;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;
import org.junit.Test;

/**
 * Testing class for the model.
 */
public class ModelTest {

  private IAnimationModel model;
  private TreeMap<String, IShape> shapes;
  private List<ICommand> toDo;
  private List<ICommand> inProgress;
  private List<IShape> shapesInOrder;
  private IShape o1;
  private IShape o2;
  private IShape o3;
  private IShape o4;
  private ICommand moveShape;
  private ICommand moveShape2;


  @Test
  public void testAddCommand() {

    shapes = new TreeMap<>();
    toDo = new ArrayList<>();
    inProgress = new ArrayList<>();
    model = new SimpleAnimationModel(shapes, toDo, inProgress, 0, 0, 800, 800, shapesInOrder);
    o1 = new Oval("O", new Posn(0, 0),
        new RGB(0, 0, 255), 5, 5, 1, 1);
    o2 = new Oval("O", new Posn(0, 0),
        new RGB(0, 0, 255), 5, 5, 1, 1);
    o3 = new Oval("O", new Posn(2.5, 2.5),
        new RGB(0, 0, 255), 5, 5, 1, 1);
    o4 = new Oval("O", new Posn(5.0, 5.0),
        new RGB(0, 0, 255), 5, 5, 1, 1);
    this.shapes.put("O", o1);
    moveShape = new MoveShape(this.shapes, "O", 1, 3, new Posn(5, 5));
    moveShape2 = new MoveShape(this.shapes, "O", 1, 3, new Posn(5, 5));
    this.model.addCommand(moveShape);
    assertEquals(moveShape2, this.model.getMotions(this.o1, this.model.getShapes()).get(0));

  }

  @Test
  public void testOnTick() {
    shapes = new TreeMap<>();
    toDo = new ArrayList<>();
    inProgress = new ArrayList<>();

    o1 = new Oval("O", new Posn(0, 0),
        new RGB(0, 0, 255), 5, 5, 1, 1);
    o2 = new Oval("O", new Posn(0, 0),
        new RGB(0, 0, 255), 5, 5, 1, 1);
    o3 = new Oval("O", new Posn(2.5, 2.5),
        new RGB(0, 0, 255), 5, 5, 1, 1);
    o4 = new Oval("O", new Posn(5.0, 5.0),
        new RGB(0, 0, 255), 5, 5, 1, 1);
    shapesInOrder = new ArrayList<>();
    shapesInOrder.add(o1);
    this.shapes.put("O", o1);
    model = new SimpleAnimationModel(shapes, toDo, inProgress, 0, 0, 800, 800, shapesInOrder);
    this.model.addShape(o1);
    this.model.addShape(o1);
    moveShape = new MoveShape(this.shapes, "O", 1, 3, new Posn(5, 5));
    moveShape2 = new MoveShape(this.shapes, "O", 1, 3, new Posn(5, 5));
    this.model.onTick();

    assertEquals(this.o2, this.model.getShapes().get("O"));

    this.model.onTick();

    assertEquals(this.o2, this.model.getShapes().get("O"));

    this.model.onTick();

    assertEquals(this.o2, this.model.getShapes().get("O"));

  }

  @Test
  public void testGetLastTick() {

    shapes = new TreeMap<>();
    toDo = new ArrayList<>();
    inProgress = new ArrayList<>();
    model = new SimpleAnimationModel(shapes, toDo, inProgress, 0, 0, 800, 800, shapesInOrder);
    o1 = new Oval("O", new Posn(0, 0),
        new RGB(0, 0, 255), 5, 5, 1, 1);
    o2 = new Oval("O", new Posn(0, 0),
        new RGB(0, 0, 255), 5, 5, 1, 1);
    o3 = new Oval("O", new Posn(2.5, 2.5),
        new RGB(0, 0, 255), 5, 5, 1, 1);
    o4 = new Oval("O", new Posn(5.0, 5.0),
        new RGB(0, 0, 255), 5, 5, 1, 1);
    this.model.addShape(o1);
    this.model.addShape(o1);
    moveShape = new MoveShape(this.shapes, "O", 1, 3, new Posn(5, 5));
    moveShape2 = new MoveShape(this.shapes, "O", 1, 3, new Posn(5, 5));

    this.model.addShape(o1);

    assertEquals(0, this.model.getLastTick());

    this.model.addCommand(moveShape);

    assertEquals(3, this.model.getLastTick());

  }

  @Test
  public void testGetTick() {

    shapes = new TreeMap<>();
    toDo = new ArrayList<>();
    inProgress = new ArrayList<>();

    o1 = new Oval("O", new Posn(0, 0),
        new RGB(0, 0, 255), 5, 5, 1, 1);
    o2 = new Oval("O", new Posn(0, 0),
        new RGB(0, 0, 255), 5, 5, 1, 1);
    o3 = new Oval("O", new Posn(2.5, 2.5),
        new RGB(0, 0, 255), 5, 5, 1, 1);
    o4 = new Oval("O", new Posn(5.0, 5.0),
        new RGB(0, 0, 255), 5, 5, 1, 1);
    shapesInOrder = new ArrayList<>();
    shapesInOrder.add(o1);
    model = new SimpleAnimationModel(shapes, toDo, inProgress, 0, 0, 800, 800, shapesInOrder);
    this.model.addShape(o1);
    this.model.addShape(o1);
    moveShape = new MoveShape(this.shapes, "O", 1, 3, new Posn(5, 5));
    moveShape2 = new MoveShape(this.shapes, "O", 1, 3, new Posn(5, 5));

    assertEquals(0, this.model.getTick());

    this.model.onTick();
    this.model.onTick();
    this.model.onTick();

    assertEquals(3, this.model.getTick());


  }

  @Test
  public void testGetShapes() {
    shapes = new TreeMap<>();
    toDo = new ArrayList<>();
    inProgress = new ArrayList<>();

    o1 = new Oval("O", new Posn(0, 0),
        new RGB(0, 0, 255), 5, 5, 1, 1);
    o2 = new Oval("O", new Posn(0, 0),
        new RGB(0, 0, 255), 5, 5, 1, 1);
    o3 = new Oval("O", new Posn(2.5, 2.5),
        new RGB(0, 0, 255), 5, 5, 1, 1);
    o4 = new Oval("O", new Posn(5.0, 5.0),
        new RGB(0, 0, 255), 5, 5, 1, 1);
    shapesInOrder = new ArrayList<>();
    shapesInOrder.add(o1);
    model = new SimpleAnimationModel(shapes, toDo, inProgress, 0, 0, 800, 800, shapesInOrder);
    this.model.addShape(o1);
    this.model.addShape(o1);
    moveShape = new MoveShape(this.shapes, "O", 1, 3, new Posn(5, 5));
    moveShape2 = new MoveShape(this.shapes, "O", 1, 3, new Posn(5, 5));

    this.model.addShape(o1);
    this.model.addCommand(moveShape);

    TreeMap<String, IShape> shapesList = new TreeMap<>();

    shapesList.put("O", o3);

    assertNotEquals(shapesList, this.model.getShapes());

    this.model.onTick();
    this.model.onTick();

    assertEquals(shapesList, this.model.getShapes());

  }

  @Test
  public void testSimulate() {
    shapes = new TreeMap<>();
    toDo = new ArrayList<>();
    inProgress = new ArrayList<>();

    o1 = new Oval("O", new Posn(0, 0),
        new RGB(0, 0, 255), 5, 5, 1, 1);
    o2 = new Oval("O", new Posn(0, 0),
        new RGB(0, 0, 255), 5, 5, 1, 1);
    o3 = new Oval("O", new Posn(2.5, 2.5),
        new RGB(0, 0, 255), 5, 5, 1, 1);
    o4 = new Oval("O", new Posn(5.0, 5.0),
        new RGB(0, 0, 255), 5, 5, 1, 1);
    shapesInOrder = new ArrayList<>();
    shapesInOrder.add(o1);
    model = new SimpleAnimationModel(shapes, toDo, inProgress, 0, 0, 800, 800, shapesInOrder);
    this.model.addShape(o1);
    this.model.addShape(o1);
    moveShape = new MoveShape(this.shapes, "O", 1, 3, new Posn(5, 5));
    moveShape2 = new MoveShape(this.shapes, "O", 1, 3, new Posn(5, 5));

    this.model.addShape(o1);
    this.model.addCommand(moveShape);

    this.model.onTick();
    this.model.onTick();
    this.model.onTick();
    this.model.onTick();

    o4 = this.model.simulate(moveShape, o1);

    assertEquals(o4, this.model.getShapes().get("O"));

  }

  @Test
  public void testGetMotions() {

    shapes = new TreeMap<>();
    toDo = new ArrayList<>();
    inProgress = new ArrayList<>();

    o1 = new Oval("O", new Posn(0, 0),
        new RGB(0, 0, 255), 5, 5, 1, 1);
    o2 = new Oval("O", new Posn(0, 0),
        new RGB(0, 0, 255), 5, 5, 1, 1);
    o3 = new Oval("O", new Posn(2.5, 2.5),
        new RGB(0, 0, 255), 5, 5, 1, 1);
    o4 = new Oval("O", new Posn(5.0, 5.0),
        new RGB(0, 0, 255), 5, 5, 1, 1);
    shapesInOrder = new ArrayList<>();
    shapesInOrder.add(o1);
    model = new SimpleAnimationModel(shapes, toDo, inProgress, 0, 0, 800, 800, shapesInOrder);
    this.model.addShape(o1);
    this.model.addShape(o1);
    moveShape = new MoveShape(this.shapes, "O", 1, 3, new Posn(5, 5));
    moveShape2 = new MoveShape(this.shapes, "O", 1, 3, new Posn(5, 5));

    this.model.addShape(o1);
    this.model.addCommand(moveShape);

    List<ICommand> list = new ArrayList<>();
    list.add(moveShape);

    assertEquals(list, this.model.getMotions(o1, this.model.getShapes()));

    this.model.onTick();

  }

  @Test
  public void testAddShapeCommand() {

    shapes = new TreeMap<>();
    toDo = new ArrayList<>();
    inProgress = new ArrayList<>();
    model = new SimpleAnimationModel(shapes, toDo, inProgress, 0, 0, 800, 800, shapesInOrder);
    o1 = new Oval("O", new Posn(0, 0),
        new RGB(0, 0, 255), 5, 5, 1, 1);
    o2 = new Oval("O", new Posn(0, 0),
        new RGB(0, 0, 255), 5, 5, 1, 1);
    o3 = new Oval("O", new Posn(2.5, 2.5),
        new RGB(0, 0, 255), 5, 5, 1, 1);
    o4 = new Oval("O", new Posn(5.0, 5.0),
        new RGB(0, 0, 255), 5, 5, 1, 1);
    this.model.addShape(o1);
    this.model.addShape(o1);
    moveShape = new MoveShape(this.shapes, "O", 1, 3, new Posn(5, 5));
    moveShape2 = new MoveShape(this.shapes, "O", 1, 3, new Posn(5, 5));

    List<IShape> badShapes = new ArrayList<>();

    model.addShape(o1);

    assertEquals(this.shapes, this.model.getShapes());
  }

  @Test
  public void testGetTimeSet() {

    shapes = new TreeMap<>();
    toDo = new ArrayList<>();
    inProgress = new ArrayList<>();
    ExtraAnimationModel model = new ExtraAnimationModel(shapes, toDo, inProgress, 0,
        0, 800, 800, shapesInOrder);
    o1 = new Oval("O", new Posn(0, 0),
        new RGB(0, 0, 255), 5, 5, 1, 1);
    o2 = new Oval("O", new Posn(0, 0),
        new RGB(0, 0, 255), 5, 5, 1, 1);
    o3 = new Oval("O", new Posn(2.5, 2.5),
        new RGB(0, 0, 255), 5, 5, 1, 1);
    o4 = new Oval("O", new Posn(5.0, 5.0),
        new RGB(0, 0, 255), 5, 5, 1, 1);
    model.addShape(o1);
    moveShape = new MoveShape(this.shapes, "O", 1, 3, new Posn(5, 5));
    moveShape2 = new MoveShape(this.shapes, "O", 1, 3, new Posn(5, 5));

    List<IShape> badShapes = new ArrayList<>();

    model.addShape(o1);

    assertEquals(new HashSet<Integer>(), model.getTimeSet());

    model.addCommand(moveShape);

    Set<Integer> set = new HashSet<Integer>();
    set.add(1);
    set.add(3);

    assertEquals(set, model.getTimeSet());
  }

}

