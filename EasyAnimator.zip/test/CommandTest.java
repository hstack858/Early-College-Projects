import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertThat;

import cs3500.model.IAnimationModel;
import cs3500.model.SimpleAnimationModel;
import cs3500.model.commands.ChangeColor;
import cs3500.model.commands.ICommand;
import cs3500.model.commands.MoveShape;
import cs3500.model.commands.TransformShape;
import cs3500.model.shapes.IShape;
import cs3500.model.shapes.Oval;
import cs3500.model.shapes.Posn;
import cs3500.model.shapes.RGB;
import cs3500.model.shapes.Rectangle;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;
import org.junit.Test;

/**
 * Testing class for commands.
 */
public class CommandTest {

  private IShape r;
  private IShape c;
  private TreeMap<String, IShape> shapes;

  private IAnimationModel model;

  /**
   * Utilities function to make testing easier by initializing variables.
   */
  private void utils() {
    r = new Rectangle("R", new Posn(200, 200),
        new RGB(255, 0, 0), 50, 100, 1, 1);
    c = new Oval("C", new Posn(440, 70), new RGB(0, 0, 255),
        120, 6, 6, 6);
    List<IShape> shapesInOrder = new ArrayList<IShape>();
    shapesInOrder.add(r);
    shapesInOrder.add(c);
    shapes = new TreeMap<String, IShape>();
    model = new SimpleAnimationModel(shapes, (new ArrayList<ICommand>()),
        (new ArrayList<ICommand>()), 100, 100, 100, 100, shapesInOrder);
    model.addShape(r);
    model.addShape(c);
  }


  @Test
  public void testRectangleCommands() {
    utils();
    model.addCommand(new MoveShape(model.getShapes(), "R", 10, 50, new Posn(300, 300)));
    model.addCommand(new TransformShape(model.getShapes(), "R", 50, 70, 25, 100));
    model.addCommand(new MoveShape(model.getShapes(), "R", 70, 100, new Posn(200, 200)));

    int index = 0;
    while (index < 6) {
      model.onTick();
      index++;
    }

    assertEquals(200, model.getShapes().get("R").getPosition().getX(), 0.01);
    assertEquals(200, model.getShapes().get("R").getPosition().getY(), 0.01);

    while (index < 10) {
      model.onTick();
      index++;
    }
    assertEquals(200, model.getShapes().get("R").getPosition().getX(), 0.01);
    assertEquals(200, model.getShapes().get("R").getPosition().getY(), 0.01);

    while (index < 15) {
      model.onTick();
      index++;
    }

    assertEquals(212.5, model.getShapes().get("R").getPosition().getX(), 0.01);
    assertEquals(212.5, model.getShapes().get("R").getPosition().getY(), 0.01);

    while (index < 50) {
      model.onTick();
      index++;
    }
    assertEquals(300, model.getShapes().get("R").getPosition().getX(), 0.01);
    assertEquals(300, model.getShapes().get("R").getPosition().getY(), 0.01);
    index = 51;
    while (index < 58) {
      model.onTick();
      index++;
    }

    assertEquals(41.25, model.getShapes().get("R").getWidth(), .01);
    assertEquals(100, model.getShapes().get("R").getHeight(), .01);

    while (index < 70) {
      model.onTick();
      index++;
    }
    assertEquals(26.25, model.getShapes().get("R").getWidth(), .01);
    assertEquals(100, model.getShapes().get("R").getHeight(), .01);
    while (index < 100) {
      model.onTick();
      index++;
    }
    assertEquals(200, model.getShapes().get("R").getPosition().getX(), 0.01);
    assertEquals(200, model.getShapes().get("R").getPosition().getY(), 0.01);
  }

  @Test
  public void testEllipseCommands() {
    utils();
    ICommand m1 = new MoveShape(model.getShapes(), "C", 20, 50, new Posn(440, 250));
    ICommand c1 = new ChangeColor(model.getShapes(), "C", 50, 70, new RGB(0, 170, 85));
    ICommand c2 = new ChangeColor(model.getShapes(), "C", 70, 80, new RGB(0, 255, 0));
    model.addCommand(m1);
    model.addCommand(c1);
    model.addCommand(c2);
    int index = 0;
    while (index < 6) {
      model.onTick();
      index++;
    }
    assertEquals(model.getShapes().get("C"), c);
    IShape ellipse2 = c.getCopy();
    while (index < 20) {
      model.onTick();
      index++;
    }
    assertEquals(ellipse2, c);
    while (index < 35) {
      model.onTick();
      index++;
    }
    assertEquals(440, model.getShapes().get("C").getPosition().getX(), 0.01);
    assertEquals(160, model.getShapes().get("C").getPosition().getY(), 0.01);
    while (index <= 50) {
      model.onTick();
      index++;
    }
    assertEquals(model.getShapes().get("C").getPosition(), new Posn(440.0, 250.0));
    while (index < 60) {
      model.onTick();
      index++;
    }
    assertEquals(new RGB(0, 85, 170), model.getShapes().get("C").getColor());
    while (index < 70) {
      model.onTick();
      index++;
    }
    assertEquals(new RGB(0, 170, 85), model.getShapes().get("C").getColor());
    while (index <= 80) {
      model.onTick();
      index++;
    }
    assertEquals(new RGB(0, 255, 0), model.getShapes().get("C").getColor());
  }

  @Test
  public void testStartTime() {
    utils();
    MoveShape r1 = new MoveShape(shapes, "R", 1, 10, new Posn(10, 200));
    assertEquals(1, r1.startTime());
  }

  @Test
  public void testEndTime() {
    utils();
    MoveShape r1 = new MoveShape(shapes, "R", 1, 10, new Posn(10, 200));
    assertEquals(10, r1.endTime());
  }

  @Test
  public void testGetCopy() {
    utils();
    ICommand r1 = new MoveShape(model.getShapes(), "C", 20, 50, new Posn(440, 250));
    ICommand c1 = new ChangeColor(model.getShapes(), "R", 1, 10, new RGB(0, 0, 0));
    ICommand t1 = new TransformShape(model.getShapes(), "R", 1, 10, 10, 10);
    model.addCommand(r1);
    model.addCommand(c1);
    model.addCommand(t1);

    ICommand r2 = r1.getCopy(model.getShapes());
    assertEquals(r2, r1);

    ICommand c2 = c1.getCopy(model.getShapes());
    assertEquals(c2, c1);

    ICommand t2 = t1.getCopy(model.getShapes());
    assertEquals(t2, t1);
  }

  @Test
  public void testGetShapeIndex() {
    utils();
    MoveShape r1 = new MoveShape(shapes, "R", 1, 10, new Posn(10, 200));
    assertEquals("R", r1.getShapeName());
  }

  @Test
  public void testGetShapes() {
    utils();
    TreeMap<String, IShape> tree = new TreeMap<String, IShape>();
    tree.put(r.returnName(), r);
    tree.put(c.returnName(), c);
    assertEquals(tree, model.getShapes());
  }

  @Test
  public void testCommandExceptions() {
    utils();
    try {
      ICommand badIndex = new MoveShape(shapes, "C", 0, 1, new Posn(0, 0));
    } catch (IllegalArgumentException a) {
      assertThat(a.getMessage(), is("Invalid shape index"));
    }
    try {
      ICommand badIndex = new ChangeColor(shapes, "C", 0, 1, new RGB(0, 0, 0));
    } catch (IllegalArgumentException a) {
      assertThat(a.getMessage(), is("Invalid shape index"));
    }
    try {
      ICommand badIndex = new TransformShape(shapes, "C", 0, 1, 10, 10);
    } catch (IllegalArgumentException a) {
      assertThat(a.getMessage(), is("Invalid shape index"));
    }
    try {
      ICommand badIndex = new ChangeColor(shapes, "R", 0, 1, new RGB(-280, 0, 0));
    } catch (IllegalArgumentException a) {
      assertThat(a.getMessage(), is("Invalid Color"));
    }
    try {
      ICommand badIndex = new ChangeColor(shapes, "R", 0, 1, new RGB(280, 0, 0));
    } catch (IllegalArgumentException a) {
      assertThat(a.getMessage(), is("Invalid Color"));
    }
    try {
      ICommand badIndex = new MoveShape(shapes, "R", 0, 1, new Posn(-100, 0));
    } catch (IllegalArgumentException a) {
      assertThat(a.getMessage(), is("Invalid shape index"));
    }
    try {
      ICommand badIndex = new MoveShape(shapes, "R", 0, 1, new Posn(0, -80));
    } catch (IllegalArgumentException a) {
      assertThat(a.getMessage(), is("Invalid shape index"));
    }
  }

  @Test
  public void hashCodeAndEquals() {
    utils();
    ChangeColor c = new ChangeColor(shapes, "R", 0, 10,
        new RGB(10, 10, 10));
    assertEquals(c, c);
    ICommand c2 = c.getCopy(shapes);
    assertEquals(c2, c);
    ChangeColor c3 = new ChangeColor(shapes, "R", 1, 10,
        new RGB(10, 10, 10));
    assertNotEquals(c, c3);

    MoveShape m = new MoveShape(shapes, "R", 0, 10, new Posn(10, 10));
    assertEquals(m, m);
    ICommand m2 = m.getCopy(shapes);
    assertEquals(m, m2);
    MoveShape m3 = new MoveShape(shapes, "R", 0, 10, new Posn(8, 10));
    assertNotEquals(m, m3);

    TransformShape t = new TransformShape(shapes, "R", 0, 10, 10, 10);
    assertEquals(t, t);
    ICommand t2 = t.getCopy(shapes);
    assertEquals(t, t2);
    TransformShape t3 = new TransformShape(shapes, "R", 0, 10, 10, 11);
    assertNotEquals(t, t3);
  }
}