import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import cs3500.animator.view.IAnimationView;
import cs3500.animator.view.MockView;
import cs3500.controller.ExtraAnimationController;
import cs3500.model.IAnimationModel;
import cs3500.model.MockModel;
import org.junit.Test;

/**
 * Testing class for the interactive controller.
 */
public class AnimationControllerTest {

  private StringBuilder log;
  private String output;

  private IAnimationModel model;
  private IAnimationView view;
  private ExtraAnimationController controller;

  private void utils() {

    log = new StringBuilder();

    model = new MockModel(log, 1);
    view = new MockView(log, true);

    controller = new ExtraAnimationController();

  }

  @Test
  public void testStartAnimationTextOrSVG() {
    utils();
    this.view = new MockView(log, false);
    controller.startAnimation(this.model, 20, this.view);
    assertEquals("view.render()", log.toString());
  }

  @Test
  public void testStartAnimationVisualOrInteractive() {
    utils();
    controller.startAnimation(this.model, 20, this.view);
    output = "view.render()";
    assertEquals(output, log.toString());
  }

  @Test
  public void testPauseAndPlay() {
    utils();
    controller.pause();
    assertFalse(controller.getIsPlaying());
    controller.play();
    assertTrue(controller.getIsPlaying());
  }

  @Test
  public void testRestart() {
    utils();
    controller.startAnimation(this.model, 20, this.view);
    controller.restart();
    assertEquals(-1, controller.getTick());
    output = "view.render()model.resetAnimation()";
    assertEquals(output, log.toString());
  }

  @Test
  public void testLoop() {
    utils();
    assertFalse(controller.getIsLooping());
    controller.loop();
    assertTrue(controller.getIsLooping());
    controller.loop();
    assertFalse(controller.getIsLooping());
  }

  @Test
  public void testSpeedUpAndSlowDown() {
    utils();
    controller.startAnimation(this.model, 20, this.view);
    output = "model.onTick()view.render()view.render()";
    controller.speedUp();
    assertEquals(25, controller.getTempo());
    output = "view.render()view.changeTempoTo()";
    assertEquals(output, log.toString());
    controller.slowDown();
    controller.slowDown();
    assertEquals(15, controller.getTempo());
    output += "view.changeTempoTo()";
    output += "view.changeTempoTo()";
    assertEquals(output, log.toString());
  }

  @Test
  public void testToggleFill() {
    utils();
    controller.startAnimation(this.model, 20, this.view);
    output = "view.render()";
    assertEquals(output, log.toString());
    output += "view.toggleFill()";
    controller.toggleFill();
    assertEquals(output, log.toString());
  }

  @Test
  public void testToggleDiscrete() {
    utils();
    assertFalse(controller.getToggleDiscrete());
    controller.toggleDiscrete();
    assertTrue(controller.getToggleDiscrete());
  }


}
