import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

import cs3500.animator.view.AnimationSVGView;
import cs3500.animator.view.ExtraSVGView;
import cs3500.model.IAnimationModel;
import cs3500.model.SimpleAnimationModel;
import cs3500.model.SimpleViewModel;
import cs3500.model.commands.ChangeColor;
import cs3500.model.commands.Display;
import cs3500.model.commands.ICommand;
import cs3500.model.commands.MoveShape;
import cs3500.model.commands.TransformShape;
import cs3500.model.shapes.IShape;
import cs3500.model.shapes.Oval;
import cs3500.model.shapes.Plus;
import cs3500.model.shapes.Posn;
import cs3500.model.shapes.RGB;
import cs3500.model.shapes.Rectangle;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;
import org.junit.Test;

/**
 * A class used to test methods on the SVG view.
 */
public class SVGViewTest {

  private IShape r;
  private IShape c;
  private TreeMap<String, IShape> shapes;
  private IAnimationModel delegateModel;
  private SimpleViewModel model;
  private List<ICommand> toDo;
  private List<ICommand> ongoing;
  private List<IShape> shapesInOrder;
  private AnimationSVGView view;
  private Appendable ap;


  @Test
  public void testSVGPlus() {
    IShape p;
    p = new Plus("P", new Posn(200, 200),
        new RGB(255, 0, 0), 100, 100, 1, 1);
    shapes = new TreeMap<String, IShape>();
    shapes.put("P", p);
    toDo = new ArrayList<ICommand>();
    ongoing = new ArrayList<ICommand>();
    shapesInOrder = new ArrayList<IShape>();
    shapesInOrder.add(p);
    Display d1 = new Display(shapes, "P", 1, 1);
    MoveShape p1 = new MoveShape(shapes, "P", 10, 50,
        new Posn(300, 300));
    TransformShape t1 = new TransformShape(shapes, "P", 10,
        50, 150, 150);
    ChangeColor c1 = new ChangeColor(shapes, "P", 10, 50,
        new RGB(0, 255, 255));
    delegateModel =
        new SimpleAnimationModel(shapes, toDo, ongoing, 400, 400, 400, 400,
            shapesInOrder);
    delegateModel.addCommand(d1);
    delegateModel.addCommand(p1);
    delegateModel.addCommand(t1);
    delegateModel.addCommand(c1);
    model = new SimpleViewModel(delegateModel);
    ap = new StringBuilder();
    ExtraSVGView view = new ExtraSVGView(model, 10, ap);
    view.render();

    assertEquals(
        "<svg width=\"400\" height=\"400\" version=\"1.1\"\n"
            + " viewBox=\"400 400 400 400\" xmlns=\"http://www.w3.org/2000/svg\">\n"
            + " <desc>An animation of your choosing</desc>\n"
            + "<rect id=\"P1\" x=\"225\" y=\"200\" width=\"50\" height=\"100\" "
            + "fill=\"rgb(255,0,0)\" visibility=\"hidden\" >\n"
            + "    <set attributeName=\"visibility\" attributeType=\"CSS\" to=\"visible\" "
            + "begin=\"0ms\" dur =\"4000ms\" fill=\"freeze\" />\n"
            + "    <animate attributeType=\"xml\" begin=\"1000ms\" dur=\"4000ms\" "
            + "attributeName=\"x\" from=\"225.0\" to=\"325.0\" fill=\"freeze\" />\n"
            + "    <animate attributeType=\"xml\" begin=\"1000ms\" dur=\"4000ms\" "
            + "attributeName=\"y\" from=\"200.0\" to=\"300.0\" fill=\"freeze\" />\n"
            + "    <animate attributeType=\"xml\" begin=\"1000ms\" dur=\"4000ms\" "
            + "attributeName=\"x\" from=\"225.0\" to=\"237.5\" fill=\"freeze\" />\n"
            + "    <animate attributeType=\"xml\" begin=\"1000ms\" dur=\"4000ms\" "
            + "attributeName=\"width\" from=\"50.0\" to=\"75.0\" fill=\"freeze\" />\n"
            + "    <animate attributeType=\"xml\" begin=\"1000ms\" dur=\"4000ms\" "
            + "attributeName=\"height\" from=\"100.0\" to=\"150.0\" fill=\"freeze\" />\n"
            + "    <animate attributeType=\"xml\" begin=\"1000ms\" dur=\"4000ms\" "
            + "attributeName=\"fill\" from=\"rgb(255,0,0)\" to=\"rgb(0,255,255)\" "
            + "fill=\"freeze\" />\n"
            + "\n"
            + "</rect>\n"
            + "<rect id=\"P2\" x=\"200\" y=\"225\" width=\"100\" height=\"50\" "
            + "fill=\"rgb(255,0,0)\" visibility=\"hidden\" >\n"
            + "    <set attributeName=\"visibility\" attributeType=\"CSS\" "
            + "to=\"visible\" begin=\"0ms\" dur =\"4000ms\" fill=\"freeze\" />\n"
            + "    <animate attributeType=\"xml\" begin=\"1000ms\" dur=\"4000ms\" "
            + "attributeName=\"x\" from=\"200.0\" to=\"300.0\" fill=\"freeze\" />\n"
            + "    <animate attributeType=\"xml\" begin=\"1000ms\" dur=\"4000ms\" "
            + "attributeName=\"y\" from=\"225.0\" to=\"325.0\" fill=\"freeze\" />\n"
            + "    <animate attributeType=\"xml\" begin=\"1000ms\" dur=\"4000ms\" "
            + "attributeName=\"y\" from=\"225.0\" to=\"237.5\" fill=\"freeze\" />\n"
            + "    <animate attributeType=\"xml\" begin=\"1000ms\" dur=\"4000ms\" "
            + "attributeName=\"width\" from=\"100.0\" to=\"150.0\" fill=\"freeze\" />\n"
            + "    <animate attributeType=\"xml\" begin=\"1000ms\" dur=\"4000ms\" "
            + "attributeName=\"height\" from=\"50.0\" to=\"75.0\" fill=\"freeze\" />\n"
            + "    <animate attributeType=\"xml\" begin=\"1000ms\" dur=\"4000ms\" "
            + "attributeName=\"fill\" from=\"rgb(255,0,0)\" to=\"rgb(0,255,255)\" "
            + "fill=\"freeze\" />\n"
            + "\n"
            + "</rect>\n"
            + "</svg>",
        ap.toString());
  }

  /**
   * Tests the SVG String output.
   */
  @Test
  public void testSVGOutput() {
    r = new Rectangle("R", new Posn(200, 200),
        new RGB(255, 0, 0), 50, 100, 1, 1);

    c = new Oval("C", new Posn(440, 70), new RGB(0, 0, 255),
        120, 60, 1, 1);
    shapes = new TreeMap<String, IShape>();
    shapes.put("R", r);
    shapes.put("C", c);
    toDo = new ArrayList<ICommand>();
    ongoing = new ArrayList<ICommand>();
    shapesInOrder = new ArrayList<IShape>();
    shapesInOrder.add(r);
    shapesInOrder.add(c);
    Display d1 = new Display(shapes, "R", 0, 0);
    Display d2 = new Display(shapes, "C", 20, 20);
    MoveShape r2 = new MoveShape(shapes, "R", 10, 50,
        new Posn(300, 300));
    TransformShape t1 = new TransformShape(shapes, "R", 51,
        70, 25, 100);
    MoveShape r3 = new MoveShape(shapes, "R", 70, 100,
        new Posn(200, 200));
    MoveShape r4 = new MoveShape(shapes, "C", 20, 50,
        new Posn(440, 250));
    MoveShape r5 = new MoveShape(shapes, "C", 50, 70,
        new Posn(440, 370));
    ChangeColor c1 = new ChangeColor(shapes, "C", 50, 70,
        new RGB(0, 170, 85));
    ChangeColor c2 = new ChangeColor(shapes, "C", 70, 80,
        new RGB(0, 255, 0));
    ChangeColor c3 = new ChangeColor(shapes, "C", 80, 100,
        new RGB(60, 0, 255));
    delegateModel =
        new SimpleAnimationModel(shapes, toDo, ongoing, 400, 400, 400, 400,
            shapesInOrder);
    delegateModel.addCommand(d1);
    delegateModel.addCommand(d2);
    delegateModel.addCommand(r2);
    delegateModel.addCommand(t1);
    delegateModel.addCommand(r3);
    delegateModel.addCommand(r4);
    delegateModel.addCommand(r5);
    delegateModel.addCommand(c1);
    delegateModel.addCommand(c2);
    delegateModel.addCommand(c3);
    model = new SimpleViewModel(delegateModel);
    ap = new StringBuilder();
    view = new AnimationSVGView(model, 10, ap);
    view.render();
    assertEquals("<svg width=\"400\" height=\"400\" version=\"1.1\"\n"
        + " viewBox=\"400 400 400 400\" xmlns=\"http://www.w3.org/2000/svg\">\n"
        + " <desc>An animation of your choosing</desc>\n"
        + "<rect id=\"R\" x=\"200\" y=\"200\" width=\"50\" height=\"100\" fill=\"rgb(255,0,0)\""
        + " visibility=\"hidden\" >\n"
        + "    <set attributeName=\"visibility\" attributeType=\"CSS\" to=\"visible\" "
        + "begin=\"0ms\" "
        + ""
        + "dur =\"10000ms\" fill=\"freeze\" />\n"
        + "    <animate attributeType=\"xml\" begin=\"1000ms\" dur=\"4000ms\" attributeName=\"x\" "
        + "from=\"200.0\" to=\"300.0\" fill=\"freeze\" />\n"
        + "    <animate attributeType=\"xml\" begin=\"1000ms\" dur=\"4000ms\""
        + " attributeName=\"y\" from=\"200.0\" to=\"300.0\" fill=\"freeze\" />\n"
        + "    <animate attributeType=\"xml\" begin=\"5000ms\" dur=\"1900ms\" "
        + "attributeName=\"width\" from=\"50.0\" to=\"25.0\" fill=\"freeze\" />\n"
        + "    <set attributeName=\"visibility\" attributeType=\"CSS\" to=\"visible\""
        + " begin=\"7000ms\" dur =\"3000ms\" fill=\"freeze\" />\n"
        + "</rect>\n"
        + " \n"
        + "<ellipse id=\"C\" cx=\"440\" cy=\"70\" rx=\"60\" ry=\"30\" fill=\"rgb(0,0,255)\""
        + " visibility=\"hidden\" >\n"
        + "    <set attributeName=\"visibility\" attributeType=\"CSS\" to=\"visible\""
        + " begin=\"2000ms\" dur =\"8000ms\" fill=\"freeze\" />\n"
        + "    <animate attributeType=\"xml\" begin=\"2000ms\" dur=\"3000ms\" "
        + "attributeName=\"cy\" from=\"70.0\" to=\"250.0\" fill=\"freeze\" />\n"
        + "    <animate attributeType=\"xml\" begin=\"5000ms\" dur=\"2000ms\""
        + " attributeName=\"cy\" from=\"70.0\" to=\"370.0\" fill=\"freeze\" />\n"
        + "    <animate attributeType=\"xml\" begin=\"5000ms\" dur=\"2000ms\" "
        + "attributeName=\"fill\" from=\"rgb(0,0,255)\" to=\"rgb(0,170,85)\" fill=\"freeze\" />\n"
        + "    <animate attributeType=\"xml\" begin=\"7000ms\" dur=\"1000ms\" "
        + "attributeName=\"fill\" from=\"rgb(0,0,255)\" to=\"rgb(0,255,0)\" fill=\"freeze\" />\n"
        + "    <animate attributeType=\"xml\" begin=\"8000ms\" dur=\"2000ms\" "
        + "attributeName=\"fill\" from=\"rgb(0,0,255)\" to=\"rgb(60,0,255)\" fill=\"freeze\" />\n"
        + "</ellipse>\n"
        + " \n"
        + "</svg>", ap.toString());
  }

  /**
   * Tests the exceptions an SVG can go through.
   */
  @Test
  public void testSVGErrors() {
    r = new Rectangle("R", new Posn(200, 200),
        new RGB(255, 0, 0), 50, 100, 1, 1);

    c = new Oval("C", new Posn(440, 70), new RGB(0, 0, 255),
        120, 60, 1, 1);
    shapes = new TreeMap<String, IShape>();
    shapes.put("R", r);
    shapes.put("C", c);
    toDo = new ArrayList<ICommand>();
    ongoing = new ArrayList<ICommand>();
    shapesInOrder = new ArrayList<IShape>();
    shapesInOrder.add(r);
    shapesInOrder.add(c);
    Display d1 = new Display(shapes, "R", 0, 0);
    Display d2 = new Display(shapes, "C", 20, 20);
    MoveShape r2 = new MoveShape(shapes, "R", 10, 50,
        new Posn(300, 300));
    TransformShape t1 = new TransformShape(shapes, "R", 51,
        70, 25, 100);
    MoveShape r3 = new MoveShape(shapes, "R", 70, 100,
        new Posn(200, 200));
    MoveShape r4 = new MoveShape(shapes, "C", 20, 50,
        new Posn(440, 250));
    MoveShape r5 = new MoveShape(shapes, "C", 50, 70,
        new Posn(440, 370));
    ChangeColor c1 = new ChangeColor(shapes, "C", 50, 70,
        new RGB(0, 170, 85));
    ChangeColor c2 = new ChangeColor(shapes, "C", 70, 80,
        new RGB(0, 255, 0));
    ChangeColor c3 = new ChangeColor(shapes, "C", 80, 100,
        new RGB(60, 0, 255));
    delegateModel =
        new SimpleAnimationModel(shapes, toDo, ongoing, 400, 400, 400, 400,
            shapesInOrder);
    delegateModel.addCommand(d1);
    delegateModel.addCommand(d2);
    delegateModel.addCommand(r2);
    delegateModel.addCommand(t1);
    delegateModel.addCommand(r3);
    delegateModel.addCommand(r4);
    delegateModel.addCommand(r5);
    delegateModel.addCommand(c1);
    delegateModel.addCommand(c2);
    delegateModel.addCommand(c3);
    model = new SimpleViewModel(delegateModel);
    ap = new StringBuilder();
    view = new AnimationSVGView(model, 10, ap);
    view.render();
    try {
      view = new AnimationSVGView(model, -1, new StringBuilder());
    } catch (IllegalArgumentException i) {
      assertThat(i.getMessage(), is("Negative tempo not allowed"));
    }
    try {
      view = new AnimationSVGView(null, 1, new StringBuilder());
    } catch (IllegalArgumentException i) {
      assertThat(i.getMessage(), is("Null model not allowed"));
    }
  }
}