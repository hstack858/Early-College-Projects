import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

import cs3500.animator.view.AnimationTextualView;
import cs3500.model.IAnimationModel;
import cs3500.model.IViewModel;
import cs3500.model.SimpleAnimationModel;
import cs3500.model.SimpleViewModel;
import cs3500.model.commands.ChangeColor;
import cs3500.model.commands.ICommand;
import cs3500.model.commands.MoveShape;
import cs3500.model.commands.TransformShape;
import cs3500.model.shapes.IShape;
import cs3500.model.shapes.Oval;
import cs3500.model.shapes.Posn;
import cs3500.model.shapes.RGB;
import cs3500.model.shapes.Rectangle;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;
import org.junit.Test;

/**
 * Testing class for the view.
 */
public class TextualViewTest {

  private IShape r;
  private IShape c;
  private TreeMap<String, IShape> shapes;
  private IAnimationModel delegateModel;
  private SimpleViewModel model;
  private List<ICommand> toDo;
  private List<ICommand> ongoing;
  private List<IShape> shapesInOrder;


  /**
   * Tests the textual view output.
   */
  @Test
  public void testToStringRectangleAndEllipse() {
    r = new Rectangle("R", new Posn(200, 200),
        new RGB(255, 0, 0), 50, 100, 1, 1);

    c = new Oval("C", new Posn(440, 70), new RGB(0, 0, 255),
        120, 60, 1, 1);
    shapes = new TreeMap<String, IShape>();
    shapes.put("R", r);
    shapes.put("C", c);
    toDo = new ArrayList<ICommand>();
    ongoing = new ArrayList<ICommand>();
    shapesInOrder = new ArrayList<IShape>();
    MoveShape r2 = new MoveShape(shapes, "R", 10, 50,
        new Posn(300, 300));
    TransformShape t1 = new TransformShape(shapes, "R", 51,
        70, 25, 100);
    MoveShape r3 = new MoveShape(shapes, "R", 70, 100,
        new Posn(200, 200));
    MoveShape r4 = new MoveShape(shapes, "C", 20, 50,
        new Posn(440, 250));
    MoveShape r5 = new MoveShape(shapes, "C", 50, 70,
        new Posn(440, 370));
    ChangeColor c1 = new ChangeColor(shapes, "C", 50, 70,
        new RGB(0, 170, 85));
    ChangeColor c2 = new ChangeColor(shapes, "C", 70, 80,
        new RGB(0, 255, 0));
    ChangeColor c3 = new ChangeColor(shapes, "C", 80,
        100, new RGB(60, 0, 255));
    delegateModel =
        new SimpleAnimationModel(shapes, toDo, ongoing, 400, 400,
            400, 400, shapesInOrder);
    delegateModel.addCommand(r2);
    delegateModel.addCommand(t1);
    delegateModel.addCommand(r3);
    delegateModel.addCommand(r4);
    delegateModel.addCommand(r5);
    delegateModel.addCommand(c1);
    delegateModel.addCommand(c2);
    delegateModel.addCommand(c3);
    model = new SimpleViewModel(delegateModel);
    AnimationTextualView rView = new AnimationTextualView(model, 1, new StringBuilder());
    assertEquals(
        "shape C oval\n"
            + "motion C 20 440.0 70.0 120.0 60.0 0.0 0.0 255.0"
            + "    20 440.0 70.0 120.0 60.0 0.0 0.0 255.0\n"
            + "motion C 20  440.0 70.0 120.0 60.0 0.0 0.0 255.0"
            + "    50  440.0 250.0 120.0 60.0 0.0 0.0 255.0\n"
            + "motion C 50  440.0 250.0 120.0 60.0 0.0 0.0 255.0"
            + "    70  440.0 370.0 120.0 60.0 0.0 170.0 85.0\n"
            + "motion C 70  440.0 370.0 120.0 60.0 0.0 170.0 85.0"
            + "    80  440.0 370.0 120.0 60.0 0.0 255.0 0.0\n"
            + "motion C 80  440.0 370.0 120.0 60.0 0.0 255.0 0.0"
            + "    100 440.0 370.0 120.0 60.0 60.0 0.0 255.0\n"
            + "motion C 100 440.0 70.0 120.0 60.0 0.0 0.0 255.0"
            + "    100 440.0 70.0 120.0 60.0 0.0 0.0 255.0\n"
            + "shape R rect\n"
            + "motion R 10 200.0 200.0 50.0 100.0 255.0 0.0 0.0"
            + "    10 200.0 200.0 50.0 100.0 255.0 0.0 0.0\n"
            + "motion R 10  200.0 200.0 50.0 100.0 255.0 0.0 0.0 "
            + "   50  300.0 300.0 50.0 100.0 255.0 0.0 0.0\n"
            + "motion R 51  300.0 300.0 50.0 100.0 255.0 0.0 0.0 "
            + "   70  300.0 300.0 25.0 100.0 255.0 0.0 0.0\n"
            + "motion R 70  300.0 300.0 25.0 100.0 255.0 0.0 0.0"
            + "    100 200.0 200.0 25.0 100.0 255.0 0.0 0.0\n"
            + "motion R 100 200.0 200.0 50.0 100.0 255.0 0.0 0.0"
            + "    100 200.0 200.0 50.0 100.0 255.0 0.0 0.",
        rView.toString());
  }

  @Test
  public void testViewErrors() {
    try {
      r = new Rectangle("R", new Posn(200, 200),
          new RGB(255, 0, 0), 50, 100, 1, 1);

      c = new Oval("C", new Posn(440, 70), new RGB(0, 0, 255),
          120, 60, 1, 1);
      shapes = new TreeMap<String, IShape>();
      shapes.put("R", r);
      shapes.put("C", c);
      toDo = new ArrayList<ICommand>();
      ongoing = new ArrayList<ICommand>();
      shapesInOrder = new ArrayList<IShape>();
      MoveShape r2 = new MoveShape(shapes, "R", 10, 50,
          new Posn(300, 300));
      TransformShape t1 = new TransformShape(shapes, "R", 51,
          70, 25, 100);
      MoveShape r3 = new MoveShape(shapes, "R", 70, 100,
          new Posn(200, 200));
      MoveShape r4 = new MoveShape(shapes, "C", 20, 50,
          new Posn(440, 250));
      MoveShape r5 = new MoveShape(shapes, "C", 50, 70,
          new Posn(440, 370));
      ChangeColor c1 = new ChangeColor(shapes, "C", 50, 70,
          new RGB(0, 170, 85));
      ChangeColor c2 = new ChangeColor(shapes, "C", 70, 80,
          new RGB(0, 255, 0));
      ChangeColor c3 = new ChangeColor(shapes, "C", 80,
          100, new RGB(60, 0, 255));
      delegateModel =
          new SimpleAnimationModel(shapes, toDo, ongoing, 400, 400,
              400, 400, shapesInOrder);
      delegateModel.addCommand(r2);
      delegateModel.addCommand(t1);
      delegateModel.addCommand(r3);
      delegateModel.addCommand(r4);
      delegateModel.addCommand(r5);
      delegateModel.addCommand(c1);
      delegateModel.addCommand(c2);
      delegateModel.addCommand(c3);
      model = new SimpleViewModel(delegateModel);
      AnimationTextualView rView = new AnimationTextualView(model, -10, new StringBuilder());
    } catch (IllegalArgumentException i) {
      assertThat(i.getMessage(), is("Can't have negative tempo"));
    }
    try {
      r = new Rectangle("R", new Posn(200, 200),
          new RGB(255, 0, 0), 50, 100, 1, 1);

      c = new Oval("C", new Posn(440, 70), new RGB(0, 0, 255),
          120, 60, 1, 1);
      shapes = new TreeMap<String, IShape>();
      shapes.put("R", r);
      shapes.put("C", c);
      toDo = new ArrayList<ICommand>();
      ongoing = new ArrayList<ICommand>();
      shapesInOrder = new ArrayList<IShape>();
      MoveShape r2 = new MoveShape(shapes, "R", 10, 50,
          new Posn(300, 300));
      TransformShape t1 = new TransformShape(shapes, "R", 51,
          70, 25, 100);
      MoveShape r3 = new MoveShape(shapes, "R", 70, 100,
          new Posn(200, 200));
      MoveShape r4 = new MoveShape(shapes, "C", 20, 50,
          new Posn(440, 250));
      MoveShape r5 = new MoveShape(shapes, "C", 50, 70,
          new Posn(440, 370));
      ChangeColor c1 = new ChangeColor(shapes, "C", 50, 70,
          new RGB(0, 170, 85));
      ChangeColor c2 = new ChangeColor(shapes, "C", 70, 80,
          new RGB(0, 255, 0));
      ChangeColor c3 = new ChangeColor(shapes, "C", 80,
          100, new RGB(60, 0, 255));
      delegateModel =
          new SimpleAnimationModel(shapes, toDo, ongoing, 400, 400,
              400, 400, shapesInOrder);
      delegateModel.addCommand(r2);
      delegateModel.addCommand(t1);
      delegateModel.addCommand(r3);
      delegateModel.addCommand(r4);
      delegateModel.addCommand(r5);
      delegateModel.addCommand(c1);
      delegateModel.addCommand(c2);
      delegateModel.addCommand(c3);
      model = new SimpleViewModel(delegateModel);
      AnimationTextualView rView = new AnimationTextualView(model, -1,
          new StringBuilder());
    } catch (IllegalArgumentException i) {
      assertThat(i.getMessage(), is("Can't have negative tempo"));
    }

    ArrayList<ICommand> toDo = new ArrayList<ICommand>();
    ArrayList<ICommand> ongoing = new ArrayList<ICommand>();
    ArrayList<IShape> shapesInOrder = new ArrayList<IShape>();
    SimpleAnimationModel rModel = new SimpleAnimationModel(shapes, toDo, ongoing, 100,
        100, 100, 100, shapesInOrder);

    IViewModel model2 = new SimpleViewModel(rModel);
    AnimationTextualView rView = new AnimationTextualView(model2, 10, new StringBuilder());
    try {
      assertEquals("", rView.toString());
    } catch (IndexOutOfBoundsException i) {
      assertThat(i.getMessage(), is("Index 0 out of bounds for length 0"));
    }
  }
}
